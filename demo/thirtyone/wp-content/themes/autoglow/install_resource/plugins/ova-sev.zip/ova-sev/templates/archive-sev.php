<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header();

$number_column = get_theme_mod( 'ova_sev_layout', 'three_column' );

?>

<div class="container">
	<div class="row">
		<div class="ova_sev_wrap archive_sev <?php echo esc_attr( $number_column ) ?>">
			<div class="content">
				<?php if( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<?php 
						$id = get_the_id();

						$class_icon = get_post_meta( $id, 'ova_sev_met_class_icon', true );
						$title = get_the_title();
						$link = get_the_permalink();
						$url_img = get_the_post_thumbnail_url($id, 'post-thumbnail');
						$title2 = get_post_meta( $id, 'ova_sev_met_title', true );
						?>

						
						<div  class="items elementor-items" >


							<div class="content_img_items">
								<img src="<?php echo esc_attr( $url_img) ?>)">


								<div class = "content_sub_items">
									<div class="content_items">


										<?php if( $class_icon ){ ?>
											<div class="icon">

												<span class="<?php echo esc_attr( $class_icon ) ?>"></span>

											</div>
										<?php } ?>

										<?php if( $title ){ ?>
											<h2 class="title second_font">

												<?php echo $title ?>

											</h2>
										<?php } ?>

										<div class="content-sub">
											<?php if( $title2 )  { ?>
												<div class=" excerpt">
													<?php echo esc_html( $title2 ) ?>
												</div>
											<?php } ?>

											<a class="readmore second_font " href="<?php echo get_the_permalink() ?>"  ><i class="flaticon-arrows"></i><?php echo esc_html( 'Read More','ova-sev') ?></a>
										</div>
									</div>
								</div>


							</div>


						</div>
					  
						



				<?php endwhile; endif; wp_reset_postdata(); ?>
				
			</div>
			
			<?php 
				autoglow_pagination_theme();
			?>

		</div>
	</div>
</div>

<?php 
 get_footer();