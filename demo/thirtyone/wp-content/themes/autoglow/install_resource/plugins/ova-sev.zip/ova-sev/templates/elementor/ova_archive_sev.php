<?php if ( !defined( 'ABSPATH' ) ) exit();
$category = $args['category'];
$number_column = $args['number_column'];
$post_per_page = $args['total_count'];
$text = $args['text'];

if( $category == 'all' ){
	$args= array(
		'post_type' => 'ova_sev',
		'post_status' => 'publish',
		'posts_per_page' => $post_per_page,
		'meta_key' => 'ova_sev_met_order_sev',
		'meta_type' => 'NUMERIC', 
        'orderby' => 'meta_value_num',
        'order'   => "ASC",
	);
} else {
	$args= array(
		'post_type' => 'ova_sev',
		'post_status' => 'publish',
		'posts_per_page' => $post_per_page,
		'meta_key' => 'ova_sev_met_order_sev',
		'meta_type' => 'NUMERIC',
		'orderby' => 'meta_value_num', 
        'order'   => "ASC",
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_sev',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$sevs  = new \WP_Query($args);

?>


<div class="ova_archive_sev archive_sev <?php echo esc_attr( $number_column ) ?>">
	<div class="content">
		<?php if( $sevs->have_posts() ) : while ( $sevs->have_posts() ) : $sevs->the_post(); ?>
			<?php 
				$id = get_the_id();

				$class_icon = get_post_meta( $id, 'ova_sev_met_class_icon', true );
				$title = get_the_title();
				$link = get_the_permalink();
				$url_img = get_the_post_thumbnail_url($id, 'post-thumbnail');
				$title2 = get_post_meta( $id, 'ova_sev_met_title', true );
				?>

			<div  class="items elementor-items" >


				<div class="content_img_items">
					<img src="<?php echo esc_url( $url_img) ?>">


					<div class = "content_sub_items">
						<div class="content_items">


							<?php if( $class_icon ){ ?>
								<div class="icon">

									<span class="<?php echo esc_attr( $class_icon ) ?>"></span>

								</div>
							<?php } ?>

							<?php if( $title ){ ?>
								<h2 class="title second_font">

									<?php echo $title ?>

								</h2>
							<?php } ?>

							<div class="content-sub">
								<?php if( $title2 )  { ?>
									<div class=" excerpt">
										<?php echo esc_html( $title2 ) ?>
									</div>
								<?php } ?>

								<?php if ( ! empty( $text ) ){ ?>

									<a class="readmore second_font " href="<?php echo get_the_permalink() ?>"  ><i class="flaticon-arrows"></i><?php echo esc_html( $text ) ?></a>

								<?php } ?>
							</div>
						</div>
					</div>


				</div>





			</div>
	

		<?php endwhile; endif; wp_reset_postdata(); ?>
	</div>



</div>


<?php 
