<?php if ( !defined( 'ABSPATH' ) ) exit();

if( !class_exists( 'OVAEV_loadmore' ) ){
	class OVAEV_loadmore{

		public function __construct(){

			add_action( 'wp_ajax_filter_elementor_grid', array( $this, 'filter_elementor_grid') );
			add_action( 'wp_ajax_nopriv_filter_elementor_grid', array( $this, 'filter_elementor_grid') );

			
		}

	

		/* Ajax Load Post Click Elementor */
		public static function filter_elementor_grid() {

			$filter = $_POST['filter'];
			$order = $_POST['order'];
			$orderby = $_POST['orderby'];
			$number_post = $_POST['number_post'];
			$first_term = $_POST['first_term'];
			$term_id_filter_string = $_POST['term_id_filter_string'];
			$term_id_filter = explode(', ', $term_id_filter_string);
			$args_base = array(
				'post_type' => 'ova_fw',
				'post_status' => 'publish',
				'numberposts'      => $numberposts,
				'order' => $order_post,
				'orderby' => $orderby_post,
			
			);
			


			if ($filter != 'all') {
				$args_cat = array(
					'p'    => $filter,
				);

				$args = array_merge_recursive($args_cat,$args_base);
				$my_posts = new WP_Query( $args );

			} else {
				$args_cat = array(
					'post__in'    => $term_id_filter,
				);

				$args = array_merge_recursive($args_base, $args_cat);
				$my_posts = new WP_Query( $args );
			}
			
			?>

			<?php
			if( $my_posts->have_posts() ) : while( $my_posts->have_posts() ) : $my_posts->the_post();

				$id = get_the_ID();
				$ova_met_gallery = get_post_meta( $id, 'ova_met_gallery', true ) ? get_post_meta( $id, 'ova_met_gallery', true ) : '';
				
				$id2='1';
				$title = get_the_title($id);
				

				?>

				

					<?php if ( $ova_met_gallery ) {
						foreach ( $ova_met_gallery  as $key => $value ) { ?>
							<div class="wrap_item">
								<a href="<?php echo esc_attr( $value ); ?>" data-fancybox="<?php echo esc_attr( $id2 ); ?>" class="item ">
									<div class="content_item">
									<img src="<?php echo esc_attr( $value ); ?>" alt="<?php echo esc_attr( $key ); ?>">
									<div class="content_item_2">
										<div class="title second_font">
											<?php echo $title ?>
										</div>
										<div class="category">
											<?php get_category_fw_by_id_fw( $id ) ?>
										</div>
										
									</div>
									<div class="readmore">

										<i data-feather="plus"></i>

									</div>
								    </div>


								</a>
							</div>
						<?php }

					} ?>



		
			<?php endwhile; endif; wp_reset_postdata(); ?>
			<?php
			wp_die();
		}



	}
	new OVAEV_loadmore();
}
?>