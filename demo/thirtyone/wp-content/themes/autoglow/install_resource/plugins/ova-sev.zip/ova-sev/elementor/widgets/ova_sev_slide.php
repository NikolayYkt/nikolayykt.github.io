<?php
namespace ova_sev_elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_sev_slide extends Widget_Base {


	public function get_name() {
		return 'ova_sev_slide';
	}

	public function get_title() {
		return __( 'Service Slide', 'ova-sev' );
	}

	public function get_icon() {
		return 'fa fa-sliders';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		wp_enqueue_style( 'owl-carousel', OVA_PLUGIN_URI.'assets/lib/owl-carousel/assets/owl.carousel.min.css' );
		wp_enqueue_script( 'owl-carousel', OVA_PLUGIN_URI.'assets/lib/owl-carousel/owl.carousel.min.js', array('jquery'), false, true );

		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-sev' ),
			]
		);

		$args = array(
           'taxonomy' => 'cat_sev',
           'orderby' => 'name',
           'order'   => 'ASC'
       	);
	
		$categories = get_categories($args);
		$catAll = array( 'all' => 'All categories');
		$cate_array = array();
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->slug] = $cate->cat_name;
			}
		} else {
			$cate_array[] = esc_html__( "No content Category found", "ova-sev" );
		}

		$this->add_control(
			'category',
			[
				'label'   => __( 'Category', 'ova-sev' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => array_merge( $catAll, $cate_array )
			]
		);

		$this->add_control(
			'total_count',
			[
				'label'   => __( 'Total', 'ova-sev' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4
			]
		);

		$this->add_control(
			'show_icon',
			[
				'label' => __( 'Show Icon', 'ova-sev' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ova-sev' ),
				'label_off' => __( 'Hide', 'ova-sev' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ova-sev' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ova-sev' ),
				'label_off' => __( 'Hide', 'ova-sev' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_title2',
			[
				'label' => __( 'Show Title 2', 'ova-sev' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ova-sev' ),
				'label_off' => __( 'Hide', 'ova-sev' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'text',
			[
				'label' => __( 'Text Button', 'ova-sev' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Read More', 'ova-sev' ),
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => __( 'Additional Options', 'ova-sev' ),
			]
		);


		/***************************  VERSION 1 ***********************/
			$this->add_control(
				'margin_items',
				[
					'label'   => __( 'Margin Right Items', 'ova-sev' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 30,
				]
				
			);

			$this->add_control(
				'item_number',
				[
					'label'       => __( 'Item Number', 'ova-sev' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => __( 'Number Item', 'ova-sev' ),
					'default'     => 3,
				]
			);

	

			$this->add_control(
				'slides_to_scroll',
				[
					'label'       => __( 'Slides to Scroll', 'ova-sev' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-sev' ),
					'default'     => 1,
				]
			);

			$this->add_control(
				'pause_on_hover',
				[
					'label'   => __( 'Pause on Hover', 'ova-sev' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-sev' ),
						'no'  => __( 'No', 'ova-sev' ),
					],
					'frontend_available' => true,
				]
			);


			$this->add_control(
				'infinite',
				[
					'label'   => __( 'Infinite Loop', 'ova-sev' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-sev' ),
						'no'  => __( 'No', 'ova-sev' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'   => __( 'Autoplay', 'ova-sev' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-sev' ),
						'no'  => __( 'No', 'ova-sev' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_speed',
				[
					'label'     => __( 'Autoplay Speed', 'ova-sev' ),
					'type'      => Controls_Manager::NUMBER,
					'default'   => 3000,
					'step'      => 500,
					'condition' => [
						'autoplay' => 'yes',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'smartspeed',
				[
					'label'   => __( 'Smart Speed', 'ova-sev' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500,
				]
			);

			$this->add_control(
				'dot_control',
				[
					'label'   => __( 'Show Dots', 'ova-sev' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-sev' ),
						'no'  => __( 'No', 'ova-sev' ),
					],
					'frontend_available' => true,
				]
			);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_icon',
			[
				'label' => __( 'Icon', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color', 'ova-sev' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .icon span::before' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'back_color_icon',
			[
				'label' => __( 'Background Color', 'ova-sev' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .icon ' => 'background-color : {{VALUE}};',
				],
			]
		);




		$this->end_controls_section();



		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .title ',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color ', 'ova-sev' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .title ' => 'color : {{VALUE}};',
				],
			]
		);

	

		$this->add_responsive_control(
			'margin_title',
			[
				'label' => __( 'Margin', 'ova-sev' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_excerpt',
			[
				'label' => __( 'Excerpt', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typography',
				'selector' => '{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .content-sub .excerpt',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_excerpt',
			[
				'label' => __( 'Color ', 'ova-sev' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .content-sub .excerpt' => 'color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_readmore',
			[
				'label' => __( 'Read More', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'readmore_typography',
				'selector' => '{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .content-sub .readmore',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_readmore',
			[
				'label' => __( 'Color ', 'ova-sev' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .content-sub .readmore' => 'color : {{VALUE}};',
				],
			]
		);



		$this->add_control(
			'color_readmore_hover',
			[
				'label' => __( 'Color Hover', 'ova-sev' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .content-sub .readmore:hover' => 'color : {{VALUE}};',
				],
			]
		);



		$this->add_responsive_control(
			'margin_readmore',
			[
				'label' => __( 'Margin', 'ova-sev' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .archive_sev .items .content_img_items .content_sub_items .content_items .content-sub .readmore' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		

		$this->start_controls_section(
			'section_dot',
			[
				'label' => __( 'Dot', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
			'dot_color_readmore_active',
			[
				'label' => __( 'Dot Active Color', 'ova-sev' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .archive_sev .owl-dots .owl-dot.active span' => 'background-color : {{VALUE}};border-color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


	}


	protected function render() {

		$settings = $this->get_settings();

		$template = apply_filters( 'el_elementor_ova_sev', 'elementor/ova_sev_slide_temp.php' );

		ob_start();
		ovasev_get_template( $template, $settings );
		echo ob_get_clean();
		
	}
}
