<?php
namespace ova_sev_elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_sev_grid extends Widget_Base {

	public function get_name() {
		return 'ova_sev_grid';
	}

	public function get_title() {
		return __( 'Service Filter Ajax', 'ovaev' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		wp_enqueue_script( 'slick-script', OVASEV_PLUGIN_URI.'assets/lib/slick/slick/slick.min.js', array('jquery'), false, true );
		wp_enqueue_style( 'owl-carousel', OVASEV_PLUGIN_URI.'assets/lib/owl-carousel/assets/owl.carousel.min.css' );
		wp_enqueue_script( 'owl-carousel', OVASEV_PLUGIN_URI.'assets/lib/owl-carousel/owl.carousel.min.js', array('jquery'), false, true );
		
		return [ 'script-elementor' ];
	}



	protected function _register_controls() {

		$this->start_controls_section(
			'section_setting',
			[
				'label' => __( 'Settings', 'ovaev' ),
			]
		);

		$this->add_control(
			'heading_setting_layout',
			[
				'label' => __( 'Layout', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$this->add_control(
			'version',
			[
				'label' => __( 'Version', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'version_1',
				'options' => [
					'version_1' => esc_html__( 'Version 1', 'ova-framework' ),
					'version_2' => esc_html__( 'Version 2', 'ova-framework' ),
				]
			]
		);	

		

		$this->add_control(
			'type',
			[
				'label' => __( 'Type', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'grid' => __( 'Grid', 'ovaev' ),
					'full_width'  => __( 'Full Width', 'ovaev' ),
				],
			]
		);

		$this->add_responsive_control(
			'filter_align',
			[
				'label' => __( 'Alignment', 'ovaev' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'ovaev' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ovaev' ),
						'icon' => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ovaev' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .ovapo_project_grid .button-filter' => 'justify-content: {{VALUE}}',
				],
				'toggle' => false,
			]
		);


		$this->add_control(
			'heading_setting_post',
			[
				'label' => __( 'Setting Post', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'number_post',
			[
				'label' => __( 'Number Post', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
			]
		);

			$this->add_control(
			'number_items',
			[
				'label' => __( 'Number items', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 2,
			]
		);

		$this->add_control(
			'orderby_post',
			[
				'label' => __( 'OrderBy Post', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date' => __( 'Date', 'ovaev' ),
					'id'  => __( 'ID', 'ovaev' ),
					'title' => __( 'Title', 'ovaev' ),
				],
			]
		);

		$this->add_control(
			'order_post',
			[
				'label' => __( 'Order Post', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC' => __( 'Ascending', 'ovaev' ),
					'DESC'  => __( 'Descending', 'ovaev' ),
				],
			]
		);

		$this->add_control(
			'show_filter',
			[
				'label' => __( 'Show Filter', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ovaev' ),
				'label_off' => __( 'Hide', 'ovaev' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_all',
			[
				'label' => __( 'Show All', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ovaev' ),
				'label_off' => __( 'Hide', 'ovaev' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


		$this->add_control(
			'owl_margin',
			[
				'label' => __( 'Margin', 'evaev' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 30,
			]
		);

		$this->add_control(
			'owl_show_nav',
			[
				'label' => __( 'Show Nav', 'evaev' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);



		$this->add_control(
			'owl_autoplay',
			[
				'label' => __( 'Autoplay', 'evaev' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
			]

		);

		$this->add_control(
			'owl_autoplay_speed',
			[
				'label' => __( 'Autoplay Speed (ms)', 'evaev' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 5000,
				'condition' => [
					'owl_autoplay' => 'yes',
				],
				
			]
		);

		$this->add_control(
			'owl_center',
			[
				'label'   => __( 'Center', 'ova-framework' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'options' => [
					'yes' => __( 'Yes', 'ova-framework' ),
					'no'  => __( 'No', 'ova-framework' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'owl_dot',
			[
				'label'   => __( 'Show Dots', 'ova-framework' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'options' => [
					'yes' => __( 'Yes', 'ova-framework' ),
					'no'  => __( 'No', 'ova-framework' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'owl_loop',
			[
				'label' => __( 'Infinite Loop', 'evaev' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'owl_lazyload',
			[
				'label' => __( 'Lazy Load', 'evaev' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'owl_nav_prev',
			[
				'label' => __( 'Class Nav Prev', 'evaev' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'arrow_carrot-left',
				'placeholder' => 'arrow_carrot-left'
			]
		);

		$this->add_control(
			'owl_nav_next',
			[
				'label' => __( 'Class Nav Next', 'evaev' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'arrow_carrot-right',
				'placeholder' => 'arrow_carrot-right'
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_fillter',
			[
				'label' => __( 'Button Fillter', 'ovaev' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_filter_typo',
				'label' => __( 'Typography', 'ovaev' ),
				'selector' => '{{WRAPPER}} .ovapo_project_grid .button-filter button',
			]
		);

		$this->add_control(
			'button_filter_color',
			[
				'label' => __( 'Color', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ovapo_project_grid .button-filter button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'back_button_filter_color',
			[
				'label' => __( 'Background Color', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ovapo_project_grid .button-filter button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_filter_color_hover',
			[
				'label' => __( 'Color Hover', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ovapo_project_grid .button-filter button:hover' => 'color: {{VALUE}}',
			    ],
			]
		);

			$this->add_control(
			'back_button_filter_color_hover',
			[
				'label' => __( 'Background Color Hover', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ovapo_project_grid .button-filter button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'button_filter_color_active',
			[
				'label' => __( 'Color Active', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ovapo_project_grid .button-filter button.active' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'back_button_filter_color_active',
			[
				'label' => __( 'Background Color Active', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ovapo_project_grid .button-filter button.active' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_filter_padding',
			[
				'label' => __( 'Padding', 'ovaev' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ovapo_project_grid .button-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_content',
			[
				'label' => __( 'Content', 'ovaev' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

	

		$this->add_control(
			'nav_hover_bg_color',
			[
				'label' => __( 'Backgroud Color: Navigation Button Hover', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}}  .ovapo_project_slide .grid .owl-nav button:hover' => 'background-color: {{VALUE}}!important;border-color: {{VALUE}}!important;',
				],
			]
		);	
		$this->add_control(
			'nav_hover_color',
			[
				'label' => __( 'Color: Navigation Button Hover', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}}  .ovapo_project_slide .grid .owl-nav button:hover i:before' => 'color: {{VALUE}}!important;',
					'{{WRAPPER}}  .ovapo_project_slide .grid .owl-nav button:hover' => 'border-color: {{VALUE}}!important;',
				],
			]
		);

		$this->add_control(
			'loading_color',
			[
				'label' => __( 'Color Loading', 'ovaev' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FF0000',
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}}  .ovapo_project_grid .wrap_loader .loader circle' => 'stroke: {{VALUE}}!important;',
				],
			]
		);	

		
		

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings();

		$number_post = $settings['number_post'];
		$order_post = $settings['order_post'];
		$orderby_post = $settings['orderby_post'];
		$type = $settings['type'];
		$show_all = $settings['show_all'];
		$show_filter = $settings['show_filter'];
		$number_items = $settings['number_items'];
		$version = $settings['version'];
        

	

		$args_post = array(
			'post_type' => 'ova_fw',
			'post_status' => 'publish',
			'numberposts'      => $number_post,
			'order' => $order_post,
			'orderby' => $orderby_post,
		);


		$terms = get_posts($args_post);

		$term_id_filter = array();
		foreach ( $terms as $term ) {
			$term_id_filter[] = $term->ID;
		}

		$term_id_filter_string = implode(", ", $term_id_filter);
		$first_term = '';
		if( $terms ){
			$first_term = $terms[0]->ID;	
		}
		
		$args_base = array(
			'post_type' => 'ova_fw',
			'post_status' => 'publish',
		);
	


		if ($show_all !== 'yes' && $first_term != '' ) {
			$args_cat = array(
				'p'=>$first_term,
			);

			$args = array_merge_recursive($args_cat, $args_base);
			$my_posts = new \WP_Query( $args );

		} else {
			$args_cat = array(
				'post__in'=>$term_id_filter,
			);

			$args = array_merge_recursive($args_cat, $args_base);
			$my_posts = new \WP_Query( $args);
		}

		

		$owl_nav_prev = $settings['owl_nav_prev'];
		$owl_nav_next = $settings['owl_nav_next'];
		$owl_show_nav         = ( 'yes' === $settings['owl_show_nav'] ) ? true : false;
		$owl_margin           = $settings['owl_margin'];
		$owl_autoplay         = ( 'yes' === $settings['owl_autoplay'] ) ? true : false;
		$owl_center           = ( 'yes' === $settings['owl_center'] ) ? true : false;
		$owl_dot              = ( 'yes' === $settings['owl_dot'] ) ? true : false;
		$owl_loop             = ( 'yes' === $settings['owl_loop'] ) ? true : false;
		$owl_lazyload         = ( 'yes' === $settings['owl_lazyload'] ) ? true : false;
		$owl_autoplay_speed   = $settings['owl_autoplay_speed'];
		$owl_mouseDrag        = $my_posts->found_posts == 1 ? false : true;

		$data = [
			'margin'          => $owl_margin,
			'dots'            => $owl_dot,
			'nav'             => $owl_show_nav,
			'autoplay'        => $owl_autoplay,
			'autoplayTimeout' => $owl_autoplay_speed,
			'loop'            => $owl_loop,
			'center'          => $owl_center,
			'lazyLoad'        => $owl_lazyload,
			'mouseDrag'       => $owl_mouseDrag,
			 'slideBy'         => 1,
			'navText' => [
				'<i class="'.$owl_nav_prev.'"></i>',
				'<i class="'.$owl_nav_next.'"></i>'
			],
			'responsive' => [
				'0'  => [
					'items'  => 1,
				],
				'414'=>[
		              'items' => 1,

		            ],
		        '736'=>[
		              'items' => 1,

		            ],

				'992'  => [
					'items'  => 2,
					// 'dots' => $owl_show_dots_mobile,
				],
				'1170'  => [
					'items'  => $number_items,
				]
			]
		];


		?>
		<?php if( $my_posts->have_posts() ): ?>
			

			<div class="ovapo_project_grid <?php echo esc_attr($type); ?> <?php echo esc_attr($version); ?>">
				<?php if ($show_filter == 'yes') { ?>
					<div class="button-filter <?php echo esc_attr($type == 'full_width' ? 'container' : '' );?> ">
						<?php if ($show_all == 'yes') { ?>
							<button data-filter="<?php echo esc_attr( 'all' ); ?>" data-order="<?php echo esc_attr($order_post); ?>" data-orderby="<?php echo esc_attr($orderby_post); ?>" data-first_term="<?php echo esc_attr($first_term); ?>" data-term_id_filter_string="<?php echo esc_attr($term_id_filter_string); ?>" data-number_post="<?php echo esc_attr($number_post); ?>"   class="second_font" >
								<?php esc_html_e( 'All', 'ovaev' ); ?>
							</button>
						<?php } ?>

						<?php 
							foreach ( $terms as $term ) { ?>
								<button data-filter="<?php echo esc_attr($term->ID); ?>" data-order="<?php echo esc_attr($order_post); ?>" data-orderby="<?php echo esc_attr($orderby_post); ?>" data-first_term="<?php echo esc_attr($first_term); ?>" data-term_id_filter_string="<?php echo esc_attr($term_id_filter_string); ?>" data-number_post="<?php echo esc_attr($number_post); ?>"   class="second_font" 
									>
									<?php esc_html_e( $term->post_title, 'ovaev' ); ?>
								</button>
							<?php }
						?>
					</div>
				<?php } ?>
				
				<div class="content ovapo_project_slide">
					<div  class="items grid owl-carousel owl-theme" data-owl="<?php echo esc_attr(wp_json_encode( $data )); ?>">
						<?php while( $my_posts->have_posts() ) : $my_posts->the_post(); 

							$id = get_the_ID();
							$ova_met_gallery = get_post_meta( $id, 'ova_met_gallery', true ) ? get_post_meta( $id, 'ova_met_gallery', true ) : '';
							$id2="1";
							$title = get_the_title($id);
						
						

							?>
						
							

								<?php if ( $ova_met_gallery ) {
									foreach ( $ova_met_gallery  as $key => $value ) { ?>
										<div class="wrap_item">
											<a href="<?php echo esc_attr( $value ); ?>" data-fancybox="<?php echo esc_attr( $id2 ); ?>" class="item">
												<div class="content_item">
												<img src="<?php echo esc_attr( $value ); ?>" alt="<?php echo esc_attr( $key ); ?>">
												<div class="content_item_2">

													<div class="title second_font">

														<?php echo $title ?>

													</div>
													<div class="category">
														<?php get_category_fw_by_id_fw( $id ) ?>
													</div>
											
												</div>

													<div class="readmore">

														<i data-feather="plus"></i>

													</div>
												</div>

							
											</a>

										</div>
									<?php }

								} ?>
							

						<?php endwhile ?>
					</div>

		    

					
				</div>

				<div class="wrap_loader">
						<svg class="loader" width="50" height="50">
							<circle cx="25" cy="25" r="10" stroke="#a1a1a1"/>
							<circle cx="25" cy="25" r="20" stroke="#a1a1a1"/>
						</svg>
					</div>

			</div>

		<?php else : 
			?>
			<div class="search_not_found">
				<?php esc_html_e( 'Not Found Project', 'ovaev' ); ?>
			</div>
		<?php endif ?>
		<?php
	}
}
?>
