<?php 
defined( 'ABSPATH' ) || exit();

if( !class_exists( 'OVASEV_assets' ) ){
	class OVASEV_assets{

		public function __construct(){

			add_action( 'wp_enqueue_scripts', array( $this, 'ovasev_enqueue_scripts' ), 10, 0 );

			/* Add JS for Elementor */
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'ova_enqueue_scripts_elementor_sev' ) );

		}



		public function ovasev_enqueue_scripts(){
			wp_enqueue_script( 'fancybox',  OVASEV_PLUGIN_URI.'assets/lib/fancybox-master/dist/jquery.fancybox.min.js',  array( 'jquery' ), null, true );



			wp_enqueue_style( 'fancybox',  OVASEV_PLUGIN_URI.'assets/lib/fancybox-master/dist/jquery.fancybox.min.css', array(), null );

			// Init Css
			wp_enqueue_style( 'ovasev_style', OVASEV_PLUGIN_URI.'assets/css/frontend/ovasev-style.css' );	

			// Init Js
			wp_enqueue_script( 'ovasev_script', OVASEV_PLUGIN_URI.'assets/js/frontend/ovasev-script.js' );			

		}

		// Add JS for elementor
		public function ova_enqueue_scripts_elementor_sev(){
			wp_enqueue_script( 'script-elementor-sev', OVASEV_PLUGIN_URI. 'assets/js/script-elementor.js', [ 'jquery' ], false, true );
		}


	}
	new OVASEV_assets();
}
