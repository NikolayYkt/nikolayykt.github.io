<?php if ( !defined( 'ABSPATH' ) ) exit();

$category = $args['category'];
$show_icon = $args['show_icon'];
$show_title = $args['show_title'];
$show_title2 = $args['show_title2'];
$text = $args['text'];

$data_options['items']              = $args['item_number'];
$data_options['slideBy']            = $args['slides_to_scroll'];
$data_options['margin']             = $args['margin_items'];
$data_options['autoplayHoverPause'] = $args['pause_on_hover'] === 'yes' ? true : false;
$data_options['loop']               = $args['infinite'] === 'yes' ? true : false;
$data_options['autoplay']           = $args['autoplay'] === 'yes' ? true : false;
$data_options['autoplayTimeout']    = $args['autoplay_speed'];
$data_options['smartSpeed']         = $args['smartspeed'];
$data_options['dots']               = $args['dot_control'] === 'yes' ? true : false;

if( $category == 'all' ){
	$args= array(
		'post_type' => 'ova_sev',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'meta_key' => 'ova_sev_met_order_sev',
		'meta_type' => 'NUMERIC', 
        'orderby' => 'meta_value_num',
        'order'   => "ASC",
	);
} else {
	$args= array(
		'post_type' => 'ova_sev',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'meta_key' => 'ova_sev_met_order_sev',
		'meta_type' => 'NUMERIC', 
        'orderby' => 'meta_value_num',
        'order'   => "ASC",
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_sev',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$deps  = new \WP_Query($args);


?>

<div class="ova_archive_sev archive_sev " >
	<div class="content ova_sev_slide owl-carousel owl-theme" data-options="<?php echo esc_attr(json_encode($data_options)) ?>">
		<?php if( $deps->have_posts() ) : while ( $deps->have_posts() ) : $deps->the_post(); ?>
				<?php 

					$id = get_the_id();

					$class_icon = get_post_meta( $id, 'ova_sev_met_class_icon', true );
					$title = get_the_title();
					$thumbnail = get_the_post_thumbnail( $id, 'large', array('class'=> 'img-responsive' ));
					$url_img = get_the_post_thumbnail_url( $id, 'full' );
					$title2 = get_post_meta( $id, 'ova_sev_met_title', true );

					?>

		
					<div  class="items elementor-items" >


						<div class="content_img_items">
							<img src="<?php echo esc_url( $url_img) ?>">


							<div class = "content_sub_items">
								<div class="content_items">


									<?php if( $show_icon === 'yes' ){ ?>
										<div class="icon">

											<span class="<?php echo esc_attr( $class_icon ) ?>"></span>

										</div>
									<?php } ?>

									<?php if( $show_title === 'yes' ){ ?>
										<h2 class="title second_font">

											<?php echo $title ?>

										</h2>
									<?php } ?>

									<div class="content-sub">
										<?php if( $show_title2 === 'yes' )  { ?>
											<div class=" excerpt">
												<?php echo esc_html( $title2 ) ?>
											</div>
										<?php } ?>

										<?php if ( ! empty( $text ) ){ ?>

											<a class="readmore second_font " href="<?php echo get_the_permalink() ?>"  ><i class="flaticon-arrows"></i><?php echo esc_html( $text ) ?></a>

										<?php } ?>
									</div>
								</div>
							</div>


						</div>





					</div>
		
		<?php endwhile; endif; wp_reset_postdata(); ?>
	</div>

</div>

<?php 
