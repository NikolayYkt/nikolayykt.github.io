<?php if ( !defined( 'ABSPATH' ) ) exit();

$id = get_the_ID();
$date = get_post_meta( $id, 'ova_por_met_date', true );
$location = get_post_meta( $id, 'ova_por_met_location', true );
$service = get_post_meta( $id, 'ova_por_met_service', true );

?>
<div class="info-por">
	<div class="content-info">
		<div class="category">
			<label class="second_font"><?php esc_html_e( 'Category', 'ova-por' ) ?></label>
			<?php get_category_por_by_id_por( $id ) ?>
		</div>
		<div class="date">
			<label class="second_font"><?php esc_html_e( 'Date', 'ova-por' ) ?></label>
			<span><?php echo esc_html( $date ) ?></span>
		</div>

		<div class="location">
			<label class="second_font"><?php esc_html_e( 'Location', 'ova-por' ) ?></label>
			<span><?php echo esc_html( $location ) ?></span>
		</div>

		<div class="service">
			<label class="second_font"><?php esc_html_e( 'Service', 'ova-por' ) ?></label>
			<span><?php echo esc_html( $service ) ?></span>
		</div>
	</div>
</div>