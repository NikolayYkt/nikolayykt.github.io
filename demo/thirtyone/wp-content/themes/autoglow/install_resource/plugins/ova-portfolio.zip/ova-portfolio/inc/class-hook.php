<?php if ( !defined( 'ABSPATH' ) ) exit();

// Single portfolio gallery
add_action( 'ova_single_port_gallery', 'ova_single_port_gallery_item', 10 );
function ova_single_port_gallery_item(){
    return ovapor_get_template( 'single/gallery.php' );
}

// Single portfolio info
add_action( 'ova_single_port_info', 'ova_single_port_info_item', 10 );
function ova_single_port_info_item(){
    return ovapor_get_template( 'single/info.php' );
}

// Single portfolio share social
add_action( 'ova_single_port_share_social', 'ova_single_port_share_social', 10 );
function ova_single_port_share_social(){
    return ovapor_get_template( 'single/share_social.php' );
}

// Single portfolio share social
add_action( 'ova_single_port_next_pre_post', 'ova_single_port_next_pre_post', 10 );
function ova_single_port_next_pre_post(){
    return ovapor_get_template( 'single/next_pre_post.php' );
}


// Archive portfolio list category
add_action( 'ova_archive_port_list_cat', 'ova_archive_port_list_cat', 10 );
function ova_archive_port_list_cat(){
    return ovapor_get_template( 'archive/list_cat.php' );
}

// Archive portfolio load more
add_action( 'ova_archive_port_load_more', 'ova_archive_port_load_more', 10 );
function ova_archive_port_load_more(){
    return ovapor_get_template( 'archive/load_more.php' );
}