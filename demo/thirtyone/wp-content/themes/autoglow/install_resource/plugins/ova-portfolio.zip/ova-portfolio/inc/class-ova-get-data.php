<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

function get_portfolio_related_by_id( $id_por ){

	$terms_cat = get_the_terms( $id_por, 'cat_por' );

    $arr_cat = [];
    if( $terms_cat ){
        foreach( $terms_cat as $cat ){
            $arr_cat[] = $cat->term_id;
        }
    }
	$args_related = array(
        'post_type' => 'ova_por',
        'posts_per_page' => 3,
        'post__not_in' => array( $id_por ),
        'tax_query' => array(
            array(
                'taxonomy' => 'cat_por',
                'field'    => 'term_id',
                'terms'    => $arr_cat,
            ),
        ),
    );
    $portfolio_related = get_posts( $args_related );
	?>
	<?php if( $portfolio_related ){ ?>
	<div class="wrap-related-por">
		<div class="related-por-inner">
			<h3 class="title-related">
				<?php esc_html_e( 'Related Projects', 'ova-por' ) ?>
			</h3>
			<div class="related-por">
				<?php foreach( $portfolio_related as $related ){ 

					$id = $related->ID;
					$url_img = get_the_post_thumbnail_url( $id, 'post-thumbnail' );
					$title = get_the_title( $id );
					$link = get_the_permalink( $id );

					$cat_por = get_cat_id_por_by_id_por( $id );

					?>
					<div class="ovapor-item <?php echo esc_attr( $cat_por ) ?>">
					<?php if( $url_img ){ ?>
						<a href="<?php echo esc_url( $link ) ?>" >
							<img src="<?php echo esc_url( $url_img ) ?>" alt="<?php echo $title ?>">
						</a>
						<div class="content-item">
							<div class="sub-content">
								<h2 class="title">
									<a class="second_font" href="<?php echo $link ?>">
										<?php echo $title ?>
									</a>
								</h2>
								<div class="category second_font">
									<?php get_category_por_by_id_por( $id ) ?>
								</div>
							</div>
							<div class="readmore">
								<a href="<?php echo $link ?>">
									<i data-feather="arrow-right"></i>
								</a>
							</div>
						</div>
					
					<?php } ?>
				</div>
				<?php } ?>
				
			</div>
		</div>
	</div>
	<?php 
	}  
	wp_reset_postdata();
}

add_action( 'pre_get_posts', 'ova_por_post_per_page_archive' );
function ova_por_post_per_page_archive( $query ) {
	if ( ( is_post_type_archive( 'ova_por' )  && !is_admin() )  || ( is_tax('cat_por') && !is_admin() ) ) {
		if( $query->is_post_type_archive( 'ova_por' ) || $query->is_tax('cat_por') ) {
			$query->set('post_type', array( 'ova_por' ) );
			$query->set('posts_per_page', get_theme_mod( 'ova_por_total_record', 9 ) );
		}
	}
}

function get_category_por_by_id_por( $id = '' ){

	if( $id === '' ) return;

	$cat_pors = get_the_terms( $id, 'cat_por' );
	$i = 0;

	if( ! empty( $cat_pors ) ){
		$count_cat = count( $cat_pors );

		foreach ($cat_pors as $cat_por) {
			$i++;
			$separator = ( $count_cat !== $i ) ? "," : "";

			$link = get_term_link($cat_por->term_id);
			$name = $cat_por->name;
			?>
				<span class="cat-por">
					<a href="<?php echo esc_url( $link ) ?>"><?php echo esc_html( $name ) ?></a>
				</span>
				<span class="separator">
					<?php echo esc_html( $separator ) ?>
				</span>

			<?php
		}
	}
}

function get_cat_id_por_by_id_por( $id_por = '' ){

	if( $id_por === '' ) return;

	$cat_pors = get_the_terms( $id_por, 'cat_por' );
	$i = 0;

	$cat_id = '';
	if( ! empty( $cat_pors ) ){
		$count_cat = count( $cat_pors );
		?>
		<?php
		foreach ($cat_pors as $cat_por) {
			$i++;
			$separator = ( $count_cat !== $i ) ? " " : "";

			$name = $cat_por->name;
			$term_id = $cat_por->term_id;

			$cat_id .= $term_id  . $separator;
		}
	}

	return $cat_id;
}

function ova_por_get_icon_attachment_file( $ext_file = '' ){
	if( $ext_file == '' ) return '<i class="flaticon-file-2"></i>';

	if( $ext_file === 'docx' || $ext_file === 'doc' ){
		$icon = '<i class="flaticon-doc"></i>';
	} elseif( $ext_file === 'jpg' || $ext_file === 'gif' || $ext_file === 'png' ){
		$icon = '<i class="flaticon-file-5"></i>';
	} elseif( $ext_file === 'pdf' ){
		$icon = '<i class="flaticon-pdf"></i>';
	} else{
		$icon = '<i class="flaticon-file-2"></i>';
	}

	return $icon;
}

function ova_por_get_file_size( $url_file = '' ){
	if( $url_file === '' ) return;
	$upload_dir = wp_upload_dir();
	$path_upload_full = $upload_dir['path'];

	$path_upload_sub = substr( $path_upload_full, 0, strpos( $path_upload_full, 'wp-content/uploads' ) );


	$position = strpos( $url_file, 'wp-content/uploads' );
	$sub_str = substr( $url_file, $position );
	$path_file = $path_upload_sub . $sub_str;

	$file_size_byte = filesize( $path_file );
	$file_size_kb = $file_size_byte * 0.0009765625;
	$file_size_kb = round( $file_size_kb );

	return $file_size_kb;
}
