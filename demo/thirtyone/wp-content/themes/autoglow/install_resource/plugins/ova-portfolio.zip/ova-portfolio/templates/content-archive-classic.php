<?php if ( !defined( 'ABSPATH' ) ) exit();

if( have_posts() ) : while ( have_posts() ) : the_post(); 
	$id = get_the_id();

	$url_img = get_the_post_thumbnail_url( $id, 'post-thumbnail' );
	$title = get_the_title( $id );
	$link = get_the_permalink( $id );

	$cat_por = get_cat_id_por_by_id_por( $id );

	$gallery = get_post_meta( $id, 'ova_por_met_gallery', true );


?>
<div class="ovapor-item <?php echo esc_attr( $cat_por ) ?>">
	<?php if( $url_img ){ ?>
		<a href="<?php echo esc_url( $link ) ?>" >
			<img src="<?php echo esc_url( $url_img ) ?>" alt="<?php echo $title ?>">
		</a>
		<div class="content-item">
			<div class="sub-content">
				<h2 class="title">
					<a class="second_font" href="<?php echo $link ?>">
						<?php echo $title ?>
					</a>
				</h2>
				<div class="category second_font">
					<?php get_category_por_by_id_por( $id ) ?>
				</div>
			</div>
			<div class="readmore">
				<a href="<?php echo $link ?>">
					<i data-feather="arrow-right"></i>
				</a>
			</div>
		</div>
	
	<?php } ?>
</div>

<?php endwhile; endif; wp_reset_postdata(); ?>