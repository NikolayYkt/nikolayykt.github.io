<?php if ( !defined( 'ABSPATH' ) ) exit();

$args = array(
   'taxonomy' => 'cat_por',
   'orderby' => 'name',
   'order'   => 'ASC'
);

$categories = get_categories($args);

$term_id = get_queried_object_id();
$class_active_all = $term_id == 0 ? 'active' : '';

?>
<?php if( $term_id == 0 ){ ?>
<ul class="list-cat-por">
	<li data-filter="*" class="<?php echo esc_attr( $class_active_all ) ?>"><a class="second_font" href="<?php echo esc_url( get_post_type_archive_link( 'ova_por' ) ) ?>"><?php echo esc_html__( 'All', 'ova-por' ) ?></a></li>
<?php
	if ($categories) {
		foreach ( $categories as $cate ) {

			$class_active = ( $term_id == $cate->term_id ) ? 'active' : '';
			?>
			<li data-filter=".<?php echo esc_attr( $cate->term_id ) ?>" class="<?php echo esc_attr( $class_active ) ?>">
				<a class="second_font" href="">
					<?php echo esc_html( $cate->cat_name ) ?>
				</a>
			</li>
			<?php									
		}
	}
?>
</ul>
<?php } ?>