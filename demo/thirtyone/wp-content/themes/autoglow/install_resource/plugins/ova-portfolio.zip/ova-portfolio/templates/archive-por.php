<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header();
$type = isset( $_GET['archive_type_portfolio'] ) ? sanitize_text_field( $_GET['archive_type_portfolio'] ) : '';

$type = $type != '' ? $type : get_theme_mod( 'ova_por_archive_type', 'classic' );

$number_column = get_theme_mod( 'ova_por_layout', 'three_column' );

?>

<div class="wrap-portfolio">
	<div class="archive-por">

		<?php 
			/**
			 * action ova_archive_port_list_cat
			 * Hooked ova_archive_port_list_cat
			 */
			do_action( 'ova_archive_port_list_cat' ); 
		?>

		<div class="content-por <?php echo esc_attr( $number_column ) ?> <?php echo $type ?>-portfolio">

			<?php
			if( $type == 'classic' ){
				ovapor_get_template( 'content-archive-classic.php' );
			}else if( $type == 'gallery' ) {
				ovapor_get_template( 'content-archive-gallery.php' );
			} else if( $type == 'grid' ) {
				ovapor_get_template( 'content-archive-grid.php' );
			}
			?>

		</div>

		<?php 
			/**
			 * action ova_archive_port_load_more
			 * Hooked ova_archive_port_load_more
			 */
			do_action( 'ova_archive_port_load_more' ); 
		?>


	</div>
	
</div>

<?php

get_footer();