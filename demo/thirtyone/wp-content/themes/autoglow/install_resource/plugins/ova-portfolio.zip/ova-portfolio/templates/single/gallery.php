<?php if ( !defined( 'ABSPATH' ) ) exit();

$id = get_the_ID();

$gallery = get_post_meta( $id, 'ova_por_met_gallery', true );

if( ! empty( $gallery ) ) { ?>
	<div class="por-gallery">
		<?php foreach( $gallery as $val ) { ?>
			<div class="item-gallery">
				<a href="<?php echo esc_url( $val ) ?>" data-fancybox="1">
					<span class="search">
						<i class="icon_search"></i>
					</span>
					<img src="<?php echo esc_url( $val ) ?>" alt="">
				</a>
			</div>
		<?php } ?>
	</div>
<?php } ?>