<?php if ( !defined( 'ABSPATH' ) ) exit();
if( have_posts() ) : while ( have_posts() ) : the_post(); 
	$id = get_the_id();

	$url_img = get_the_post_thumbnail_url( $id, 'post-thumbnail' );
	$title = get_the_title( $id );
	$link = get_the_permalink( $id );

	$cat_por = get_cat_id_por_by_id_por( $id );

	$gallery = get_post_meta( $id, 'ova_por_met_gallery', true );
	


?>
<div class="ovapor-item <?php echo esc_attr( $cat_por ) ?>">
	<?php if( $url_img ) { ?>
		<a href="<?php echo esc_url( $link ) ?>">
			<span class="search">
				<i class="icon_search"></i>
			</span>
			<img src="<?php echo esc_url( $url_img ) ?>" alt="<?php echo $title ?>">
		</a>
	<?php } ?>
</div>

<?php endwhile; endif; wp_reset_postdata(); ?>