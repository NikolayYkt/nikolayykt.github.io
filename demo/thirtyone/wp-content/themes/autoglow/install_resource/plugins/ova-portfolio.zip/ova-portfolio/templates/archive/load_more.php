<?php if ( !defined( 'ABSPATH' ) ) exit();

$type = isset( $_GET['archive_type_portfolio'] ) ? sanitize_text_field( $_GET['archive_type_portfolio'] ) : '';

$term_id = get_queried_object_id();
$post_per_page = get_theme_mod( 'ova_por_total_record', 9 );

?>
<div class="ova_more_por" data-paged="2"  data-perpage="<?php echo esc_attr($post_per_page); ?>" data-cat="<?php echo esc_attr( $term_id ) ?>" >
    <span class="ova-load-more-por ova_button second_font type1 medium"><?php echo esc_html__('Load More','ova-por'); ?></span>
    <div class="ova-loader"></div> 
</div>
<div class="ova-nodata ">
	<span class="ova_button second_font type1 medium"><?php echo esc_html__('No Data','ova-por'); ?></span>
</div>