<?php
global $post;

$id = get_the_ID();


?>

<div class="wrap-portfolio">
	<div class="single-por type1">

		<?php 
			/**
			 * action ova_single_port_gallery
			 * Hooked ova_single_port_gallery_item
			 */
			do_action( 'ova_single_port_gallery' ); 
		?>

		
		<div class="wrap-content-por">
			<div class="content">
				<?php if( have_posts() ) : while( have_posts() ) : the_post();
					the_content();
				?>
				<?php endwhile; endif; wp_reset_postdata(); ?>
			</div>

			<?php 
				/**
				 * action ova_single_port_info
				 * Hooked ova_single_port_info_item
				 */
				do_action( 'ova_single_port_info' ); 
			?>
			
		</div>
		<div class="single-foot-por">

			<?php 
				/**
				 * action ova_single_port_share_social
				 * Hooked ova_single_port_share_social
				 */
				do_action( 'ova_single_port_share_social' ); 
			?>


			<?php 
				/**
				 * action ova_single_port_next_pre_post
				 * Hooked ova_single_port_next_pre_post
				 */
				do_action( 'ova_single_port_next_pre_post' ); 
			?>
			
		</div>
	</div>
</div>

<?php
	get_portfolio_related_by_id( $id );
?>
