<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class Ova_get_data {
	public function __construct() {

		add_action('wp_ajax_ova_loadmore_portfolio', array( $this, 'ova_loadmore_portfolio' ), 10 , 0 );
		add_action('wp_ajax_nopriv_ova_loadmore_portfolio', array( $this, 'ova_loadmore_portfolio' ), 10, 0 );
	}

	public function ova_loadmore_portfolio(){

		$paged     = isset( $_POST['paged'] ) ? sanitize_text_field( $_POST['paged'] ) : 1;
		$perpage   = isset( $_POST['perpage'] ) ? sanitize_text_field( $_POST['perpage'] ) : 6;

		$cat = isset( $_POST['cat'] ) ? sanitize_text_field( $_POST['cat'] ) : 0;
		$type = isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : '';

		if( $cat != 0 ){
			$args = array(
			    'post_type'   => 'ova_por',
			    'posts_per_page' => $perpage,
			    'paged'          => $paged,
			    'post_status' => array( 'publish' ),
			    'tax_query' => array(
			        array(
			            'taxonomy' => 'cat_por',
			            'field'    => 'id',
			            'terms'    => $cat, 
			        ),
			    ),
			);
		} else{
			$args = array(
			    'post_type'   => 'ova_por',
			    'posts_per_page' => $perpage,
			    'paged'          => $paged,
			    'post_status' => array( 'publish' ),
			);
		}
		

		$list_portfolios = get_posts( $args );

		if ( $list_portfolios ) {			
				foreach( $list_portfolios as $portfolio ){

					$id = $portfolio->ID;

					$url_img = get_the_post_thumbnail_url( $id, 'post-thumbnail' );
					$title = get_the_title( $id );
					$link = get_the_permalink( $id );

					$cat_por = get_cat_id_por_by_id_por( $id );

					$gallery = get_post_meta( $id, 'ova_por_met_gallery', true );
			?>
			<div class="ovapor-item <?php echo esc_attr( $cat_por ) ?> ">
				
				<?php if( $url_img ){ ?>
					<a href="<?php echo esc_url( $link) ?>"  >
						<span class="search">
							<i class="icon_search"></i>
						</span>
						<img src="<?php echo esc_url( $url_img ) ?>" alt="<?php echo $title ?>">
					</a>
					<div class="content-item">
						<div class="sub-content">
							<h2 class="title">
								<a class="second_font" href="<?php echo $link ?>">
									<?php echo $title ?>
								</a>
							</h2>
							<div class="category second_font">
								<?php get_category_por_by_id_por( $id ) ?>
							</div>
						</div>
						<div class="readmore">
							<a href="<?php echo $link ?>">
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
							</a>
						</div>
					</div>
				
				<?php } ?>
				
			</div>

			<?php 
			} 
			wp_reset_postdata(); 

			
		} else {
			echo 'no_product';
			wp_die();
		}

		wp_die();
	}
}
new Ova_get_data();