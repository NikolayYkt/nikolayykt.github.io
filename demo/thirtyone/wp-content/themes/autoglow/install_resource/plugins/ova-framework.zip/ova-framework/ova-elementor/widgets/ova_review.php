<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_review extends Widget_Base {

	public function get_name() {
		return 'ova_review';
	}

	public function get_title() {
		return __( 'Ova Review', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-review';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$this->add_control(
				'name_author',
				[
					'label'   => 'Author Name',
					'type'    => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Donald Salvor', 'ova-framework' ),
				]
			);

			$this->add_control(
				'job',
				[
					'label'   => 'Job',
					'type'    => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Citizen Of Omina', 'ova-framework' ),
				]
			);

			$this->add_control(
				'image_author',
				[
					'label'   => 'Author Image',
					'type'    => \Elementor\Controls_Manager::MEDIA,
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);

			$this->add_control(
				'description',
				[
					'label'   => __( 'Description ', 'ova-framework' ),
					'type'    => \Elementor\Controls_Manager::TEXTAREA,
					'default' => __( '"Sed ullamcorper morbi tincidunt or massa eget egestas purus. Non nisi est sit amet facilisis magna etiam."', 'ova-framework' ),
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'General', 'ova-framework' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'quote_color',
				[
					'label'     => __( 'Quote Job', 'ova-framework' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-review .client_info .icon-quote span:before' => 'color : {{VALUE}};',
						
					],
				]
			);

			$this->add_responsive_control(
				'review_padding',
				[
					'label'      => __( 'Padding', 'ova-framework' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-review .client_info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_author_name',
			[
				'label' => __( 'Author Name', 'ova-framework' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'author_name_typography',
					'selector' => '{{WRAPPER}} .ova-review .client_info .info .name-job .name',
					'scheme'   => Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'author_name_color',
				[
					'label'     => __( 'Color Author', 'ova-framework' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-review .client_info .info .name-job .name' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'author_name_margin',
				[
					'label'      => __( 'Margin', 'ova-framework' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-review .client_info .info .name-job .name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'author_name_padding',
				[
					'label'      => __( 'Padding', 'ova-framework' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-review .client_info .info .name-job .name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();


		$this->start_controls_section(
			'section_job',
			[
				'label' => __( 'Job', 'ova-framework' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'job_typography',
					'selector' => '{{WRAPPER}} .ova-review .client_info .info .name-job .job',
					'scheme'   => Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'job_color',
				[
					'label'     => __( 'Color Job', 'ova-framework' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-review .client_info .info .name-job .job' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'job_margin',
				[
					'label'      => __( 'Margin', 'ova-framework' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-review .client_info .info .name-job .job' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'job_padding',
				[
					'label'      => __( 'Padding', 'ova-framework' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-review .client_info .info .name-job .job' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();	

		?>

		<div class="ova-review">
			<div class="client_info">
				
				<?php if( $settings['description'] != '' ) : ?>
					<p class="evaluate"><?php echo esc_html($settings['description']) ?></p>
				<?php endif; ?>
				<div class="info">
					<div class="client">
						<?php if( $settings['image_author'] != '' ): ?>
							<img src="<?php echo esc_attr($settings['image_author']['url']) ?>" alt="">
						<?php endif; ?>
					</div>
					<div class="name-job">
						<?php if( $settings['name_author'] != '' ): ?>
							<p class="name second_font"><?php echo esc_html($settings['name_author']) ?></p>
						<?php endif; ?>

						<?php if( $settings['job'] != '' ): ?>
							<p class="job"><?php echo esc_html($settings['job']) ?></p>
						<?php endif; ?>
					</div>
				</div>
				<!-- end info -->
				<div class="icon-quote">
					<span class="flaticon-left-quote-1"></span>
				</div>
			</div>
		</div>
		
		<?php
	}
	// end render
}


