<?php defined( 'ABSPATH' ) || exit;

if( !class_exists( 'ova_shortcode_need_any_help' ) ) {

	class ova_shortcode_need_any_help {

		public $shortcode = 'ova_need_any_help';

		public function __construct() {
			//add shortcode
			add_shortcode( $this->shortcode, array( $this, 'init_shortcode' ) );
		}

		function init_shortcode( $args, $content = null ) {

			if ( !empty($args) ) {
				$args = [
					'class_icon' => isset($args['class_icon']) ? $args['class_icon'] : '',
					'title' 	 => isset($args['title']) ? $args['title'] : '',
					'des' 		 => isset($args['description']) ? $args['description'] : '',
					'url_img' 	 => isset($args['url_img']) ? $args['url_img'] : '',
					'title_btn'  => isset($args['button']) ? $args['button'] : '',
					'link_btn' 	 => isset($args['link']) ? $args['link'] : '',
				];
			} else {
				$args = [
					'class_icon' => '',
					'title' 	 => '',
					'des' 		 => '',
					'url_img' 	 => '',
					'title_btn'  => '',
					'link_btn' 	 => '',
				];
			}

			?>
				<?php if ( !empty($args) ): ?>
					<div class="shortcode-need-any-help">
						<div class="clear"></div>
						<div class="content-shortcode" style="background-image:url(<?php echo esc_html( $args['url_img'] ); ?>);">
							<?php if ( !empty($args['class_icon']) ): ?>
								<div class="class-icon">
									<i class="<?php echo esc_html( $args['class_icon'] ); ?>"></i>
								</div>
							<?php endif; ?>
							<?php if ( !empty($args['title']) ): ?>
								<h3 class="title"><?php echo esc_html( $args['title'] ); ?></h3>
							<?php endif; ?>
							<?php if ( !empty($args['des']) ): ?>
								<p class="description"><?php echo esc_html( $args['des'] ); ?></p>
							<?php endif; ?>
							<?php if ( !empty($args['title_btn']) ): ?>
								<a href="<?php echo esc_html( $args['link_btn'] ); ?>" class="btn">
									<?php echo esc_html( $args['title_btn'] ); ?>		
								</a>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>

			<?php
		}
	}

	new ova_shortcode_need_any_help();

}
