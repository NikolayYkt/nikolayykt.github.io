<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_button extends Widget_Base {

	public function get_name() {
		return 'ova_button';
	}

	public function get_title() {
		return __( 'Ova Button', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);


		$this->add_control(
			'text',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'Learn More', 'ova-framework' ),
				'placeholder' => __( 'Learn More', 'ova-framework' ),
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
				'default' => [
					'url' => '#',
				],
			]
		);

		$this->add_control(
			'type',
			[
				'label' => __( 'Type', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'type1',
				'options' => [
					'type1' => "Type 1",
					'type2' => "Type 2",
					'type3' => "Type 3",
					'type4' => "Type 4",
				]
			]
		);

		$this->add_control(
			'size',
			[
				'label' => __( 'Size', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'medium',
				'options' => [
					'tiny' => "Tiny",
					'small' => "Small",
					'medium' => "Medium",
					'large' => "Large",
				]
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .wrap_ova_button' => 'text-align: {{VALUE}}',
				]
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Button', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_button',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);


		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => __( 'Normal', 'elementor' ),
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label' => __( 'Text Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .ova_button' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type3' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,

				'selectors' => [
					'{{WRAPPER}} .ova_button' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type2' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type3' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type4' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => __( 'Hover', 'elementor' ),
			]
		);

		$this->add_control(
			'hover_color',
			[
				'label' => __( 'Text Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_button:hover, {{WRAPPER}} .ova_button:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_background_hover_color',
			[
				'label' => __( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_button:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type2:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type3:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type4:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label' => __( 'Border Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .ova_button:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type2:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type3:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type4:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .ova_button',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_responsive_control(
			'text_padding',
			[
				'label' => __( 'Padding', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();


	}

	protected function render() {
		$settings = $this->get_settings();

		$text = $settings['text'];

		$target = $settings['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';
	
		?>
		<div class="wrap_ova_button">
			<a class="ova_button second_font <?php echo $settings['type'] . ' ' . $settings['size'] ?>" href="<?php echo $settings['link']['url'] ?>" <?php echo $target . ' ' . $nofollow ?> ><?php echo esc_html( $text ) ?></a>
		</div>

		<?php

	}
}


