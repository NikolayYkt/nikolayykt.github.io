<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_contact extends Widget_Base {

	public function get_name() {
		return 'ova_contact';
	}

	public function get_title() {
		return __( 'Ova Contact', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-headphones';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$this->add_control(
                'image',
                [
                    'label' => __( 'Choose Image', 'ova_framework' ),
                    'type' 	=> Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' 		=> 'image',
                    'default' 	=> 'large',
                    'separator' => 'none',
                ]
            );

			$this->add_control(
                'class_icon',
                [
                    'label'   => __( 'Icon Class', 'ova_framework' ),
                    'type' 	  => Controls_Manager::TEXT,
                    'default' => 'flaticon-support',
                ]
            );

            $this->add_control(
                'text',
                [
                    'label'   => __( 'Text', 'ova_framework' ),
                    'type' 	  => Controls_Manager::TEXT,
                    'default' => __( '24 HOURS SERVICE AVAILABLE', 'ova-framework' ),
                ]
            );

            $this->add_control(
                'title',
                [
                    'label'   => __( 'Title', 'ova_framework' ),
                    'type' 	  => Controls_Manager::TEXT,
                    'default' => __( 'Call our booking:', 'ova-framework' ),
                ]
            );

            $this->add_control(
                'phone_number',
                [
                    'label'   => __( 'Phone Number', 'ova_framework' ),
                    'type' 	  => Controls_Manager::TEXT,
                    'default' => '666 888 0000',
                ]
            );

            $this->add_control(
                'phone_link',
                [
                    'label'   => __( 'Link Phone', 'ova_framework' ),
                    'type' 	  => Controls_Manager::TEXT,
                    'default' => 'tel:666 888 0000',
                ]
            );

		$this->end_controls_section();
		
		/**
		 * Section icon style
		 */
		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
	            'icon_bg',
	            [
	                'label' 	=> __( 'Background', 'ova_framework' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova_contact .content_left .icon' => 'background-color: {{VALUE}}',
	                ],
	            ]
	        );

	        $this->add_control(
	            'icon_color',
	            [
	                'label' 	=> __( 'Color', 'ova_framework' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova_contact .content_left .icon i' => 'color: {{VALUE}}',
	                ],
	            ]
	        );

	        $this->add_responsive_control(
	            'icon_size',
	            [
	                'label' 	 => __( 'Size', 'ova_framework' ),
	                'type' 		 => Controls_Manager::SLIDER,
	                'size_units' => [ '%', 'px' ],
	                'range' => [
	                    'px' => [
	                        'max' => 100,
	                    ],
	                ],
	                'tablet_default' => [
	                    'unit' => '%',
	                ],
	                'mobile_default' => [
	                    'unit' => '%',
	                ],
	                'selectors' => [
	                    '{{WRAPPER}} .ova_contact .content_left .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
	                ],
	            ]
	        );

		$this->end_controls_section();
		// End

		/**
		 * Section text style
		 */
		$this->start_controls_section(
			'section_text_style',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
	            'text_color',
	            [
	                'label' 	=> __( 'Color', 'ova_framework' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'default' 	=> '',
	                'selectors' => [
	                    '{{WRAPPER}} .ova_contact .content_right .text h3' => 'color: {{VALUE}};',
	                ],
	            ]
	        );

	        $this->add_group_control(
	            Group_Control_Typography::get_type(),
	            [
	                'name' 	   => 'text_typography',
	                'selector' => '{{WRAPPER}} .ova_contact .content_right .text h3',
	            ]
	        );

	        $this->add_responsive_control(
	            'text_margin',
	            [
	                'label' => __( 'Margin', 'ova_framework' ),
	                'type' 	=> Controls_Manager::DIMENSIONS,
	                'size_units' => [ 'px', '%', 'em' ],
	                'selectors'  => [
	                    '{{WRAPPER}} .ova_contact .content_right .text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

		$this->end_controls_section();
		// End

		/**
		 * Section title style
		 */
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
	            'title_color',
	            [
	                'label' 	=> __( 'Color', 'ova_framework' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'default' 	=> '',
	                'selectors' => [
	                    '{{WRAPPER}} .ova_contact .content_right .title_phone .title h2' => 'color: {{VALUE}};',
	                ],
	            ]
	        );

	        $this->add_group_control(
	            Group_Control_Typography::get_type(),
	            [
	                'name' 	   => 'title_typography',
	                'selector' => '{{WRAPPER}} .ova_contact .content_right .title_phone .title h2',
	            ]
	        );

	        $this->add_responsive_control(
	            'title_margin',
	            [
	                'label' => __( 'Margin', 'ova_framework' ),
	                'type' 	=> Controls_Manager::DIMENSIONS,
	                'size_units' => [ 'px', '%', 'em' ],
	                'selectors'  => [
	                    '{{WRAPPER}} .ova_contact .content_right .title_phone .title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

		$this->end_controls_section();
		// End

		/**
		 * Section phone style
		 */
		$this->start_controls_section(
			'section_phone_style',
			[
				'label' => __( 'Phone', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
	            'phone_color',
	            [
	                'label' 	=> __( 'Color', 'ova_framework' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'default' 	=> '',
	                'selectors' => [
	                    '{{WRAPPER}} .ova_contact .content_right .title_phone .phone h2 a' => 'color: {{VALUE}};',
	                ],
	            ]
	        );

	        $this->add_group_control(
	            Group_Control_Typography::get_type(),
	            [
	                'name' 	   => 'phone_typography',
	                'selector' => '{{WRAPPER}} .ova_contact .content_right .title_phone .phone h2',
	            ]
	        );

	        $this->add_responsive_control(
	            'phone_margin',
	            [
	                'label' => __( 'Margin', 'ova_framework' ),
	                'type' 	=> Controls_Manager::DIMENSIONS,
	                'size_units' => [ 'px', '%', 'em' ],
	                'selectors'  => [
	                    '{{WRAPPER}} .ova_contact .content_right .title_phone .phone h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

		$this->end_controls_section();
		// End

	}

	protected function render() {
		
		$settings 	= $this->get_settings();

		$url_img 	= $settings['image']['url'];
		$class_icon = $settings['class_icon'];
		$text 		= $settings['text'];
		$title 		= $settings['title'];
		$phone 		= $settings['phone_number'];
		$phone_link	= $settings['phone_link'];
	
		?>
		<div class="ova_contact">
			<div class="content_left">
				<div class="image">
					<img src="<?php echo esc_html( $url_img ); ?>" alt="Avatar">
				</div>
				<div class="icon">
					<i class="<?php echo esc_html( $class_icon ); ?>"></i>
				</div>
			</div>
			<div class="content_right">
				<div class="text">
					<h3><?php echo $text; ?></h3>
				</div>
				<div class="title_phone">
					<div class="title">
						<h2><?php echo $title; ?></h2>
					</div>
					<div class="phone">
						<h2><a href="<?php echo $phone_link; ?>" title="Call support"><?php echo $phone; ?></a></h2>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}


