<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_list_icon extends Widget_Base {

	public function get_name() {
		return 'ova_list_icon';
	}

	public function get_title() {
		return __( 'List Icon Service', 'ova-framework' );
	}

	public function get_icon() {
		return 'fas fa-check';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		//SECTION CONTENT
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

	

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);


		$repeater->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);
		$repeater->add_control(
			'title2',
			[
				'label' => __( 'Title2', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);


		$this->add_control(
			'tabs',
			[
				'label' => __( 'Tabs', 'ova-framework' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'icon' => __( 'flaticon-car-wash-4', 'ova-framework' ),
						'title' => __( 'High Quality', 'ova-framework' ),
						'title2' => __( 'Sed sed condimentum massa morbila auctor vestibulum urna. ', 'ova-framework' ),
					],
					[   'icon' => __( 'flaticon-bathing', 'ova-framework' ),
						'title' => __( 'Organic Products', 'ova-framework' ),
						'title2' => __( 'Sed sed condimentum massa morbila auctor vestibulum urna.', 'ova-framework' ),
					],
					[    'icon' => __( 'flaticon-mechanic', 'ova-framework' ),
						'title' => __( 'Talented Workers', 'ova-framework' ),
						'title2' => __( 'Sed sed condimentum massa morbila auctor vestibulum urna.', 'ova-framework' ),
					],
					
				],
			]
		);
			

		$this->end_controls_section();

		

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color icon ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_icon ul li .li-sev-icon i:before' => 'color : {{VALUE}};',
				],
			]
		);
			$this->add_control(
			'background_color_banner',
			[
				'label' => __( 'Background Color icon', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_icon ul li .li-sev-icon' => 'background-color : {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'color_icon_hover',
			[
				'label' => __( 'Color icon hover ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_icon ul li:hover .li-sev-icon i:before' => 'color : {{VALUE}};',
				],
			]
		);
			$this->add_control(
			'background_color_banner_hover',
			[
				'label' => __( 'Background Color icon hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_icon ul li:hover .li-sev-icon' => 'background-color : {{VALUE}};',
				],
			]
		);
			

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color Title ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_icon ul li .li-sev-text .li-text1' => 'color : {{VALUE}};',
				],
			]
		);
			$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_heading_typography',
				'selector' => '{{WRAPPER}} .ova_list_icon ul li .li-sev-text .li-text1 ',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);
			$this->add_control(
			'color_title2',
			[
				'label' => __( 'Color Title 2', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_icon ul li .li-sev-text .li-text2' => 'color : {{VALUE}};',
				],
			]
		);
				$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_sub_typography',
				'selector' => '{{WRAPPER}} .ova_list_icon ul li .li-sev-text .li-text2',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_responsive_control(
			'margin_icon',
			[
				'label' => __( 'Margin ', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}}  .ova_list_icon ul li:not(:last-child)' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding_text',
			[
				'label' => __( 'Padding text ', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}}  .ova_list_icon ul li .li-sev-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
            'display_tabs',
            [
                'label' => __( 'Display', 'ova_framework' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'flex' => __( 'Flex', 'ova_framework' ),
                    'block' => __( 'Block', 'ova_framework' ),
                ],
                'default' => 'flex',
                'selectors' => [
                    '{{WRAPPER}} .ova_list_icon ul li' => 'display: {{VALUE}};',
                ],
            ]
        );


		$this->end_controls_section();
		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$tabs = $settings['tabs'];
		?>
		
		<div class="ova_list_icon" >
				<?php if( !empty( $tabs ) ) : ?>
				<ul>
				<?php 
				foreach( $tabs as $item ) { 
					?>
					<li class="item">
						<div class="li-sev-icon">
			            <i class = "<?php echo esc_html__( $item['icon'] ) ?>"></i>
	                    </div>
	                    <div class="li-sev-text">
						<div class="li-text1 second_font"><?php echo esc_html__( $item['title'] ) ?></div>
						<div class="li-text2"><?php echo esc_html__( $item['title2'] ) ?></div>
					   </div>
					</li>
				<?php } ?>
				</ul>
			<?php endif ?>
		</div>

		<?php
	}
}

	