<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_tooltip extends Widget_Base {

	public function get_name() {
		return 'ova_tooltip';
	}

	public function get_title() {
		return __( 'Tooltip', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);


	$this->add_control(
			'heading',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('+ ','ova-framework'),
			]
		);
		$this->add_control(
			'heading2',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('Complete Car Wash Services ','ova-framework'),
			]
		);




	

		$this->end_controls_section();

			$this->start_controls_section(
				'section_icon_text',
				[
					'label' => __( 'Style', 'ova-framework' ),
					'tab' => Controls_Manager::TAB_STYLE,
				]
			);
			
			$this->add_control(
				'background_color_title',
				[
					'label' => __( 'Background Color Title ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .tt-mis .tt-title' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => __( 'Color Text ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .tt-mis .tt-title ' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_heading_typography',
					'selector' => '{{WRAPPER}} .tt-mis .tt-title ',
					'scheme' => Typography::TYPOGRAPHY_1,
				]
			);
			$this->add_control(
				'color_title2',
				[
					'label' => __( 'Color Title ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .tt-mis .tt-title2' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color_title2',
				[
					'label' => __( 'Background Color Title ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .tt-mis .tt-title2' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_sub_typography',
					'selector' => '{{WRAPPER}} .tt-mis .tt-title2',
					'scheme' => Typography::TYPOGRAPHY_1,
				]
			);
			
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

	

		$title = $settings['heading'];
		$title2 = $settings['heading2'];
	
		?>


		
		<div class="tt-mis">
			<div class="tt-title  second_font"><?php echo esc_html( $title ) ?></div>
			<div class="tt-title2 second_font"><?php echo esc_html( $title2 ) ?></div>
		</div>
		
	  
		
	    

		<?php

	}
}


