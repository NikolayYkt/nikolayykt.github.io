<?php 

if( !defined( 'ABSPATH' ) ) exit();

if( !class_exists( 'OVAFW_custom_post_type' ) ) {

	class OVAFW_custom_post_type{

		public function __construct(){
			add_action( 'init', array( $this, 'OVAFW_register_post_type_ova_fw' ) );
			add_action( 'init', array( $this, 'OVAFW_register_taxonomy_ova_fw' ) );
		}

		
		function OVAFW_register_post_type_ova_fw() {

			$labels = array(
				'name'                  => _x( 'Gallery', 'Post Type General Name', 'ova-framework' ),
				'singular_name'         => _x( 'Gallery', 'Post Type Singular Name', 'ova-framework' ),
				'menu_name'             => __( 'Gallery', 'ova-framework' ),
				'name_admin_bar'        => __( 'Post Type', 'ova-framework' ),
				'archives'              => __( 'Item Archives', 'ova-framework' ),
				'attributes'            => __( 'Item Attributes', 'ova-framework' ),
				'parent_item_colon'     => __( 'Parent Item:', 'ova-framework' ),
				'all_items'             => __( 'All Gallery', 'ova-framework' ),
				'add_new_item'          => __( 'Add New Gallery', 'ova-framework' ),
				'add_new'               => __( 'Add New Gallery', 'ova-framework' ),
				'new_item'              => __( 'New Item', 'ova-framework' ),
				'edit_item'             => __( 'Edit Gallery', 'ova-framework' ),
				'view_item'             => __( 'View Item', 'ova-framework' ),
				'view_items'            => __( 'View Items', 'ova-framework' ),
				'search_items'          => __( 'Search Item', 'ova-framework' ),
				'not_found'             => __( 'Not found', 'ova-framework' ),
				'not_found_in_trash'    => __( 'Not found in Trash', 'ova-framework' ),
			);
			$args = array(
				'description'         => __( 'Post Type Description', 'ova-framework' ),
				'labels'              => $labels,
				'supports'            => array( 'title','excerpt', 'editor', 'comments', 'thumbnail' ),
				'hierarchical'        => false,
				'public'              => true,
				'show_ui'             => true,
				'menu_position'       => 5,
				'query_var'           => true,
				'has_archive'         => true,
				'exclude_from_search' => true,
				'publicly_queryable'  => true,
				'rewrite'             => array( 'slug' => _x( 'ova_fw', 'URL slug', 'ova-framework' ) ),
				'capability_type'     => 'post',
			);
			register_post_type( 'ova_fw', $args );
		}

		function OVAFW_register_taxonomy_ova_fw(){
			

			$labels = array(
				'name'                       => _x( 'Category Gallery', 'Post Type General Name', 'ova-framework' ),
				'singular_name'              => _x( 'Category', 'Post Type Singular Name', 'ova-framework' ),
				'menu_name'                  => __( 'Category Gallery', 'ova-framework' ),
				'all_items'                  => __( 'All Category Gallery', 'ova-framework' ),
				'parent_item'                => __( 'Parent Item', 'ova-framework' ),
				'parent_item_colon'          => __( 'Parent Item:', 'ova-framework' ),
				'new_item_name'              => __( 'New Item Name', 'ova-framework' ),
				'add_new_item'               => __( 'Add New Category', 'ova-framework' ),
				'add_new'                    => __( 'Add New Category', 'ova-framework' ),
				'edit_item'                  => __( 'Edit Category', 'ova-framework' ),
				'view_item'                  => __( 'View Item', 'ova-framework' ),
				'separate_items_with_commas' => __( 'Separate items with commas', 'ova-framework' ),
				'add_or_remove_items'        => __( 'Add or remove items', 'ova-framework' ),
				'choose_from_most_used'      => __( 'Choose from the most used', 'ova-framework' ),
				'popular_items'              => __( 'Popular Items', 'ova-framework' ),
				'search_items'               => __( 'Search Items', 'ova-framework' ),
				'not_found'                  => __( 'Not Found', 'ova-framework' ),
				'no_terms'                   => __( 'No items', 'ova-framework' ),
				'items_list'                 => __( 'Items list', 'ova-framework' ),
				'items_list_navigation'      => __( 'Items list navigation', 'ova-framework' ),

			);
			$args = array(
				'labels'            => $labels,
				'hierarchical'      => true,
				'publicly_queryable' => true,
				'public'            => true,
				'show_ui'           => true,
				'show_admin_column' => true,
				'show_in_nav_menus' => true,
				'show_tagcloud'     => false,
				'rewrite'            => array(
					'slug'       => _x( 'cat_fw','Service Slug', 'ova-framework' ),
					'with_front' => false,
					'feeds'      => true,
				),
			);
			register_taxonomy( 'cat_fw', array( 'ova_fw' ), $args );
		}
	}

	new OVAFW_custom_post_type();
}