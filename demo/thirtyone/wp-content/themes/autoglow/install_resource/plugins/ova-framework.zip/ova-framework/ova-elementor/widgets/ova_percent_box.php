<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_percent_box extends Widget_Base {

	public function get_name() {
		return 'ova_percent_box';
	}

	public function get_title() {
		return __( 'Ova Percent Box', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-device-wide';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$this->add_control(
				'number',
				[
					'label' => __( 'Number', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => __('100','ova-framework'),
				]
			);
			
			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __('Satisfaction Guarantee','ova-framework'),
				]
			);

			$this->add_responsive_control(
	            'align',
	            [
	                'label'   => __( 'Alignment', 'ova_framework' ),
	                'type' 	  => Controls_Manager::CHOOSE,
	                'options' => [
	                    'flex-start' => [
	                        'title' => __( 'Left', 'ova_framework' ),
	                        'icon' 	=> 'eicon-text-align-left',
	                    ],
	                    'center' => [
	                        'title' => __( 'Center', 'ova_framework' ),
	                        'icon' 	=> 'eicon-text-align-center',
	                    ],
	                    'flex-end' => [
	                        'title' => __( 'Right', 'ova_framework' ),
	                        'icon' 	=> 'eicon-text-align-right',
	                    ],
	                ],
	                'default' => '',
	                'selectors' => [
	                    '{{WRAPPER}} .ova_percent_box' => 'justify-content: {{VALUE}};',
	                ],
	            ]
	        );

		$this->end_controls_section();
		
		/**
		 * Section content style
		 */
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
	            'content_bg',
	            [
	                'label' 	=> __( 'Background', 'ova_framework' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content' => 'background-color: {{VALUE}}',
	                ],
	            ]
	        );

	        $this->add_responsive_control(
	            'content_max_width',
	            [
	                'label' 	 => __( 'Max Width', 'ova_framework' ),
	                'type' 		 => Controls_Manager::SLIDER,
	                'size_units' => [ '%', 'px' ],
	                'range' => [
	                    'px' => [
	                        'max' => 1000,
	                    ],
	                ],
	                'tablet_default' => [
	                    'unit' => '%',
	                ],
	                'mobile_default' => [
	                    'unit' => '%',
	                ],
	                'selectors' => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content' => 'max-width: {{SIZE}}{{UNIT}};',
	                ],
	            ]
	        );

	        $this->add_responsive_control(
	            'content_align',
	            [
	                'label'   => __( 'Alignment', 'ova_framework' ),
	                'type' 	  => Controls_Manager::CHOOSE,
	                'options' => [
	                    'left' => [
	                        'title' => __( 'Left', 'ova_framework' ),
	                        'icon' 	=> 'eicon-text-align-left',
	                    ],
	                    'center' => [
	                        'title' => __( 'Center', 'ova_framework' ),
	                        'icon' 	=> 'eicon-text-align-center',
	                    ],
	                    'right' => [
	                        'title' => __( 'Right', 'ova_framework' ),
	                        'icon' 	=> 'eicon-text-align-right',
	                    ],
	                    'justify' => [
	                        'title' => __( 'Justified', 'ova_framework' ),
	                        'icon' 	=> 'eicon-text-align-justify',
	                    ],
	                ],
	                'default' => '',
	                'selectors' => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content' => 'text-align: {{VALUE}};',
	                ],
	            ]
	        );

	        $this->add_group_control(
	            Group_Control_Border::get_type(), [
	                'name' 		=> 'content_border',
	                'selector' 	=> '{{WRAPPER}} .ova_percent_box .percent_box_content',
	                'separator' => 'before',
	            ]
	        );

	        $this->add_control(
	            'content_border_radius',
	            [
	                'label' => __( 'Border Radius', 'ova_framework' ),
	                'type' 	=> Controls_Manager::DIMENSIONS,
	                'size_units' => [ 'px', '%' ],
	                'selectors'  => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

	        $this->add_responsive_control(
	            'content_padding',
	            [
	                'label' => __( 'Padding', 'ova_framework' ),
	                'type' 	=> Controls_Manager::DIMENSIONS,
	                'size_units' => [ 'px', 'em', '%' ],
	                'selectors'  => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

		$this->end_controls_section();
		// End

		/**
		 * Section number style
		 */
		$this->start_controls_section(
			'section_number_style',
			[
				'label' => __( 'Number', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
	            'number_color',
	            [
	                'label' 	=> __( 'Color', 'ova_framework' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'default' 	=> '',
	                'selectors' => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content .content .percent h1' => 'color: {{VALUE}};',
	                ],
	            ]
	        );

	        $this->add_group_control(
	            Group_Control_Typography::get_type(),
	            [
	                'name' 	   => 'number_typography',
	                'selector' => '{{WRAPPER}} .ova_percent_box .percent_box_content .content .percent h1',
	            ]
	        );

	        $this->add_group_control(
	            Group_Control_Border::get_type(), [
	                'name' 		=> 'number_border',
	                'selector' 	=> '{{WRAPPER}} .ova_percent_box .percent_box_content .content',
	                'separator' => 'before',
	            ]
	        );

	        $this->add_control(
	            'number_border_radius',
	            [
	                'label' => __( 'Border Radius', 'ova_framework' ),
	                'type' 	=> Controls_Manager::DIMENSIONS,
	                'size_units' => [ 'px', '%' ],
	                'selectors'  => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content .content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

	        $this->add_responsive_control(
	            'number_margin',
	            [
	                'label' => __( 'Margin', 'ova_framework' ),
	                'type' 	=> Controls_Manager::DIMENSIONS,
	                'size_units' => [ 'px', '%', 'em' ],
	                'selectors'  => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content .content .percent h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

		$this->end_controls_section();
		// End

		/**
		 * Section title style
		 */
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
	            'title_color',
	            [
	                'label' 	=> __( 'Color', 'ova_framework' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'default' 	=> '',
	                'selectors' => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content .content .title h2' => 'color: {{VALUE}};',
	                ],
	            ]
	        );

	        $this->add_group_control(
	            Group_Control_Typography::get_type(),
	            [
	                'name' 	   => 'title_typography',
	                'selector' => '{{WRAPPER}} .ova_percent_box .percent_box_content .content .title h2',
	            ]
	        );

	        $this->add_responsive_control(
	            'title_margin',
	            [
	                'label' => __( 'Margin', 'ova_framework' ),
	                'type' 	=> Controls_Manager::DIMENSIONS,
	                'size_units' => [ 'px', '%', 'em' ],
	                'selectors'  => [
	                    '{{WRAPPER}} .ova_percent_box .percent_box_content .content .title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

		$this->end_controls_section();
		// End

	}

	protected function render() {
		
		$settings 	= $this->get_settings();
		$number 	= $settings['number'];
		$title 		= $settings['title'];
	
		?>
		<div class="ova_percent_box">
			<div class="percent_box_content">
				<div class="content">
					<div class="percent">
						<h1><?php echo $number; ?><span>%</span></h1>
					</div>
					<div class="title">
						<h2><?php echo $title; ?></h2>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}


