<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_before_after extends Widget_Base {

	public function get_name() {
		return 'ova_before_after';
	}

	public function get_title() {
		return __( 'Before After', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-testimonial';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {

		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			

				$this->add_control(
					'image_before',
					[
						'label'   => 'Before Image',
						'type'    => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					]
				);

				$this->add_control(
					'image_after',
					[
						'label'   => 'After Image',
						'type'    => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					]
				);


		$this->end_controls_section();

		/*****************  END SECTION CONTENT ******************/


		/*****************************************************************
						START SECTION ADDITIONAL
		******************************************************************/

	
	}

	protected function render() {
		$settings = $this->get_settings();


		

		?>

		<div class='ova_before_after'>

			<div id="comparison" >
				<figure style="background-image: url(<?php echo esc_attr($settings['image_before']['url'])?>);">
					<div id="handle"></div>
					<div id="divisor" style="background-image: url(<?php echo esc_attr($settings['image_after']['url'])?>);"></div>
				</figure>
				<input type="range" min="0" max="100" value="50" id="slider">
			</div>



		</div>

		<?php
	}

		
}


