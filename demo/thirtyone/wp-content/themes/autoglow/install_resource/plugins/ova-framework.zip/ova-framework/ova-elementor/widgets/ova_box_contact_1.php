<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_box_contact_1 extends Widget_Base {

	public function get_name() {
		return 'ova_box_contact_1';
	}

	public function get_title() {
		return __( 'Box Contact 1', 'ova-framework' );
	}

	public function get_icon() {
		return 'fa fa-map-marker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$this->add_control(
				'version',
				[
					'label'   => __( 'Version', 'ova-framework' ),
					'type' 	  => Controls_Manager::SELECT,
					'default' => 'version_1',
					'options' => [
						'version_1' => esc_html__( 'Version 1', 'ova-framework' ),
						'version_2' => esc_html__( 'Version 2', 'ova-framework' ),
						'version_3' => esc_html__( 'Version 3', 'ova-framework' ),
					]
				]
			);

			$this->add_control(
				'class_icon',
				[
					'label' 	=> __( 'Class icon', 'ova-framework' ),
					'type' 		=> \Elementor\Controls_Manager::TEXT,
					'default' 	=> 'flaticon-pin',
				]
			);

			$this->add_control(
				'title',
				[
					'label' 	=> __( 'Title', 'ova-framework' ),
					'type' 		=> \Elementor\Controls_Manager::TEXT,
					'default' 	=> __('Our Address', 'ova-framework'),
				]
			);

			$this->add_control(
				'type_link',
				[
					'label'   => __( 'Type Link', 'ova-framework' ),
					'type' 	  => Controls_Manager::SELECT,
					'default' => 'none',
					'options' => [
						'email' => __('Email', 'ova-framework'),
						'tell' 	=> __('Tell', 'ova-framework'),
						'none' 	=> __('None', 'ova-framework'),
					]
				]
			);

			$this->add_control(
				'link_1',
				[
					'label' 	=> __( 'Link 1', 'ova-framework' ),
					'type' 		=> \Elementor\Controls_Manager::TEXT,
					'default' 	=> __('contact@domain.com', 'ova-framework'),
				]
			);

			$this->add_control(
				'text_link_1',
				[
					'label' 	=> __( 'Label 1', 'ova-framework' ),
					'type' 		=> \Elementor\Controls_Manager::TEXT,
					'default' 	=> __('Level 13, 2 Elizabeth St,', 'ova-framework'),
				]
			);

			$this->add_control(
				'link_2',
				[
					'label' 	=> __( 'Link 2', 'ova-framework' ),
					'type' 		=> \Elementor\Controls_Manager::TEXT,
					'default' 	=> __('contact@domain.com', 'ova-framework'),
				]
			);

			$this->add_control(
				'text_link_2',
				[
					'label' 	=> __( 'Label 2', 'ova-framework' ),
					'type' 		=> \Elementor\Controls_Manager::TEXT,
					'default' 	=> __('Melbourne, Victoria 3000, Australia', 'ova-framework'),
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon_text',
			[
				'label' => __( 'Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
				
			$this->add_control(
				'color_icon',
				[
					'label' 	=> __( 'Color Icon ', 'ova-framework' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_contact_1 .icon i:before'  => 'color: {{VALUE}};',
						'{{WRAPPER}} .ova_box_contact.version_3 .icon i' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'bg_icon',
				[
					'label' 	=> __( 'Background', 'ova-framework' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_contact.version_3 .icon' => 'background-color: {{VALUE}};',
					],
					'condition' => [
						'version' => ['version_3'],
					],
				]
			);

			$this->add_control(
				'font_size_icon',
				[
					'label' 	 => __( 'Font Size', 'ova-framework' ),
					'type' 		 => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' 	 => [
						'px' => [
							'min' 	=> 1,
							'max' 	=> 100,
							'step' 	=> 1,
						]
					],
					'selectors' => [
						'{{WRAPPER}} .ova_box_contact_1 .icon i:before'  => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .ova_box_contact_1 .icon svg' 		 => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .ova_box_contact.version_3 .icon i' => 'font-size: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' 	=> __( 'Color Title', 'ova-framework' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_contact_1 .title' 		=> 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_box_contact.version_3 .title' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title_hover',
				[
					'label' 	=> __( 'Color Title Hover', 'ova-framework' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_contact_1 .title:hover' 		  => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_box_contact.version_3 .title:hover' => 'color : {{VALUE}};',
					],
				]
			);
		

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title_typography',
					'selector' 	=> '{{WRAPPER}} .ova_box_contact_1 .title',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
					'condition' => [
						'version!' => ['version_3'],
					], 
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title_typography_v3',
					'selector' 	=> '{{WRAPPER}} .ova_box_contact.version_3 .title',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
					'condition' => [
						'version' => ['version_3'],
					], 
				]
			);


			$this->add_control(
				'color_title2',
				[
					'label' 	=> __( 'Color Label', 'ova-framework' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_contact_1 a, {{WRAPPER}} .ova_box_contact_1 p' 				 => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_box_contact.version_3 p, {{WRAPPER}} .ova_box_contact.version_3 a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title2_hover',
				[
					'label' 	=> __( 'Color Label Hover', 'ova-framework' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_contact_1 a:hover, {{WRAPPER}} .ova_box_contact_1 p:hover' 				 => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_box_contact.version_3 p:hover, {{WRAPPER}} .ova_box_contact.version_3 a:hover' => 'color : {{VALUE}};',
					],
				]
			);
		

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title2_typography',
					'selector' 	=> '{{WRAPPER}} .ova_box_contact_1 a, {{WRAPPER}} .ova_box_contact_1 p',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
					'condition' => [
						'version!' => ['version_3'],
					],
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title2_typography_v3',
					'selector' 	=> '{{WRAPPER}} .ova_box_contact.version_3 p, {{WRAPPER}} .ova_box_contact.version_3 a',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
					'condition' => [
						'version' => ['version_3'],
					],
				]
			);

		$this->end_controls_section();


	}

	protected function render() {
		$settings = $this->get_settings();

		$title = $settings['title'];
		$type_link = $settings['type_link'];

		$icon = $settings['class_icon'];
		$html_icon = '<i class="'.esc_attr( $icon ).'"></i>';

		$link_1 = $settings['link_1'];
		$label_1 = $settings['text_link_1'];
		
		$link_2 = $settings['link_2'];
		$label_2 = $settings['text_link_2'];
		$version = $settings['version'];


		$text_link_1 = $text_link_2 = '';
		switch($type_link) {
			case "email" : {
				if( ! empty( $label_1 ) ){
					$text_link_1 = "<a href='mailto:".esc_attr( $link_1 )."'>".esc_html( $label_1 )."</a>";
				}

				if( ! empty( $label_2 ) ){
					$text_link_2 = "<a href='mailto:".esc_attr( $link_2 )."'>".esc_html( $label_2 )."</a>";
				}
			
				break;
			}
			case "tell" : {

				if( ! empty( $label_1 ) ){
					$text_link_1 = "<a href='tel:".esc_attr( $link_1 )."'>".esc_html( $label_1 )."</a>";
				}

				if( ! empty( $label_2 ) ){
					$text_link_2 = "<a href='tel:".esc_attr( $link_2 )."'>".esc_html( $label_2 )."</a>";
				}
				
				break;
			}

			case "none" : {

				if( ! empty( $label_1 ) ){
					$text_link_1 = "<p>".esc_html( $label_1 )."</p>";
				}

				if( ! empty( $label_2 ) ){
					$text_link_2 = "<p>".esc_html( $label_2 )."</p>";
				}
				
				break;
			}

		}

		
		?>

		<?php if ( $version != 'version_3' ): ?>

			<div class="ova_box_contact_1 <?php echo esc_attr( $version ) ?> ">
				<?php if ( $icon ): ?>
					<div class="icon">
						<i class="<?php echo esc_attr( $icon ) ?>"></i>
					</div>
				<?php endif; ?>
				<div>
					<?php if ( $title ): ?>
						<h3 class="title">
							<?php echo $title ?>
						</h3>
					<?php endif; ?>

					<?php
						echo $text_link_1 . $text_link_2;
					?>
				</div>

			</div>

		<?php else: ?>

			<div class="ova_box_contact <?php echo esc_attr( $version ) ?> ">
				<?php if ( $icon ): ?>
					<div class="icon">
						<i class="<?php echo esc_attr( $icon ) ?>"></i>
					</div>
				<?php endif; ?>

				<?php if ( $title ): ?>
					<h3 class="title"><?php echo $title; ?></h3>
				<?php endif; ?>

				<?php
					echo $text_link_1 . $text_link_2;
				?>

			</div>

		<?php
		endif;
	}
// end render
}


