<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_banner2 extends Widget_Base {

	public function get_name() {
		return 'ova_banner2';
	}

	public function get_title() {
		return __( 'Banner Service', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'flaticon-car-service', 'ova-framework' ),
				
			]
		);


		$this->add_control(
			'heading',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('01 ','ova-framework'),
			]
		);
		$this->add_control(
			'heading2',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('Make an appointment & Bring your car','ova-framework'),
			]
		);

			$this->add_control(
			'sub_title',
			[
				'label' => __( 'Sub Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
			]
		);




	

		$this->end_controls_section();

			$this->start_controls_section(
			'section_icon_text',
			[
				'label' => __( 'Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'color_icon',
				[
					'label' 	=> __( 'Color Icon ', 'ova-framework' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}}  .banner2-sev .icon-title .bn2-icon i' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon',
				[
					'label' 	 => __( 'Font Size', 'ova-framework' ),
					'type' 		 => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' 	 => [
						'px' => [
							'min' 	=> 1,
							'max' 	=> 100,
							'step' 	=> 1,
						]
					],
					'selectors' => [
						'{{WRAPPER}}  .banner2-sev .icon-title .bn2-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				
					],
				]
			);
				$this->add_control(
			'background_color_cicle',
			[
				'label' => __( 'Background Circle 1 ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner2-sev .icon-title .bn2-sev:before' => 'background-color : {{VALUE}};',
				],
			]
		);
			
			$this->add_control(
			'background_color_title',
			[
				'label' => __( 'Background Circle 2 ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner2-sev .icon-title .bn2-sev .bn2-title' => 'background-color : {{VALUE}};',
				],
			]
		);
			$this->add_control(
			'color_title',
			[
				'label' => __( 'Color Text ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner2-sev .icon-title .bn2-sev .bn2-title ' => 'color : {{VALUE}};',
				],
			]
		);
			$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_heading_typography',
				'selector' => '{{WRAPPER}} .banner2-sev .icon-title .bn2-sev .bn2-title ',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);
				$this->add_control(
			'color_title2',
			[
				'label' => __( 'Color Title ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner2-sev .bn2-title2' => 'color : {{VALUE}};',
				],
			]
		);

				$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_sub_typography',
				'selector' => '{{WRAPPER}} .banner2-sev .bn2-title2',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

					$this->add_control(
			'color_sub_title2',
			[
				'label' => __( 'Color Sub Title ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner2-sev .bn2-sub_title' => 'color : {{VALUE}};',
				],
			]
		);

				$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_sub2_typography',
				'selector' => '{{WRAPPER}} .banner2-sev .bn2-sub_title',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);
			
			
	
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

	
		$icon = $settings['class_icon'];
		$title = $settings['heading'];
		$title2 = $settings['heading2'];
		$sub_title = $settings['sub_title'];
	
		?>


		<div class="banner2-sev">
			<div class="icon-title">
				<div class="bn2-sev">
					<div class="bn2-title"><?php echo esc_html( $title ) ?></div>
				</div>
				<div class="bn2-icon"><i class = "<?php echo esc_html( $icon ) ?>"></i></div>
			</div>
		<div class="bn2-title2 second_font"><?php echo esc_html( $title2 ) ?></div>
			<div class="bn2-sub_title"><?php echo esc_html( $sub_title ) ?></div>
	   </div>
		
	    

		<?php

	}
}


