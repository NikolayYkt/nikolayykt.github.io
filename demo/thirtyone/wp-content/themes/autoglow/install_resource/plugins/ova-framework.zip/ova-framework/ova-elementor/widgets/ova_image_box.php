<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_image_box extends Widget_Base {

    public function get_name() {
        return 'ova_image_box';
    }

    public function get_title() {
        return __( 'Ova Image Box', 'ova-framework' );
    }

    public function get_icon() {
        return 'eicon-image-box';
    }

    public function get_categories() {
        return [ 'ovatheme' ];
    }

    public function get_script_depends() {
        return [ 'script-elementor' ];
    }

    protected function _register_controls() {

        //begin Image
        $this->start_controls_section(
            'section_image',
            [
                'label' => __( 'Image', 'ova_framework' ),
            ]
        );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Choose Image', 'ova_framework' ),
                    'type' => Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' => 'image',
                    'default' => 'large',
                    'separator' => 'none',
                ]
            );

            $this->add_control(
                'link_image',
                [
                    'label' => __( 'Link', 'ova_framework' ),
                    'type' => Controls_Manager::URL,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => '#',
                    ],
                ]
            );
        $this->end_controls_section();
        //end Image

        //begin Text
        $this->start_controls_section(
            'section_text_image_box',
            [
                'label' => __( 'Text', 'ova-framework' ),
            ]
        );

            $this->add_control(
              'title_image_box',
              [
                  'label'   => __( 'Title', 'ova_framework' ),
                  'type' => Controls_Manager::TEXT,
                  'default' => 'Car Washing',
              ]
            );

            $this->add_responsive_control(
            'text-align',
                [
                    'label' => __( 'Alignment', 'ova_framework' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'ova_framework' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'ova_framework' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'ova_framework' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                        'justify' => [
                        'title' => __( 'Justified', 'ova_framework' ),
                        'icon' => 'eicon-text-align-justify',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .content_image_box .ova_title_img_box' => 'text-align: {{VALUE}}',
                    ],
                ]
            );

        $this->end_controls_section();
        //end Text

        //begin Icon
        $this->start_controls_section(
            'section_icon_image_box',
            [
                'label' => __( 'Icon', 'ova-framework' ),
            ]
        );

            $this->add_control(
                'class_icon',
                [
                    'label'   => __( 'Icon Class', 'ova_framework' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'flaticon-car-wash',
                ]
            );

            $this->add_control(
                'icon_size',
                [
                    'label' => __( 'Size', 'ova_framework' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => ['px'],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 100,
                            'step' => 1,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .content_image_box .ova_icon_img_box i:before' => 'font-size: {{SIZE}}{{UNIT}}',
                    ],
                ]
            );

        $this->end_controls_section();
        //end Icon

        //begin Button
        $this->start_controls_section(
            'section_button_image_box',
            [
                'label' => __( 'Button', 'ova-framework' ),
            ]
        );

            $this->add_control(
                'text_button',
                [
                   'label'   => __( 'Text', 'ova_framework' ),
                  'type' => Controls_Manager::TEXT,
                  'default' => 'See Details',
                ]
            );

            $this->add_responsive_control(
            'text-button-align',
                [
                    'label' => __( 'Alignment', 'ova_framework' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'ova_framework' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'ova_framework' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'ova_framework' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .ova_button_img_box' => 'text-align: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'link_button',
                [
                    'label' => __( 'Link', 'ova_framework' ),
                    'type' => Controls_Manager::URL,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => '#',
                    ],
                ]
            );

            $this->add_control(
                'class_icon_button',
                [
                    'label'   => __( 'Class Icon', 'ova_framework' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'arrow_carrot-right',
                ]
            );

            $this->add_control(
                'icon_button_align',
                [
                    'label' => __( 'Icon Position', 'ova_framework' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'right',
                    'options' => [
                        'left' => __( 'Before', 'ova_framewor' ),
                        'right' => __( 'After', 'ova_framewor' ),
                    ],
                    'condition' => [
                        'class_icon_button[value]!' => '',
                    ],
                ]
            );

            $this->add_control(
                'icon_button_indent',
                [
                    'label' => __( 'Icon Spacing', 'ova_framework' ),
                    'type' => Controls_Manager::SLIDER,
                    'range' => [
                        'px' => [
                            'max' => 50,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .ova_button_img_box .icon_after i:before' => 'margin-left: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .ova_image_box .ova_button_img_box .icon_before i:before' => 'margin-right: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();
        //end Button

        //begin Text Style
        $this->start_controls_section(
            'section_text_style',
            [
                'label' => __( 'Text', 'ova_framework' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

            $this->add_control(
                'text_color',
                [
                    'label' => __( 'Text Color', 'ova_framework' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .content_image_box .ova_title_img_box' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'text_typography',
                    'selector' => '{{WRAPPER}} .ova_image_box .content_image_box .ova_title_img_box',
                ]
            );

            $this->add_control(
                'text_padding',
                [
                    'label' => __( 'Padding', 'ova_framework' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .content_image_box .ova_title_img_box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'text_margin',
                [
                    'label' => __( 'Margin', 'ova_framework' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .content_image_box .ova_title_img_box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();
        //end Text Style

        //begin Icon Style
        $this->start_controls_section(
            'section_icon_style',
            [
                'label' => __( 'Icon', 'ova_framework' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

            $this->add_control(
                'icon_color',
                [
                    'label' => __( 'Icon Color', 'ova_framework' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .content_image_box .ova_icon_img_box i:before' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'icon_typography',
                    'selector' => '{{WRAPPER}} .ova_image_box .content_image_box .ova_icon_img_box i:before',
                ]
            );

            $this->add_control(
                'icon_padding',
                [
                    'label' => __( 'Padding', 'ova_framework' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .content_image_box .ova_icon_img_box i:before' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'icon_margin',
                [
                    'label' => __( 'Margin', 'ova_framework' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .content_image_box .ova_icon_img_box i:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();
        //end Icon Style

        //begin Button Style

        $this->start_controls_section(
            'section_button_style',
            [
                'label' => __( 'Button', 'ova_framework' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

            $this->add_group_control(
            Group_Control_Typography::get_type(),
                [
                    'name' => 'typography',
                    'selector' => '{{WRAPPER}} .ova_image_box .ova_button_img_box a',
                ]
            );

            $this->start_controls_tabs( 'tabs_button_style' );

                $this->start_controls_tab(
                    'tab_button_normal',
                    [
                        'label' => __( 'Normal', 'ova_framework' ),
                    ]
                );

                    $this->add_control(
                        'button_text_color_style',
                        [
                            'label' => __( 'Text Color', 'ova_framework' ),
                            'type' => Controls_Manager::COLOR,
                            'default' => '',
                            'selectors' => [
                                '{{WRAPPER}} .ova_image_box .ova_button_img_box a' => 'fill: {{VALUE}}; color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'background_color_style',
                        [
                            'label' => __( 'Background Color', 'ova_framework' ),
                            'type' => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .ova_image_box .ova_button_img_box' => 'background-color: {{VALUE}};',
                            ],
                        ]
                    );

                $this->end_controls_tab();

                $this->start_controls_tab(
                    'tab_button_hover',
                    [
                        'label' => __( 'Hover', 'ova_framework' ),
                    ]
                );

                    $this->add_control(
                        'button_hover_color_style',
                            [
                                'label' => __( 'Text Color', 'ova_framework' ),
                                'type' => Controls_Manager::COLOR,
                                'selectors' => [
                                    '{{WRAPPER}} .ova_image_box .ova_button_img_box:hover a' => 'color: {{VALUE}};',
                                ],
                            ]
                        );

                    $this->add_control(
                        'button_background_hover_color',
                        [
                            'label' => __( 'Background Color', 'ova_framework' ),
                            'type' => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .ova_image_box .ova_button_img_box:hover' => 'background-color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'button_hover_border_color',
                        [
                            'label' => __( 'Border Color', 'ova_framework' ),
                            'type' => Controls_Manager::COLOR,
                            'condition' => [
                                'border_border!' => '',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .ova_image_box .ova_button_img_box:hover' => 'border-color: {{VALUE}};',
                            ],
                        ]
                    );


                $this->end_controls_tab();

            $this->end_controls_tabs();


            $this->add_control(
                'border_radius',
                [
                    'label' => __( 'Border Radius', 'ova_framework' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .ova_button_img_box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );


            $this->add_responsive_control(
                'button_text_padding',
                [
                    'label' => __( 'Padding', 'elementor' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_image_box .ova_button_img_box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );


        $this->end_controls_section();

        //end Button Style

        //

    }


    protected function render() {
        $settings = $this->get_settings();

        $link_image = $settings['link_image']['url'] ? $settings['link_image']['url'] : '#';
        $image_url = $settings['image']['url'] ? $settings['image']['url'] : '#';
        $title = $settings['title_image_box'] ? $settings['title_image_box'] : 'Title';
        $class_icon = $settings['class_icon'] ? $settings['class_icon'] : 'flaticon-car-wash';
        $link_button = $settings['link_button']['url'] ? $settings['link_button']['url'] : '#';
        $text_button = $settings['text_button'] ? $settings['text_button'] : 'Click here!';

        $class_icon_button = $settings['class_icon_button'] ? $settings['class_icon_button'] : 'arrow_carrot-right';
        $icon_button_align = $settings['icon_button_align'] ? $settings['icon_button_align'] : 'right';

        ?>

        <div class="ova_image_box">

            <a href="<?php echo $link_image; ?>">
                <img class="ova_img_box" src="<?php echo $image_url; ?>" alt="Image Box">
            </a>

            <div class="content_image_box">
                <div class="ova_icon_img_box">
                    <i class="<?php echo $class_icon; ?>"></i>
                </div>
                <div class="ova_title_img_box"><?php echo $title; ?></div>
            </div>

            <div class="ova_button_img_box">
                <?php if ( 'right' === $icon_button_align ) : ?>
                    <a class="icon_after" href="<?php echo $link_button; ?>"><?php echo $text_button; ?><i class="<?php echo $class_icon_button; ?>"></i></a>
                <?php else: ?>
                    <a class="icon_before" href="<?php echo $link_button; ?>"><i class="<?php echo $class_icon_button; ?>"></i><?php echo $text_button; ?></a>
                <?php endif; ?>

            </div>
            
        </div>
    <?php
    }
    // end render
}


