<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_pricing extends Widget_Base {

    public function get_name() {
        return 'ova_pricing';
    }

    public function get_title() {
        return __( 'Pricing', 'ova-framework' );
    }

    public function get_icon() {
        return 'fas fa-money-check-alt';
    }

    public function get_categories() {
        return [ 'ovatheme' ];
    }

    public function get_script_depends() {
        return [ 'script-elementor' ];
    }

    protected function _register_controls() {
    /*
     * Begin Content
     */

    // Begin Header
        $this->start_controls_section(
            'section_heading_content',
            [
                'label' => __( 'Content', 'ova-framework' ),

            ]
        );

        $this->add_control(
          'content_title',
          [
              'label'   => __( 'Title', 'ova_framework' ),
              'type'    => \Elementor\Controls_Manager::TEXT,
              'placeholder' => __( 'Enter your title', 'ova_framework' ),
              'default' => __( 'Add Your Title', 'ova_framework'),
          ]
        );

        $this->add_responsive_control(
            'content_align',
            [
                'label' => __( 'Alignment', 'ova_framework' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'ova_framework' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'ova_framework' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'ova_framework' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'ova_framework' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .content-price-title' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

    // End Header

    // Begin Pricing
        $this->start_controls_section(
            'section_pricing',
            [
                'label' => __( 'Pricing', 'ova_framework' ),
            ]
        );

        $this->add_control(
            'currency_symbol',
            [
                'label' => __( 'Currency Symbol', 'ova_framework' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'None', 'ova_framework' ),
                    'dollar' => '&#36; ' . _x( 'Dollar', 'Currency Symbol', 'ova_framework' ),
                    'euro' => '&#128; ' . _x( 'Euro', 'Currency Symbol', 'ova_framework' ),
                    'baht' => '&#3647; ' . _x( 'Baht', 'Currency Symbol', 'ova_framework' ),
                    'franc' => '&#8355; ' . _x( 'Franc', 'Currency Symbol', 'ova_framework' ),
                    'guilder' => '&fnof; ' . _x( 'Guilder', 'Currency Symbol', 'ova_framework' ),
                    'krona' => 'kr ' . _x( 'Krona', 'Currency Symbol', 'ova_framework' ),
                    'lira' => '&#8356; ' . _x( 'Lira', 'Currency Symbol', 'ova_framework' ),
                    'peseta' => '&#8359 ' . _x( 'Peseta', 'Currency Symbol', 'ova_framework' ),
                    'peso' => '&#8369; ' . _x( 'Peso', 'Currency Symbol', 'ova_framework' ),
                    'pound' => '&#163; ' . _x( 'Pound Sterling', 'Currency Symbol', 'ova_framework' ),
                    'real' => 'R$ ' . _x( 'Real', 'Currency Symbol', 'ova_framework' ),
                    'ruble' => '&#8381; ' . _x( 'Ruble', 'Currency Symbol', 'ova_framework' ),
                    'rupee' => '&#8360; ' . _x( 'Rupee', 'Currency Symbol', 'ova_framework' ),
                    'indian_rupee' => '&#8377; ' . _x( 'Rupee (Indian)', 'Currency Symbol', 'ova_framework' ),
                    'shekel' => '&#8362; ' . _x( 'Shekel', 'Currency Symbol', 'ova_framework' ),
                    'yen' => '&#165; ' . _x( 'Yen/Yuan', 'Currency Symbol', 'ova_framework' ),
                    'won' => '&#8361; ' . _x( 'Won', 'Currency Symbol', 'ova_framework' ),
                    'custom' => __( 'Custom', 'ova_framework' ),
                ],
                'default' => 'dollar',
            ]
        );

        $this->add_control(
            'currency_symbol_custom',
            [
                'label' => __( 'Custom Symbol', 'ova_framework' ),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'currency_symbol' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'price',
            [
                'label' => __( 'Price', 'ova_framework' ),
                'type' => Controls_Manager::TEXT,
                'default' => '99.99',
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'currency_format',
            [
                'label' => __( 'Currency Format', 'ova_framework' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => 'Integer (Default)',
                    ',' => 'Decimal',
                ],
            ]
        );

        $this->add_control(
            'sale',
            [
                'label' => __( 'Sale', 'ova_framework' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'ova_framework' ),
                'label_off' => __( 'Off', 'ova_framework' ),
                'default' => '',
            ]
        );

        $this->add_control(
            'original_price',
            [
                'label' => __( 'Original Price', 'ova_framework' ),
                'type' => Controls_Manager::NUMBER,
                'default' => '59',
                'condition' => [
                    'sale' => 'yes',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'description_price',
            [
                'label' => __( 'Description', 'ova_framework' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Duration: 15 min', 'ova_framework' ),
                'default' => __( 'Duration: 15 min', 'ova_framework' ),
            ]
        );

        $this->end_controls_section();
    // End Pricing

    //Divider
        $this->start_controls_section(
            'section_divider',
            [
                'label' => __( 'Divider', 'ova_framework' ),
            ]
        );

        $this->add_control(
            'divider-style',
            [
                'label' => __( 'Style', 'ova_framework' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'dotted' => __( 'Dotted', 'ova_framework' ),
                    'dashed' => __( 'Dashed', 'ova_framework' ),
                    'solid'  => __( 'Solid', 'ova_framework' ),
                    'double' => __( 'Double', 'ova_framework' ),
                    'groove' => __( 'Groove', 'ova_framework' ),
                    'ridge' => __( 'Ridge', 'ova_framework' ),
                    'inset' => __( 'Inset', 'ova_framework' ),
                    'outset' => __( 'Outset', 'ova_framework' ),
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ova-divider .divider' => 'border-bottom-style: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'divider-width',
            [
                'label' => __( 'Width', 'ova_framework' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ '%', 'px' ],
                'range' => [
                    'px' => [
                        'max' => 1000,
                    ],
                ],
                'tablet_default' => [
                    'unit' => '%',
                ],
                'mobile_default' => [
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ova-divider .divider' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'divider-align',
            [
                'label' => __( 'Alignment', 'ova_framework' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'ova_framework' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'ova_framework' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'ova_framework' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ova-divider' => 'text-align: {{VALUE}}',
                    '{{WRAPPER}} .container-price .content-price .ova-price .ova-divider .divider' => 'margin: 0 auto; margin-{{VALUE}}: 0',
                ],
            ]
        );

        $this->end_controls_section();
    //End divider

    // Begin Features
        $this->start_controls_section(
            'section_features',
            [
                'label' => __( 'Features', 'ova-framework' ),
            ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'item_text',
            [
                'label' => __( 'Text', 'ova-framework' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'List Item', 'ova-framework' ),
            ]
        );

        $default_icon = 'check-circle';

        $repeater->add_control(
            'icon_class',
            [
                'label' => __( 'Icon Class', 'ova-framework' ),
                'type' => Controls_Manager::TEXT,
                'default' => $default_icon,
            ]
        );

        $repeater->add_control(
            'item_icon_color',
            [
                'label' => __( 'Icon Color', 'ova-framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} {{CURRENT_ITEM}} svg' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $repeater->add_control(
            'item_color',
            [
                'label' => __( 'Item Color', 'ova-framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .list-item' => 'color: {{VALUE}} !important',
                ],
            ]
        );

        $this->add_control(
            'features_list',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'item_text' => __( 'List Item #1', 'ova-framework' ),
                        'selected_item_icon' => $default_icon,
                    ],
                    [
                        'item_text' => __( 'List Item #2', 'ova-framework' ),
                        'selected_item_icon' => $default_icon,
                    ],
                    [
                        'item_text' => __( 'List Item #3', 'ova-framework' ),
                        'selected_item_icon' => $default_icon,
                    ],
                ],
                'title_field' => '{{{ item_text }}}',
            ]
        );

        $this->end_controls_section();

    // End Features

    // Begin Footer
        $this->start_controls_section(
            'section_footer',
            [
                'label' => __( 'Footer', 'ova_framework' ),
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __( 'Button Text', 'ova_framework' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Click Here', 'ova_framework' ),
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => __( 'Link', 'ova_framework' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'ova_framework' ),
                'default' => [
                    'url' => '#',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'footer_additional_info',
            [
                'label' => __( 'Additional Info', 'ova_framework' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __( 'Enter your text', '' ),
                'rows' => 3,
            ]
        );

        $this->end_controls_section();

        //Ribbon
        $this->start_controls_section(
            'section_ribbon',
            [
                'label' => __( 'Ribbon', 'ova_framework' ),
            ]
        );

        $this->add_control(
            'show_ribbon',
            [
                'label' => __( 'Show', 'ova_framework' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ribbon_title',
            [
                'label' => __( 'Title', 'ova_framework' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Best Plan', 'ova_framework' ),
                'condition' => [
                    'show_ribbon' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
        //End Ribbon
    // End Footer

    /*
     * End Content
     */


    /*
     * Begin Style
     */

    // Begin Style Header
        $this->start_controls_section(
            'section_header_style',
            [
                'label' => __( 'Content', 'ova_framework' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_control(
            'header_bg_color',
            [
                'label' => __( 'Background Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .content-price-title' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'header_padding',
            [
                'label' => __( 'Padding', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .content-price-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'header_margin',
            [
                'label' => __( 'Margin', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .content-price-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_border_radius',
            [
                'label' => __( 'Border Radius', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .content-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'heading_title_style',
            [
                'label' => __( 'Title', 'ova_framework' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'heading_title_color',
            [
                'label' => __( 'Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .content-price-title .title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'selector' => '{{WRAPPER}} .container-price .content-price .content-price-title .title',
            ]
        );

        $this->end_controls_section();
    // End Style Header

    // Begin Style Pricing

        // Header
        $this->start_controls_section(
            'section_pricing_style',
            [
                'label' => __( 'Pricing', 'ova_framework' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_control(
            'pricing_bg_color',
            [
                'label' => __( 'Background Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'pricing_padding',
            [
                'label' => __( 'Padding', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'pricing_margin',
            [
                'label' => __( 'Margin', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'price_title_color',
            [
                'label' => __( 'Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'global' => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'priceg_typography',
                'selector' => '{{WRAPPER}} .container-price .content-price .pricing .price',

            ]
        );
        // END Header

        // Pricing
        $this->add_control(
            'heading_currency_style',
            [
                'label' => __( 'Currency Symbol', 'ova_framework' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'currency_symbol!' => '',
                ],
            ]
        );

        $this->add_control(
            'currency_size',
            [
                'label' => __( 'Size', 'ova_framework' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .pricing .currency-icon' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'currency_symbol!' => '',
                ],
            ]
        );

        $this->add_control(
            'currency_position',
            [
                'label' => __( 'Position', 'ova_framework' ),
                'type' => Controls_Manager::CHOOSE,
                'default' => 'before',
                'options' => [
                    'before' => [
                        'title' => __( 'Before', 'ova_framework' ),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'after' => [
                        'title' => __( 'After', 'ova_framework' ),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
            ]
        );

        $this->add_control(
            'currency_vertical_position',
            [
                'label' => __( 'Vertical Position', 'ova_framework' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'top' => [
                        'title' => __( 'Top', 'ova_framework' ),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'middle' => [
                        'title' => __( 'Middle', 'ova_framework' ),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'bottom' => [
                        'title' => __( 'Bottom', 'ova_framework' ),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors_dictionary' => [
                    'top' => 'top',
                    'middle' => 'middle',
                    'bottom' => 'bottom',
                ],
                'selectors' => [
                    '{{WRAPPER}} .currency-icon' => 'vertical-align: {{VALUE}}',
                ],
                'condition' => [
                    'currency_symbol!' => '',
                ],
            ]
        );
        
        $this->add_control(
            'fractional_part_style',
            [
                'label' => __( 'Fractional Part', 'ova_framework' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'currency_symbol!' => '',
                ],
            ]
        );

        $this->add_control(
            'fractional_part_size',
            [
                'label' => __( 'Size', 'ova_framework' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .pricing .price-format' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'currency_symbol!' => '',
                ],
            ]
        );

        $this->add_control(
            'fractional_part_position',
            [
                'label' => __( 'Vertical Position', 'ova_framework' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'top' => [
                        'title' => __( 'Top', 'ova_framework' ),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'middle' => [
                        'title' => __( 'Middle', 'ova_framework' ),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'bottom' => [
                        'title' => __( 'Bottom', 'ova_framework' ),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors_dictionary' => [
                    'top' => 'top',
                    'middle' => 'middle',
                    'bottom' => 'bottom',
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-format' => 'vertical-align: {{VALUE}}',
                ],
                'condition' => [
                    'currency_symbol!' => '',
                ],
            ]
        );

        $this->add_control(
            'duration_style',
            [
                'label' => __( 'Description', 'ova_framework' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'currency_symbol!' => '',
                ],
            ]
        );
        $this->add_control(
            'duration_padding',
            [
                'label' => __( 'Padding', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .pricing .duration' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'duration_margin',
            [
                'label' => __( 'Margin', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .pricing .duration' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'duration_color',
            [
                'label' => __( 'Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .pricing .duration' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'duration_typography',
                'selector' => '{{WRAPPER}} .container-price .content-price .pricing .duration',
            ]
        );

        $this->end_controls_section();
        // END Pricing
        
        //Divider style
        $this->start_controls_section(
            'section_fdivider_style',
            [
                'label' => __( 'Divider', 'ova_framework' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_control(
            'divider-color',
            [
                'label' => __( 'Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ova-divider .divider' => 'border-bottom-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'divider-weight',
            [
                'label' => __( 'Weight', 'ova_framework' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 1,
                ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ova-divider .divider' => 'border-bottom-width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'divider-gap',
            [
                'label' => __( 'Gap', 'ova_framework' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ova-divider' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
        //End Divider style
        

        // Features
        $this->start_controls_section(
            'section_features_list_style',
            [
                'label' => __( 'Features', 'ova_framework' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_control(
            'features_list_bg_color',
            [
                'label' => __( 'Background Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .features-list' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'features_list_padding',
            [
                'label' => __( 'Padding', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .features-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'features_list_margin',
            [
                'label' => __( 'Margin', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .features-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'features_list_color',
            [
                'label' => __( 'Color Text', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .features-list li .list-item' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'features_list_typography',
                'selector' => '{{WRAPPER}} .container-price .content-price .ova-price .features-list li .list-item',
            ]
        );

         $this->add_control(
            'features_icon_color',
            [
                'label' => __( 'Color Icon', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .features-list li i' => 'color: {{VALUE}}',
                ],
            ]
        );

            $this->add_control(
            'font_size_icon',
            [
                'label' => __( 'Font Size Icon', 'ova-framework' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}}  .container-price .content-price .ova-price .features-list li i:before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'features_list_alignment',
            [
                'label' => __( 'Alignment List', 'ova_framework' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'ova_framework' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'ova_framework' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'ova_framework' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .features-list' => 'text-align: {{VALUE}}',
                ],
            ]
        );

    
        $this->end_controls_section();
        // END Features

        // Footer
        $this->start_controls_section(
            'section_footer_style',
            [
                'label' => __( 'Footer', 'ova_framework' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_control(
            'footer_bg_color',
            [
                'label' => __( 'Background Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'footer_padding',
            [
                'label' => __( 'Padding', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'footer_margin',
            [
                'label' => __( 'Margin', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'heading_footer_button',
            [
                'label' => __( 'Button', 'ova_framework' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'button_text!' => '',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'tab_button_normal',
            [
                'label' => __( 'Normal', 'ova_framework' ),
                'condition' => [
                    'button_text!' => '',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Text Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .container-price .content-price .button a',
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __( 'Background Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} button',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label' => __( 'Border Radius', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_padding',
            [
                'label' => __( 'Text Padding', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_margin',
            [
                'label' => __( 'Text Margin', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_hover',
            [
                'label' => __( 'Hover', 'ova_framework' ),
                'condition' => [
                    'button_text!' => '',
                ],
            ]
        );

        $this->add_control(
            'button_hover_color',
            [
                'label' => __( 'Text Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button:hover a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_hover_color',
            [
                'label' => __( 'Background Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => __( 'Border Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .button:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // END Footer

        //Ribbon style
        $this->start_controls_section(
                'section_ribbon_style',
                [
                    'label' => __( 'Ribbon', 'ova_framework' ),
                    'tab' => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                    'condition' => [
                        'show_ribbon' => 'yes',
                    ],
                ]
            );

        $this->add_control(
                'ribbon_bg_color',
                [
                    'label' => __( 'Background Color', 'ova_framework' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .container-price .content-price .ova-price .ribbon span' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

        $this->add_control(
            'ribbon_text_color',
            [
                'label' => __( 'Text Color', 'ova_framework' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ribbon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ribbon_padding',
            [
                'label' => __( 'Padding', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ribbon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ribbon_border_radius',
            [
                'label' => __( 'Border Radius', 'ova_framework' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .container-price .content-price .ova-price .ribbon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ribbon_typography',
                'selector' => '{{WRAPPER}} .container-price .content-price .ova-price .ribbon',
            ]
        );

        $this->end_controls_section();
    //End Ribbon style

        
    // End Style Pricing

    /*
     * End Style
     */

    }

    private function get_currency_symbol( $symbol_name ) {
        $symbols = [
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'pound' => '&#163;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'baht' => '&#3647;',
            'yen' => '&#165;',
            'won' => '&#8361;',
            'guilder' => '&fnof;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'rupee' => '&#8360;',
            'indian_rupee' => '&#8377;',
            'real' => 'R$',
            'krona' => 'kr',
        ];

        return isset( $symbols[ $symbol_name ] ) ? $symbols[ $symbol_name ] : '';
    }

    protected function render() {

        $settings = $this->get_settings();
        $currency_position = ! empty( $settings['currency_position'] ) ? $settings['currency_position'] : 'before';
        $symbol = '';

        if ( ! empty( $settings['currency_symbol'] ) ) {
            if ( 'custom' !== $settings['currency_symbol'] ) {
                $symbol = $this->get_currency_symbol( $settings['currency_symbol'] );
            } else {
                $symbol = $settings['currency_symbol_custom'];
            }
        }
        $currency_format = empty( $settings['currency_format'] ) ? '.' : $settings['currency_format'];
        $price = explode( $currency_format, $settings['price'] );
        $intpart = $price[0];
        $fraction = '';
        if ( 2 === count( $price ) ) {
            $fraction = $price[1];
        }
        
        ?>
        <div class="container-price">
            <div class="content-price">
                <div class="ova-price">

                    <?php if( 'yes' === $settings['show_ribbon'] ) : ?>
                        <div class="ribbon second_font">
                            <span><?php echo $settings['ribbon_title']; ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="content-price-title">
                        <span class="title second_font"><?php echo $settings['content_title']; ?></span>
                    </div>
                    <div class="pricing">

                        <?php if( 'yes' === $settings['sale'] && ! empty( $settings['original_price'] ) ) : ?>
                            <span class="sale"><?php echo $symbol.$settings['original_price']; ?></span>
                        <?php endif; ?>

                        <?php if( $currency_position === 'before' ) : ?>
                            <span class="currency-icon"><?php echo $symbol; ?></span>
                        <?php endif; ?>

                    <?php if ( '.' == $currency_format ) : ?>
                        <span class="price"><?php echo $intpart; ?></span>
                        <span class="price-format"><?php echo $fraction; ?></span>

                        <?php if( $currency_position === 'after' ) : ?>
                            <span class="currency-icon"><?php echo $symbol; ?></span>
                        <?php endif; ?>

                    <?php else: ?>
                        <span class="price">
                            <?php echo $intpart; ?>
                        </span>

                        <?php if( $currency_position === 'after' ) : ?>
                            <span class="currency-icon"><?php echo $symbol; ?></span>
                        <?php endif; ?>

                    <?php endif; ?>

                        <div class="price-descrption">
                            <span class="duration"><?php echo $settings['description_price']; ?></span>
                        </div>
                    </div>

                    <div class="ova-divider">
                        <p class="divider"></p>
                    </div>
                    
                    <?php if ( ! empty( $settings['features_list'] ) ) : ?>
                    <ul class="features-list">
                        <?php foreach ($settings['features_list'] as $index => $item) : ?>
                        
                            <li class="elementor-repeater-item-<?php echo $item['_id']; ?>">
                                <i data-feather="<?php echo $item['icon_class']; ?>"></i>
                                <span class="list-item second_font">
                                    <?php echo $item['item_text']; ?>
                                </span>
                            </li>

                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>

                </div>

                <div class="button">
                    <a href="<?php echo $settings['link']['url'] ? $settings['link']['url'] : '#'; ?>">
                        <?php echo $settings['button_text'] ? $settings['button_text'] : 'CHOOSE PLAN'; ?>
                    </a>
                </div>
            </div>
        </div>

<?php
    }
// end render
}


