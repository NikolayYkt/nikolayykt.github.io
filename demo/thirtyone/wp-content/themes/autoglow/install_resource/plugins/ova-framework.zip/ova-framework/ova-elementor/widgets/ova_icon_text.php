<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_icon_text extends Widget_Base {

	public function get_name() {
		return 'ova_icon_text';
	}

	public function get_title() {
		return __( 'Package Service 4', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'flaticon-car-service', 'ova-framework' ),
				
			]
		);

	$this->add_control(
			'heading',
			[
				'label' => __( 'Heading Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('Schedule an Appointment ','ova-framework'),
			]
		);
		$this->add_control(
			'heading2',
			[
				'label' => __( 'Heading Title2', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('Call for more details or to schedule an appointment.','ova-framework'),
			]
		);


		$this->add_control(
			'text',
			[
				'label' => __( 'Text Button', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'Book Appointment', 'ova-framework' ),
				'placeholder' => __( 'Book Appointment', 'ova-framework' ),
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link Button', 'ova-framework' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
				'default' => [
					'url' => '#',
				],
			]
		);

		$this->add_control(
			'type',
			[
				'label' => __( 'Type Button', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'type1',
				'options' => [
					'type1' => "Type 1",
					'type2' => "Type 2",
					'type3' => "Type 3",
					'type4' => "Type 4",
				]
			]
		);

		$this->add_control(
			'size',
			[
				'label' => __( 'Size Button', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'medium',
				'options' => [
					'tiny' => "Tiny",
					'small' => "Small",
					'medium' => "Medium",
					'large' => "Large",
				]
			]
		);

	

		$this->end_controls_section();

			$this->start_controls_section(
			'section_icon_text',
			[
				'label' => __( 'ICON AND TEXT', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color Icon ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pk3-sev .pk3-icon i:before' => 'color : {{VALUE}};',
				],
			]
		);
				$this->add_control(
			'font_size_icon',
			[
				'label' => __( 'Font Size', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .pk3-sev .pk3-icon i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pk3-sev .pk3-icon svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

					$this->add_responsive_control(
			'margin_icon',
			[
				'label' => __( 'Margin Icon', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pk3-sev .pk3-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
			$this->add_control(
			'color_title',
			[
				'label' => __( 'Color Heading Title ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pk3-sev .pk3-icon .ova-icon span .pk3-title' => 'color : {{VALUE}};',
				],
			]
		);
			$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_heading_typography',
				'selector' => '{{WRAPPER}} .pk3-sev .pk3-icon .ova-icon span .pk3-title',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);
				$this->add_control(
			'color_title2',
			[
				'label' => __( 'Color Heading Title2 ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pk3-sev .pk3-icon .ova-icon span .pk3-title2' => 'color : {{VALUE}};',
				],
			]
		);

				$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_sub_typography',
				'selector' => '{{WRAPPER}} .pk3-sev .pk3-icon .ova-icon span .pk3-title2',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);


					$this->add_control(
			'background_color_pk3',
			[
				'label' => __( 'Background Color Banner', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pk3-sev' => 'background-color : {{VALUE}};',
				],
			]
		);

	
		$this->end_controls_section();




		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style Button', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
	
			

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_button',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);


		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => __( 'Normal', 'elementor' ),
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label' => __( 'Text Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .ova_button' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type3' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,

				'selectors' => [
					'{{WRAPPER}} .ova_button' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type2' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type3' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type4' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => __( 'Hover', 'elementor' ),
			]
		);

		$this->add_control(
			'hover_color',
			[
				'label' => __( 'Text Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_button:hover, {{WRAPPER}} .ova_button:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_background_hover_color',
			[
				'label' => __( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_button:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type2:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type3:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type4:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label' => __( 'Border Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .ova_button:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type2:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type3:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .ova_button.type4:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .ova_button',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_responsive_control(
			'text_padding',
			[
				'label' => __( 'Padding', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'button_align',
			[
				'label' => __( 'Alignment', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .pk3-sev .pk3-btn .wrap_ova_button a.ova_button' => 'text-align: {{VALUE}}',
				]
			]
		);

		$this->end_controls_section();


	}

	protected function render() {
		$settings = $this->get_settings();

		$icon = $settings['class_icon'];

		$title = $settings['heading'];
		$title2 = $settings['heading2'];

		$text = $settings['text'];

		$target = $settings['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';
	
		?>
		<div class="pk3-sev">
			<div class="pk3-icon">
			    <i class = "<?php echo esc_html( $icon ) ?>"></i>
				<div class="ova-icon">
					 <span>
						<span class="pk3-title second_font"><?php echo $title; ?></span>
						<span class="pk3-title2 second_font"><?php echo $title2; ?></span>
					</span>
				</div>
			</div>

			<div class="pk3-btn">
				<div class="wrap_ova_button">
					<a class="ova_button second_font <?php echo $settings['type'] . ' ' . $settings['size'] ?>" href="<?php echo $settings['link']['url'] ?>" <?php echo $target . ' ' . $nofollow ?> ><?php echo esc_html( $text ) ?></a>
				</div>
		    </div>
	    </div>

		<?php

	}
}


