<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;
use Elementor\Group_Control_Css_Filter;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_tabs extends Widget_Base {

	public function get_name() {
		return 'ova_tabs';
	}

	public function get_title() {
		return __( 'Ova Tabs', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-tabs';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		//Tabs
		 $this->start_controls_section(
            'section_ova_tabs',
            [
                'label' => __( 'Tabs', 'ova-framework' ),
            ]
        );

            $this->add_control(
                'version',
                [
                    'label' => __( 'Version', 'ova-framework' ),
                    'type'  => Controls_Manager::SELECT,
                    'default' => 'version_1',
                    'options' => [
                        'version_1' => esc_html__( 'Version 1', 'ova-framework' ),
                        'version_2' => esc_html__( 'Version 2', 'ova-framework' ),
                    ]
                ]
            );

            // Tabs version 1
            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
                'item_id',
                [
                    'label'     => __( 'Tab ID', 'ova-framework' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( '#', 'ova-framework' ),
                ]
            );

            $repeater->add_control(
                'item_class',
                [
                    'label'     => __( 'Tab Class', 'ova-framework' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( '#', 'ova-framework' ),
                ]
            );

            $repeater->add_control(
                'item_text',
                [
                    'label'     => __( 'Text', 'ova-framework' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( 'Tab', 'ova-framework' ),
                ]
            );

            $repeater->add_control(
                'ova_tab_image',
                [
                    'label'     => __( 'Choose Image', 'ova-framework' ),
                    'type'      => Controls_Manager::MEDIA,
                    'dynamic'   => [
                        'active' => true,
                    ],
                ]
            );

            $default_icon = 'far fa-check-circle';

            $repeater->add_control(
                'icon_class',
                [
                    'label'     => __( 'Icon Class', 'ova-framework' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( 'far fa-check-circle', 'ova-framework' ),
                ]
            );

            $this->add_control(
                'tab_list',
                [
                    'type'      => Controls_Manager::REPEATER,
                    'fields'    => $repeater->get_controls(),
                    'default'   => [
                        [
                            'item_text'     => __( 'Mid-Size Car', 'ova-framework' ),
                            'ova_tab_image' => [
                                'url' => '',
                            ],
                            'icon_class' => 'fas fa-car-side fa-3x',
                            'item_id'    => 'mid-size',
                            'item_class' => 'mid-size',
                        ],
                        [
                            'item_text'     => __( 'Small Size Car', 'ova-framework' ),
                            'ova_tab_image' => [
                                'url' => '',
                            ],
                            'icon_class' => 'fas fa-truck-moving fa-3x',
                            'item_id'    => 'small-size',
                            'item_class' => 'small-size',
                        ],
                        [
                            'item_text'     => __( 'Full-Size Car', 'ova-framework' ),
                            'ova_tab_image' => [
                                'url' => '',
                            ],
                            'icon_class' => 'fas fa-truck fa-3x',
                            'item_id'    => 'full-size',
                            'item_class' => 'full-size',
                        ],
                        [
                            'item_text'     => __( 'Pickup Truck', 'ova-framework' ),
                            'ova_tab_image' => [
                                'url' => '',
                            ],
                            'icon_class' => 'fas fa-truck-pickup fa-3x',
                            'item_id'    => 'pickup-truck',
                            'item_class' => 'pickup-truck',
                        ],
                    ],
                    'condition' => [
                        'version' => ['version_1'],
                    ],
                ]
            );
            // End

            // Tabs version 2
            $repeater_v2 = new \Elementor\Repeater();

            $repeater_v2->add_control(
                'item_id_v2',
                [
                    'label'     => __( 'Tab ID', 'ova-framework' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( '#', 'ova-framework' ),
                ]
            );

            $repeater_v2->add_control(
                'item_class_v2',
                [
                    'label'     => __( 'Tab Class', 'ova-framework' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( '#', 'ova-framework' ),
                ]
            );

            $repeater_v2->add_control(
                'item_text_v2',
                [
                    'label'     => __( 'Text', 'ova-framework' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( 'Tab', 'ova-framework' ),
                ]
            );

            $repeater_v2->add_control(
                'icon_class_v2',
                [
                    'label'     => __( 'Icon Class', 'ova-framework' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( 'check-circle', 'ova-framework' ),
                ]
            );

            $this->add_control(
                'tab_list_v2',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'fields'  => $repeater_v2->get_controls(),
                    'default' => [
                        [
                            'item_text_v2'  => __( 'Our Mission', 'ova-framework' ),
                            'icon_class_v2' => 'check-circle',
                            'item_id_v2'    => 'our-mission',
                            'item_class_v2' => 'our-mission',
                        ],
                        [
                            'item_text_v2'  => __( 'Our Vision', 'ova-framework' ),
                            'icon_class_v2' => 'check-circle',
                            'item_id_v2'    => 'our-vision',
                            'item_class_v2' => 'our-vision',
                        ],
                        [
                            'item_text_v2'  => __( 'Values', 'ova-framework' ),
                            'icon_class_v2' => 'check-circle',
                            'item_id_v2'    => 'values',
                            'item_class_v2' => 'values',
                        ],
                    ],
                    'condition' => [
                        'version' => ['version_2'],
                    ],
                ]
            );

            $this->add_responsive_control(
            'tab_align',
            [
                'label' => __( 'Alignment', 'ova_framework' ),
                'type'  => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title'  => __( 'Left', 'ova_framework' ),
                        'icon'   => 'eicon-text-align-left',
                    ],
                    'center'     => [
                        'title'  => __( 'Center', 'ova_framework' ),
                        'icon'   => 'eicon-text-align-center',
                    ],
                    'flex-end'   => [
                        'title'  => __( 'Right', 'ova_framework' ),
                        'icon'   => 'eicon-text-align-right',
                    ],
                ],
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .ova_tabs' => 'justify-content: {{VALUE}};',
                ],
            ]
        );
            // End

        $this->end_controls_section();
        //End tabs

        //Tabs style

        $this->start_controls_section(
            'section_tabs_style',
            [
                'label'      => __( 'Tabs', 'ova_framework' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->start_controls_tabs( 'tabs_style' );

        //Normal
       $this->start_controls_tab(
            'tab_normal',
            [
                'label' => __( 'Normal', 'ova_framework' ),
            ]
        );

            $this->add_control(
                'item_bg_color',
                [
                    'label' => __( 'Background Color', 'ova_framework' ),
                    'type'  => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items' => 'background-color: {{VALUE}}',
                    ],
                    'condition' => [
                        'version' => ['version_1'],
                    ],
                ]
            );

            $this->add_control(
                'item_text_color',
                [
                    'label' => __( 'Text Color', 'ova_framework' ),
                    'type'  => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items .ova_item_text'             => 'color: {{VALUE}}',
                        '{{WRAPPER}} .ova_tabs.version_2 .ova_tab_items_v2 span.ova_item_text_v2'   => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'      => 'item_text_typography',
                    'selector'  => '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items .ova_item_text',
                    'condition' => [
                        'version' => ['version_1'],
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'      => 'item_text_v2_typography',
                    'selector'  => '{{WRAPPER}} .ova_tabs.version_2 .ova_tab_items_v2 .ova_item_text_v2',
                    'condition' => [
                        'version' => ['version_2'],
                    ],
                ]
            );

            $this->add_responsive_control(
                'tab_image_size',
                [
                    'label' => __( 'Width Image', 'ova_framework' ) . ' (%)',
                    'type'  => Controls_Manager::SLIDER,
                    'tablet_default' => [
                        'unit' => '%',
                    ],
                    'mobile_default' => [
                        'unit' => '%',
                    ],
                    'size_units' => [ '%' ],
                    'range' => [
                        '%' => [
                            'min' => 5,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items .ova_tab_img img' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => [
                        'version' => ['version_1'],
                    ],
                ]
            );

            $this->add_control(
            	'item_icon_color',
            	[
            		'label' => __( 'Icon Color', 'ova_framework' ),
                    'type'  => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items .ova_tab_icon i'         => 'color: {{VALUE}}',
                        '{{WRAPPER}} .ova_tabs.version_2 .ova_tab_items_v2 .ova_tab_icon_v2 svg' => 'color: {{VALUE}}',
                    ],
            	]
            );

        $this->end_controls_tab();
        //End normal

        //Hover
        $this->start_controls_tab(
            'tab_hover',
            [
                'label' => __( 'Hover', 'ova_framework' ),
            ]
        );

            $this->add_control(
                'item_bg_color_hover',
                [
                    'label' => __( 'Background Color', 'ova_framework' ),
                    'type'  => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items:hover' => 'background-color: {{VALUE}}',
                    ],
                    'condition' => [
                        'version' => ['version_1'],
                    ],
                ]
            );

            $this->add_control(
                'item_text_color_hover',
                [
                    'label' => __( 'Text Color', 'ova_framework' ),
                    'type'  => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items:hover .ova_item_text'       => 'color: {{VALUE}}',
                        '{{WRAPPER}} .ova_tabs.version_2 .ova_tab_items_v2:hover .ova_item_text_v2' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'      => 'item_text_typography_hover',
                    'selector'  => '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items:hover .ova_item_text',
                    'condition' => [
                        'version' => ['version_1'],
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'      => 'item_text_v2_typography_hover',
                    'selector'  => '{{WRAPPER}} .ova_tabs.version_2 .ova_tab_items_v2:hover .ova_item_text_v2',
                    'condition' => [
                        'version' => ['version_2'],
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Css_Filter::get_type(),
                [
                    'name'      => 'css_filters_hover',
                    'selector'  => '{{WRAPPER}} .ova_tabs .ova_tab_items:hover .ova_tab_img img',
                    'condition' => [
                        'version' => ['version_1'],
                    ],
                ]
            );

            $this->add_control(
            	'item_icon_color_hover',
            	[
            		'label' => __( 'Icon Color', 'ova_framework' ),
                    'type'  => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ova_tabs.version_1 .ova_tab_items:hover .ova_tab_icon i'          => 'color: {{VALUE}}',
                        '{{WRAPPER}} .ova_tabs.version_2 .ova_tab_items_v2:hover .ova_tab_icon_v2 svg'  => 'color: {{VALUE}}',
                    ],
            	]
            );

            $this->end_controls_tab();
        //End Hover

        $this->end_controls_tabs();
        //End tab normal, hover

        $this->end_controls_section();
        //End Tabs style

	}

	protected function render() {

		$settings = $this->get_settings();
        $version  = $settings['version'];

		?>

		<div class="ova_tabs <?php echo $version; ?>">
        <!-- Version 1 -->
			<?php if ( !empty( $settings['tab_list'] ) && $version === 'version_1' ) : ?>
				<?php foreach ($settings['tab_list'] as $index => $item) : 
					$item_class    = $item['item_class']        ? $item['item_class']       : 'tab_class';
					$item_id 	   = $item['item_id'] 	        ? $item['item_id']          : 'tab_id';
                    $icon_class    = $item['icon_class']        ? $item['icon_class']       : 'far fa-check-circle';
                    $img_url       = $item['ova_tab_image']['url']  ? $item['ova_tab_image']['url'] : '';
                    

                    if ( $index === 0 ) : ?>

                        <div class="ova_tab_items active <?php echo $item_class; ?>" data-id="<?php echo $item_id; ?>">
            
                            <?php if( !empty($img_url) ): ?>
                                <div class="ova_tab_img"><img src="<?php echo $img_url; ?>" alt="<?php echo $item['item_text']; ?>"></div>
                            <?php else: ?>
                              <div class="ova_tab_icon"><i class="<?php echo $icon_class; ?>"></i></div>
                            <?php endif; ?>

                            <span class="ova_item_text second_font"><?php echo $item['item_text']; ?></span>
                        </div>

                    <?php else: ?>

                        <div class="ova_tab_items <?php echo $item_class; ?>" data-id="<?php echo $item_id; ?>">

                            <?php if( !empty($img_url) ): ?>
                                <div class="ova_tab_img"><img src="<?php echo $img_url; ?>" alt="<?php echo $item['item_text']; ?>"></div>
                            <?php else: ?>
                              <div class="ova_tab_icon"><i class="<?php echo $icon_class; ?>"></i></div>
                            <?php endif; ?>

                            <span class="ova_item_text"><?php echo $item['item_text']; ?></span>
                        </div>

                    <?php endif; ?>

		<?php endforeach; endif; ?>

        <!-- Version 2 -->
        <?php if ( !empty( $settings['tab_list_v2'] ) && $version === 'version_2' ) : ?>
                <?php foreach ( $settings['tab_list_v2'] as $index_v2 => $item_v2 ) : 

                    $item_class_v2    = $item_v2['item_class_v2'] ? $item_v2['item_class_v2'] : 'tab_class';
                    $item_id_v2       = $item_v2['item_id_v2']    ? $item_v2['item_id_v2']    : 'tab_id';
                    $icon_class_v2    = $item_v2['icon_class_v2'] ? $item_v2['icon_class_v2'] : 'check-circle';
                    $item_text_v2     = $item_v2['item_text_v2']  ? $item_v2['item_text_v2']  : 'Tab';
                    

                    if ( $index_v2 === 0 ) : ?>

                        <div class="ova_tab_items_v2 active <?php echo $item_class_v2; ?>" data-id="<?php echo $item_id_v2; ?>">
                            <div class="ova_tab_icon_v2"><i data-feather="<?php echo $icon_class_v2; ?>"></i></div>
                            <span class="ova_item_text_v2 second_font"><?php echo $item_text_v2; ?></span>
                        </div>

                    <?php else: ?>

                        <div class="ova_tab_items_v2 <?php echo $item_class_v2; ?>" data-id="<?php echo $item_id_v2; ?>">
                            <div class="ova_tab_icon_v2"><i data-feather="<?php echo $icon_class_v2; ?>"></i></div>
                            <span class="ova_item_text_v2"><?php echo $item_text_v2; ?></span>
                        </div>

                    <?php endif; ?>

        <?php endforeach; endif; ?>

		</div>

		<?php
	}
}
