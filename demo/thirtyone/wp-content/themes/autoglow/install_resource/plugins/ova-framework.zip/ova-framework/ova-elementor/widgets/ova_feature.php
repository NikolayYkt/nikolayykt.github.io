<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_feature extends Widget_Base {

	public function get_name() {
		return 'ova_feature';
	}

	public function get_title() {
		return __( 'Feature', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'version',
			[
				'label' => __( 'Version', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'version_1',
				'options' => [
					'version_1' => esc_html__( 'Version 1', 'ova-framework' ),
					'version_2' => esc_html__( 'Version 2', 'ova-framework' ),
					'version_3' => esc_html__( 'Version 3', 'ova-framework' ),
				]
			]
		);
		

		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'flaticon-parthenon',
			]
		);

		$this->add_control(
			'class_icon_hover',
			[
				'label' => __( 'Class Icon Hover', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'flaticon-parthenon',
				'condition' => [
					'version' => 'version_1',
				],
			]
		);

		

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Your Goverment','ova-framework'),
			]
		);
		$this->add_control(
			'show_box_shadow',
			[
				'label' => __( 'Show Box Shadow', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ova-framework' ),
				'label_off' => __( 'Hide', 'ova-framework' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'version' => 'version_2',
				],
			]
		);

		$this->add_control(
			'excerpt',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __( 'City employment issue opportunities are position descriptions are listed.','ova-framework' ),
				'condition' => [
					'version!' => 'version_1',
				],
			]
		);

		$this->add_control(
			'read_more',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Read More','ova-framework'),
				'condition' => [
					'version' => 'version_1',
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => '#',
			]
		);


		$this->end_controls_section();


		$this->start_controls_section(
			'section_icon',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'font_size_icon',
			[
				'label' => __( 'Font Size', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'max' => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova_feature .icon span::before' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature .icon span::before' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_icon',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_feature .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();


		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_feature .title a',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature .title a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_title_hover',
			[
				'label' => __( 'Color hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature .title a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_title',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_feature .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_excerpt',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version!' => 'version_1',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typography',
				'selector' => '{{WRAPPER}} .ova_feature .content-sub .excerpt, {{WRAPPER}} .ova_feature.version_3 .items .excerpt p',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_excerpt',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature .content-sub .excerpt' => 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_feature.version_3 .items .excerpt p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'margin_excerpt',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_feature .content-sub .excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ova_feature.version_3 .items .excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_readmore',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version' => 'version_1',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'readmore_typography',
				'selector' => '{{WRAPPER}} .ova_feature .content-sub .readmore',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_readmore',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature .content-sub .readmore' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_readmore_hover',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature .content-sub .readmore:hover' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'margin_readmore',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_feature .content-sub .readmore' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon_hover',
			[
				'label' => __( 'Icon Hover', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version' => 'version_1',
				],
			]
		);

		$this->add_control(
			'font_size_icon_hover',
			[
				'label' => __( 'Font Size', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'max' => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova_feature .icon-hide span::before' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'color_icon_hover',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature .icon-hide span::before ' => 'color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		
	}

	protected function render() {
		$settings = $this->get_settings();

		$version = $settings['version'];

		$class_icon = $settings['class_icon'];
		$class_icon_hover = $settings['class_icon_hover'];
		$title = $settings['title'];
		$excerpt = $settings['excerpt'];
		$read_more = $settings['read_more'];
		$link = $settings['link'];

		$show_box_shadow = $settings['show_box_shadow'];

		$class_box_shadow = $show_box_shadow == 'yes' ? 'box-shadow' : '';
	
		?>

		<?php if( $version == 'version_1' ){ ?>
		<div class="ova_feature version_1">
			<div class="items">
				
			
			<?php if( ! empty( $class_icon ) ) { ?>
				<div class="icon">
					<span class="<?php echo esc_attr( $class_icon ) ?>"></span>
				</div>
				<?php } ?>

				<?php if( ! empty( $title ) ){ ?>
					<h3 class="title">
						<a class="second_font" href="<?php echo esc_url( $link ) ?>">
							<?php echo $title ?>
						</a>
					</h3>
				<?php } ?>

				<div class="content-sub">
					<?php if( ! empty( $excerpt ) ){ ?>
					<p class="excerpt">
						<?php echo esc_html( $excerpt ) ?>
					</p>
					<?php } ?>
					
					<?php if( ! empty( $read_more ) ){ ?>
					<a href="<?php echo esc_url( $link ) ?>" class="second_font readmore">
						<?php echo esc_html( $read_more ) ?>
						<i data-feather="arrow-right"></i>
					</a>
					<?php } ?>
				</div>
				<?php if( ! empty( $class_icon_hover ) ) { ?>
				<div class="icon-hide">
					<span class="<?php echo esc_attr( $class_icon_hover ) ?>"></span>
				</div>
				<?php } ?>
			</div>
		</div>
		<?php } else if( $version == 'version_2' ){ ?>
		<div class="ova_feature version_2 <?php echo esc_attr( $class_box_shadow ) ?>">
			<div class="items">
				
			<?php if( ! empty( $class_icon ) ) { ?>
				<div class="icon">
					<span class="<?php echo esc_attr( $class_icon ) ?>"></span>
				</div>
				<?php } ?>

				<?php if( ! empty( $title ) ){ ?>
					<h3 class="title">
						<a class="second_font" href="<?php echo esc_url( $link ) ?>">
							<?php echo $title ?>
						</a>
					</h3>
				<?php } ?>

			</div>
		</div>
		<?php } else if( $version == 'version_3' ){ ?>
			<div class="ova_feature version_3">
			<div class="items">
				
			<?php if( ! empty( $class_icon ) ) { ?>
				<div class="icon">
					<span class="<?php echo esc_attr( $class_icon ) ?>"></span>
				</div>
				<?php } ?>

				<?php if( ! empty( $title ) ){ ?>
					<h3 class="title">
						<a class="second_font" href="<?php echo esc_url( $link ) ?>">
							<?php echo $title ?>
						</a>
					</h3>
				<?php } ?>

				<?php if( ! empty( $excerpt ) ){ ?>
					<div class="excerpt">
						<p>
							<?php echo esc_html( $excerpt ) ?>
						</p>
					</div>
				<?php } ?>

			</div>
		</div>
		<?php
		}
		// end if version
	}
}


