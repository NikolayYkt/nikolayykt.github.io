<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_list_checked_grid extends Widget_Base {

	public function get_name() {
		return 'ova_list_checked_grid';
	}

	public function get_title() {
		return __( 'List Checked Grid', 'ova-framework' );
	}

	public function get_icon() {
		return 'fas fa-check';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		//SECTION CONTENT
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);


		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title',
			[
				'label'   => __( 'Title', 'ova-framework' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => __('Your Title', 'ova-framework'),
			]
		);

		$repeater->add_control(
			'class_icon',
			[
				'label'   => __( 'Class Icon', 'ova-framework' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'check-circle',
			]
		);

			$this->add_control(
				'tabs',
				[
					'label'   => __( 'Tabs', 'ova-framework' ),
					'type'    => Controls_Manager::REPEATER,
					'fields'  => $repeater->get_controls(),
					'default' => [
						[
							'title' 	 => __( 'Over 250,000 cleans', 'ova-framework' ),
							'class_icon' => __( 'check-circle', 'ova-framework' ),
						],
						[
							'title' 	 => __( '100% Satisfaction', 'ova-framework' ),
							'class_icon' => __( 'check-circle', 'ova-framework' ),
						],
						[
							'title' 	 => __( 'Eco-Friendly Products', 'ova-framework' ),
							'class_icon' => __( 'check-circle', 'ova-framework' ),
						],
						[
							'title' 	 => __( 'Most Cost Effective', 'ova-framework' ),
							'class_icon' => __( 'check-circle', 'ova-framework' ),
						],
					],
				]
			);

			$this->add_control(
				'columns',
				[
					'label' => __( 'Columns', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'col2',
					'options' => [
						'col1' => __( 'Columns 1', 'ova-framework' ),
						'col2' => __( 'Columns 2', 'ova-framework' ),
						'col3' => __( 'Columns 3', 'ova-framework' ),
					]
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'column_gap',
				[
					'label' => __( 'Column Gap', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px'],
					'range' => [
						'px' => [
							'max' => 100,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_list_checked_grid' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'row_gap',
				[
					'label' => __( 'Row Gap', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px'],
					'range' => [
						'px' => [
							'max' => 100,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_list_checked_grid' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'width_icon',
				[
					'label' => __( 'Width', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px'],
					'range' => [
						'px' => [
							'max' => 100,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_list_checked_grid .content_grid svg' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_icon',
				[
					'label' => __( 'Color ', 'ova-framework' ),
					'type'  => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_list_checked_grid .content_grid svg' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_icon',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_list_checked_grid .content_grid svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title_typography',
					'selector' 	=> '{{WRAPPER}} .ova_list_checked_grid .content_grid span',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' 	=> __( 'Color ', 'ova-framework' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_list_checked_grid .content_grid span' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_title',
				[
					'label' 	 => __( 'Margin', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_list_checked_grid .content_grid span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings 	= $this->get_settings_for_display();
		$tabs 		= $settings['tabs'];
		$col 		= $settings['columns'];

		?>
		
		<div class="ova_list_checked_grid <?php echo esc_html( $col ); ?>" >
			<?php if( !empty( $tabs ) ) : ?>
				<?php foreach( $tabs as $item ): ?>
					<div class="content_grid">
						<i data-feather="<?php echo esc_html( $item['class_icon'] ); ?>"></i>
						<span><?php echo esc_html__( $item['title'] ); ?></span>
					</div>
			<?php endforeach; endif; ?>

		</div>

		<?php
	}
}
