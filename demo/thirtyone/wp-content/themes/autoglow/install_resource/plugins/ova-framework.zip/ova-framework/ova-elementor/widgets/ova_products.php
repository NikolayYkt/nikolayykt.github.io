<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_products extends Widget_Base {

    public function get_name() {
        return 'ova_products';
    }

    public function get_title() {
        return __( 'Ova Products', 'ova-framework' );
    }

    public function get_icon() {
        return 'fas fa-shopping-cart';
    }

    public function get_categories() {
        return [ 'ovatheme' ];
    }

    public function get_script_depends() {
        // Carousel
        wp_enqueue_style( 'owl-carousel', OVA_PLUGIN_URI.'assets/libs/owl-carousel/assets/owl.carousel.min.css' );
        wp_enqueue_script( 'owl-carousel', OVA_PLUGIN_URI.'assets/libs/owl-carousel/owl.carousel.min.js', array('jquery'), false, true );
        return [ 'script-elementor' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_query',
            [
                'label' => __( 'Query', 'ova-framework' ),
            ]
        );

            $this->add_control(
                'total_product',
                [
                    'label'   => __( 'Total Products', 'ova-framework' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => 10,
                ]
                
            );

            $this->add_control(
                'product_ids',
                    [
                        'label'   => 'Product IDs',
                        'type'    => \Elementor\Controls_Manager::TEXT,
                        'description' => __( 'The product IDs are separated by a mark ",". (1,2,3)', 'ova-framework' ),
                    ]
                );

            $this->add_control(
                'category_ids',
                    [
                        'label'   => 'Category IDs',
                        'type'    => \Elementor\Controls_Manager::TEXT,
                        'description' => __( 'The category IDs are separated by a mark ",". (1,2,3)', 'ova-framework' ),
                    ]
                );

            $this->add_control(
                'category_slug',
                    [
                        'label'   => 'Category Slug',
                        'type'    => \Elementor\Controls_Manager::TEXT,
                        'description' => __( 'The categories slug (or name) are separated by a mark ",". (category-slug-1,category-slug-2,category-slug-3)', 'ova-framework' ),

                        'condition' => [
                            'category_ids[value]' => '',
                        ],
                    ]
                );

            $this->add_control(
                'order_by_product',
                [
                    'label' => __( 'Order By', 'ova-framework' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'date',
                    'options' => [
                        'date' => esc_html__( 'Date', 'ova-framework' ),
                        'title' => esc_html__( 'Title', 'ova-framework' ),
                        'price' => esc_html__( 'Price', 'ova-framework' ),
                        'popularity' => esc_html__( 'Popularity', 'ova-framework' ),
                        'rating' => esc_html__( 'Rating', 'ova-framework' ),
                        'rand' => esc_html__( 'Random', 'ova-framework' ),
                        'menu_order' => esc_html__( 'Menu Order', 'ova-framework' ),
                    ]
                ]
            );

            $this->add_control(
                'order_product',
                [
                    'label' => __( 'Order', 'ova-framework' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'ASC',
                    'options' => [
                        'ASC' => esc_html__( 'ASC', 'ova-framework' ),
                        'DESC' => esc_html__( 'DESC', 'ova-framework' ),
                    ]
                ]
            );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_additional_options',
            [
                'label' => __( 'Additional Options', 'ova-framework' ),
            ]
        );

            $this->add_control(
                'margin_items',
                [
                    'label'   => __( 'Margin Right Items', 'ova-framework' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => 30,
                ]
                
            );

            $this->add_control(
                'item_number',
                [
                    'label'       => __( 'Item Number', 'ova-framework' ),
                    'type'        => Controls_Manager::NUMBER,
                    'description' => __( 'Number Item', 'ova-framework' ),
                    'default'     => 4,
                ]
            );

    

            $this->add_control(
                'slides_to_scroll',
                [
                    'label'       => __( 'Slides to Scroll', 'ova-framework' ),
                    'type'        => Controls_Manager::NUMBER,
                    'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-framework' ),
                    'default'     => 1,
                ]
            );

            $this->add_control(
                'pause_on_hover',
                [
                    'label'   => __( 'Pause on Hover', 'ova-framework' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'options' => [
                        'yes' => __( 'Yes', 'ova-framework' ),
                        'no'  => __( 'No', 'ova-framework' ),
                    ],
                    'frontend_available' => true,
                ]
            );


            $this->add_control(
                'infinite',
                [
                    'label'   => __( 'Infinite Loop', 'ova-framework' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'options' => [
                        'yes' => __( 'Yes', 'ova-framework' ),
                        'no'  => __( 'No', 'ova-framework' ),
                    ],
                    'frontend_available' => true,
                ]
            );

            $this->add_control(
                'autoplay',
                [
                    'label'   => __( 'Autoplay', 'ova-framework' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'options' => [
                        'yes' => __( 'Yes', 'ova-framework' ),
                        'no'  => __( 'No', 'ova-framework' ),
                    ],
                    'frontend_available' => true,
                ]
            );

            $this->add_control(
                'autoplay_speed',
                [
                    'label'     => __( 'Autoplay Speed', 'ova-framework' ),
                    'type'      => Controls_Manager::NUMBER,
                    'default'   => 3000,
                    'step'      => 500,
                    'condition' => [
                        'autoplay' => 'yes',
                    ],
                    'frontend_available' => true,
                ]
            );

            $this->add_control(
                'smartspeed',
                [
                    'label'   => __( 'Smart Speed', 'ova-framework' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => 500,
                ]
            );

            $this->add_control(
                'dot_control',
                [
                    'label'   => __( 'Show Dots', 'ova-framework' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'options' => [
                        'yes' => __( 'Yes', 'ova-framework' ),
                        'no'  => __( 'No', 'ova-framework' ),
                    ],
                    'frontend_available' => true,
                ]
            );

                $this->add_control(
                'nav_control',
                [
                    'label'   => __( 'Show Nav', 'ova-framework' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'options' => [
                        'yes' => __( 'Yes', 'ova-framework' ),
                        'no'  => __( 'No', 'ova-framework' ),
                    ],
                    'frontend_available' => true,
                ]
            );

        $this->end_controls_section();

    }


    protected function render() {
        $settings = $this->get_settings();

        $data_options = [
            'items'                 => $settings['item_number'],
            'slideBy'               => $settings['slides_to_scroll'],
            'margin'                => $settings['margin_items'],
            'autoplayHoverPause'    => $settings['pause_on_hover'] === 'yes' ? true : false,
            'loop'                  => $settings['infinite'] === 'yes' ? true : false,
            'autoplay'              => $settings['autoplay'] === 'yes' ? true : false,
            'autoplayTimeout'       => $settings['autoplay_speed'],
            'smartSpeed'            => $settings['smartspeed'],
            'dots'                  => $settings['dot_control'] === 'yes' ? true : false,
            'nav'                   => $settings['nav_control'] === 'yes' ? true : false,
        ];

        $total_product = $settings['total_product'] ? $settings['total_product'] : 10;
        $order_by_product = $settings['order_by_product'] ? $settings['order_by_product'] : 'date';
        $order_product = $settings['order_product'] ? $settings['order_product'] : 'ASC';

        if ( !empty( $settings['product_ids'] ) ) {

            $product_ids = explode( ",",$settings['product_ids'] );
            $args = [
                'post_type' => 'product',
                'orderby' => $order_by_product,
                'order' => $order_product,
                'post__in' => $product_ids,
            ];
            // sort by price
            if ( $order_by_product === 'price' ) {
                $args = [
                'post_type' => 'product',
                'orderby' => 'meta_value_num',
                'meta_key' => '_price',
                'order' => $order_product,
                'post__in' => $product_ids,
            ];
            }
            //end sort by price


        } else {

            $args = [
                'post_type' => 'product',
                'posts_per_page' => $total_product,
                'orderby' => $order_by_product,
                'order' => $order_product,
            ];

            // sort by price
            if ( $order_by_product === 'price' ) {
                $args = [
                'post_type' => 'product',
                'orderby' => 'meta_value_num',
                'meta_key' => '_price',
                'order' => $order_product,
                'post__in' => $product_ids,
            ];
            }
            //end sort by price
        }

        if ( !empty( $settings['category_ids'] ) ) {
            $category_ids = explode( ",",$settings['category_ids'] );
            $args['tax_query'] = [
                [
                    'taxonomy' => 'product_cat',
                        'field'    => 'term_id',
                        'terms'     =>  $category_ids,
                        'operator'  => 'IN'
                ]
            ];
        }

        if ( !empty( $settings['category_slug'] ) and empty( $settings['category_ids'] ) ) {
            $categories_name = explode( ",",$settings['category_slug'] );
            $args['tax_query'] = [
                [
                    'taxonomy' => 'product_cat',
                        'field'    => 'slug',
                        'terms'     =>  $categories_name,
                        'operator'  => 'IN'
                ]
            ];
        }

        $loop = new \WP_Query( $args );

        ?>
         
        <div class="ova_product_container">
            <div class="woocommerce">
                <ul class="products ova_product_carousel owl-carousel owl-theme" data-options="<?php echo esc_attr(json_encode($data_options)) ?>">

            <?php
            if ( $loop->have_posts() ) {
                while ( $loop->have_posts() ) : $loop->the_post();

                    wc_get_template_part( 'content', 'product' );

                endwhile;
            } else {
                echo __( 'No products found', 'ova-framework' );
            }
            wp_reset_postdata();
        
            ?>
                </ul>
            </div>
        </div>

    <?php
    }
// end render
}


