<?php

namespace ova_framework;

use ova_framework\widgets\ova_menu;
use ova_framework\widgets\ova_logo;
use ova_framework\widgets\ova_header;
use ova_framework\widgets\ova_contact_info;
use ova_framework\widgets\ova_search_popup;
use ova_framework\widgets\ova_language;
use ova_framework\widgets\ova_social;
use ova_framework\widgets\ova_menu_page;
use ova_framework\widgets\ova_skill_bar;
use ova_framework\widgets\ova_heading;
use ova_framework\widgets\ova_education;
use ova_framework\widgets\ova_testimonial;
use ova_framework\widgets\ova_list_checked;
use ova_framework\widgets\ova_list_checked2;
use ova_framework\widgets\ova_list_checked_grid;
use ova_framework\widgets\ova_list_icon;
use ova_framework\widgets\ova_banner;
use ova_framework\widgets\ova_banner2;
use ova_framework\widgets\ova_list_text;
use ova_framework\widgets\ova_feature;
use ova_framework\widgets\ova_box_learnmore;
use ova_framework\widgets\ova_blog;
use ova_framework\widgets\ova_time_countdown;
use ova_framework\widgets\ova_history;
use ova_framework\widgets\ova_feature_box;
use ova_framework\widgets\ova_list_link;
use ova_framework\widgets\ova_box_resource;
use ova_framework\widgets\ova_contact_slide;


use ova_framework\widgets\ova_button;
use ova_framework\widgets\ova_icon;
use ova_framework\widgets\ova_icon_header;
use ova_framework\widgets\ova_icon_banner;
use ova_framework\widgets\ova_our_skill;
use ova_framework\widgets\ova_box_feature_1;
use ova_framework\widgets\ova_box_contact_1;
use ova_framework\widgets\ova_tooltip;
use ova_framework\widgets\ova_pricing;
use ova_framework\widgets\ova_tabs;
use ova_framework\widgets\ova_icon_text;
use ova_framework\widgets\ova_products;
use ova_framework\widgets\ova_image_box;
use ova_framework\widgets\ova_review;
use ova_framework\widgets\ova_percent_box;
use ova_framework\widgets\ova_contact;
use ova_framework\widgets\ova_before_after;




if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly




/**
 * Main Plugin Class
 *
 * Register new elementor widget.
 *
 * @since 1.0.0
 */
class Ova_Register_Elementor {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {
		$this->add_actions();
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function add_actions() {

		// Register Header Footer Category in Pane
	    add_action( 'elementor/elements/categories_registered', array( $this, 'add_hf_category' ) );

	     // Register Ovatheme Category in Pane
	    add_action( 'elementor/elements/categories_registered', array( $this, 'add_ovatheme_category' ) );
	    
		
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'on_widgets_registered' ] );
		

	}

	
	public  function add_hf_category(  ) {
	    \Elementor\Plugin::instance()->elements_manager->add_category(
	        'hf',
	        [
	            'title' => __( 'Header Footer', 'ova-framework' ),
	            'icon' => 'fa fa-plug',
	        ]
	    );

	}

	
	public function add_ovatheme_category(  ) {

	    \Elementor\Plugin::instance()->elements_manager->add_category(
	        'ovatheme',
	        [
	            'title' => __( 'Ovatheme', 'ova-framework' ),
	            'icon' => 'fa fa-plug',
	        ]
	    );

	}


	/**
	 * On Widgets Registered
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function on_widgets_registered() {
		$this->includes();
		$this->register_widget();
	}

	/**
	 * Includes
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function includes() {
		
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-menu.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-logo.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-header.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_contact_info.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_search_popup.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_language.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_social.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_menu_page.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_skill_bar.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_heading.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_education.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_testimonial.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_checked.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_checked2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_checked_grid.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_icon.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_banner.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_banner2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_text.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_feature.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_learnmore.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_blog.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_time_countdown.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_history.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_feature_box.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_link.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_resource.php';

		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_contact_slide.php';


		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_button.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_icon.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_icon_header.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_icon_banner.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_our_skill.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_feature_1.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_contact_1.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_tooltip.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_pricing.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_tabs.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_icon_text.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_products.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_image_box.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_review.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_percent_box.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_contact.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_before_after.php';

		
	}

	/**
	 * Register Widget
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function register_widget() {

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_menu() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_logo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_header() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_contact_info() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_search_popup() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_language() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_social() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_menu_page() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_skill_bar() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_heading() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_education() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_testimonial() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_list_checked() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_list_checked2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_list_checked_grid() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_list_icon() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_banner() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_banner2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_list_text() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_icon() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_icon_header() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_icon_banner() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_feature() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_box_learnmore() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_blog() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_time_countdown() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_history() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_feature_box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_list_link() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_box_resource() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_contact_slide() );

		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_button() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_our_skill() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_box_feature_1() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_box_contact_1() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_tooltip() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_pricing() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_tabs() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_icon_text() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_products() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_image_box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_review() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_percent_box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_contact() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_before_after() );
	}
	    
	

}

new Ova_Register_Elementor();





