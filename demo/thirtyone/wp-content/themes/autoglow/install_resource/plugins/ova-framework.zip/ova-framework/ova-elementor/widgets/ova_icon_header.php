<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_icon_header extends Widget_Base {

	public function get_name() {
		return 'ova_icon_header';
	}

	public function get_title() {
		return __( 'Icon Header', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'hf' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

				$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'flaticon-whatsapp', 'ova-framework' ),
				
			]
		);


	$this->add_control(
			'text',
			[
				'label' => __( 'Phone', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('650-732-9369 ','ova-framework'),
			]
		);


		$this->add_control(
			'type_link',
			[
				'label' => __( 'Type Link', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'tell',
				'options' => [
					'email' => __('Email', 'ova-framework'),
					'tell' => __('Tell', 'ova-framework'),
					'web' => __('Website', 'ova-framework'),
				]
			]
		);

		$this->add_control(
			'link_text',
			[
				'label' => __( 'Link 1', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('6507329369', 'ova-framework'),
			]
		);

	


	


		$this->end_controls_section();


		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color Icon ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_icon_header .number i:before' => 'color : {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'color_icon_hover',
			[
				'label' => __( 'Color Icon Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_icon_header .number i:hover:before' => 'color : {{VALUE}};',
				],
			]
		);
			$this->add_control(
			'color_title',
			[
				'label' => __( 'Color Text', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_icon_header .number .hd-title a' => 'color : {{VALUE}};',
				],
			]
		);
				$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_icon_header .number .hd-title a',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);
				$this->add_control(
			'color_title_hover',
			[
				'label' => __( 'Color Text Hover ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_icon_header .number .hd-title a:hover' => 'color : {{VALUE}};',
				],
			]
		);

	

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$title = $settings['text'];
		$type_link = $settings['type_link'];
		$link_text = $settings['link_text'];

		$text = $settings['class_icon'];

			$text_link_1 = '';
		switch($type_link) {
			case "email" : {
				if( ! empty( $title ) ){
					$text_link_1 = "<a href='mailto:".esc_attr( $link_text )."'>".esc_html( $title )."</a>";
				}

			
			
				break;
			}
			case "tell" : {

				if( ! empty( $title ) ){
					$text_link_1 = "<a href='tel:".esc_attr( $link_text )."'>".esc_html( $title )."</a>";
				}

			
				
				break;
			}

			case "web" : {


			
				if( ! empty( $title) ){
					$text_link_1 = "<a href='".esc_attr( $link_text )."'>".esc_html( $title )."</a>";
				}
			
				
				break;
			}

		}



		?>
	
		<div class="ova_icon_header">

			<span class="number">
				<i class = "<?php echo esc_html( $text ) ?>"></i>
				<span class="hd-title second_font"> <?php echo $text_link_1 ?></span>
			</span>


		
		</div>


		<?php

	}
}


