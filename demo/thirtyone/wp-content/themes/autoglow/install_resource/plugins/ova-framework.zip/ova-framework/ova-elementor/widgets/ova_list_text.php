<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_list_text extends Widget_Base {

	public function get_name() {
		return 'ova_list_text';
	}

	public function get_title() {
		return __( 'Package Service 2', 'ova-framework' );
	}

	public function get_icon() {
		return 'fas fa-check';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		//SECTION CONTENT
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label' => __( 'Heading Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('À La Carte Services','ova-framework'),
			]
		);


		$repeater = new \Elementor\Repeater();


		$repeater->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);
		$repeater->add_control(
			'title2',
			[
				'label' => __( 'Title2', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);


		$this->add_control(
			'tabs',
			[
				'label' => __( 'Tabs', 'ova-framework' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => __( 'Air Freshener', 'ova-framework' ),
						'title2' => __( '$1.00 ', 'ova-framework' ),
					],
					[
						'title' => __( 'Armor All Tires', 'ova-framework' ),
						'title2' => __( '$2.00', 'ova-framework' ),
					],
					[
						'title' => __( 'Gleam Polish Wax', 'ova-framework' ),
						'title2' => __( '$4.00', 'ova-framework' ),
					],
					[
						'title' => __( 'Extra Vcuuming', 'ova-framework' ),
						'title2' => __( '$5.00 & Up', 'ova-framework' ),
					],
					[
						'title' => __( 'Mats Brush Cleaned', 'ova-framework' ),
						'title2' => __( '$1.00', 'ova-framework' ),
					],
					[
						'title' => __( 'Trunk and Cargo Vacuuming', 'ova-framework' ),
						'title2' => __( 'By Estimate', 'ova-framework' ),
					],
					[
						'title' => __( 'Convertible Tops Cleaned', 'ova-framework' ),
						'title2' => __( 'By Estimate', 'ova-framework' ),
					],
					[
						'title' => __( 'Vinyl Tops Cleaned and Dressed', 'ova-framework' ),
						'title2' => __( 'By Estimate', 'ova-framework' ),
					],
				],
			]
		);
			

		$this->end_controls_section();

		

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'color_banner',
			[
				'label' => __( 'Color Heading ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pk2-title' => 'color : {{VALUE}};',
				],
			]
		);
			$this->add_control(
			'background_color_banner',
			[
				'label' => __( 'Background Color Heading', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pk2-title' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color Title ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_text' => 'color : {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'background_color_pk2',
			[
				'label' => __( 'Background Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_text .table-text td' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'background_color2_pk2',
			[
				'label' => __( 'Background Color 2', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_text .table-text tr:nth-child(even) td' => 'background-color : {{VALUE}};',
				],
			]
		);



		$this->end_controls_section();
		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$title = $settings['heading'];
		$tabs = $settings['tabs'];
		?>

		<div class="pk2-title second_font">

			<h2><?php echo esc_html( $title ) ?></h2>

		</div>
		
		<div class="ova_list_text" >
			<?php if( !empty( $tabs ) ) : ?>
				<table  class=" table-striped table-text">
				

							<?php 
							foreach( $tabs as $item ) { 

								?>
								<tr>
								<td class="sev-text second_font">
									<?php echo esc_html__( $item['title'] ) ?>
								</td>
								<td class="sev-text2 second_font">
									<?php echo esc_html__( $item['title2'] ) ?>
								</td>
								</tr>

							<?php } ?>
						
				
				</table>

			<?php endif ?>
		</div>

		<?php
	}
}

	