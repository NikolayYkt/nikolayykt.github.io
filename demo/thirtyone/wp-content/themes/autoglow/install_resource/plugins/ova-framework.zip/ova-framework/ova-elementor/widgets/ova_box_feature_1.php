<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_box_feature_1 extends Widget_Base {

	public function get_name() {
		return 'ova_box_feature_1';
	}

	public function get_title() {
		return __( 'Icon Boxes', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'version',
			[
				'label' => __( 'Version', 'ova-framework' ),
				'type' 	=> Controls_Manager::SELECT,
				'default' => 'version_1',
				'options' => [
					'version_1' => esc_html__( 'Version 1', 'ova-framework' ),
					'version_2' => esc_html__( 'Version 2', 'ova-framework' ),
					'version_3' => esc_html__( 'Version 3', 'ova-framework' ),
					'version_4' => esc_html__( 'Version 4', 'ova-framework' ),
					'version_5' => esc_html__( 'Version 5', 'ova-framework' ),
					'version_6' => esc_html__( 'Version 6', 'ova-framework' ),
				]
			]
		);	

		$this->add_control(
			'class_icon',
			[
				'label' 	=> __( 'Class Icon', 'ova-framework' ),
				'type' 		=> Controls_Manager::TEXT,
				'default' 	=> 'flaticon-parthenon',
			]
		);

		$this->add_control(
			'number',
			[
				'label' 	=> __( 'Number', 'ova-framework' ),
				'type' 		=> Controls_Manager::TEXT,
				'default' 	=> '01',
				'condition' => [
					'version' => ['version_2'],
				],
			]
		);
		

		$this->add_control(
			'title',
			[
				'label'   => __( 'Title', 'ova-framework' ),
				'type' 	  => Controls_Manager::TEXT,
				'default' => __('Four Wheel Alighning','ova-framework'),
			]
		);

		$this->add_control(
			'description',
			[
				'label'   	=> __( 'Description', 'ova-framework' ),
				'type' 	  	=> Controls_Manager::TEXT,
				'default' 	=> __('Helping Our Clients From  Past 30 Years!','ova-framework'),
				'condition' => [
					'version' => ['version_6'],
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'type' 	=> Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
				'default' => [
					'url' => '#',
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'bg_content',
				[
					'label' => __( 'Background ', 'ova-framework' ),
					'type' 	=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_1' 					=> 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ova_box_feature_3.version_3' 			=> 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ova_box_feature_1.version_4 .item' 	=> 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ova_box_feature.version_5 .item' 		=> 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6' 		=> 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
	            'content_align',
	            [
	                'label' => __( 'Alignment', 'ova_framework' ),
	                'type' 	=> Controls_Manager::CHOOSE,
	                'options' => [
	                    'flex-start' => [
	                        'title' 	=> __( 'Left', 'ova_framework' ),
	                        'icon' 		=> 'eicon-text-align-left',
	                    ],
	                    'center' 	 => [
	                        'title' 	=> __( 'Center', 'ova_framework' ),
	                        'icon' 		=> 'eicon-text-align-center',
	                    ],
	                    'flex-end' 	 => [
	                        'title' 	=> __( 'Right', 'ova_framework' ),
	                        'icon' 		=> 'eicon-text-align-right',
	                    ],
	                ],
	                'default' => '',
	                'selectors' => [
	                    '{{WRAPPER}} .ova_boxes.version_6' => 'justify-content: {{VALUE}};',
	                ],
	                'condition'  => [
						'version' => ['version_6'],
					],
	            ]
	        );

			$this->add_responsive_control(
				'padding_v2',
				[
					'label' 	 => __( 'Padding', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_box_feature_1.version_2 .item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6' 	 => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'condition'  => [
						'version' => ['version_2', 'version_6'],
					],
				]
			);

			$this->add_group_control(
	            Group_Control_Border::get_type(), [
	                'name' => 'version_6_border',
	                'selector' => '{{WRAPPER}} .ova_boxes.version_6 .item_v6',
	                'condition'  => [
						'version' => ['version_6'],
					],
	            ]
	        );

	        $this->add_control(
	            'version_6_border_radius',
	            [
	                'label' 		=> __( 'Border Radius', 'ova_framework' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ova_boxes.version_6 .item_v6' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	                'condition'  	=> [
						'version' 	=> ['version_6'],
					],
	            ]
	        );

	        $this->add_responsive_control(
	            'version_6_max_width',
	            [
	                'label' 	 => __( 'Max Width', 'ova_framework' ),
	                'type' 		 => Controls_Manager::SLIDER,
	                'size_units' => [ '%', 'px' ],
	                'range' => [
	                    'px' => [
	                        'max' => 1000,
	                    ],
	                ],
	                'tablet_default' => [
	                    'unit' => '%',
	                ],
	                'mobile_default' => [
	                    'unit' => '%',
	                ],
	                'selectors' => [
	                    '{{WRAPPER}} .ova_boxes.version_6 .item_v6' => 'max-width: {{SIZE}}{{UNIT}};',
	                ],
	                'condition' => [
						'version' 	=> ['version_6'],
					],
	            ]
	        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'font_size_icon',
			[
				'label' 	 => __( 'Font Size', 'ova-framework' ),
				'type' 		 => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' 	 => [
					'px' => [
						'max' => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova_box_feature_1 .item .icon i:before' 			=> 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ova_box_feature_3.version_3 .item .icon i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ova_box_feature.version_5 .item .icon i' 			=> 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .icon i' 			=> 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' 	=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_feature_1 .item .icon i:before' 			=> 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_box_feature_3.version_3 .item .icon i:before' => 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_box_feature.version_5 .item .icon i'			=> 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .icon i'				=> 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_icon',
			[
				'label' 	 => __( 'Margin', 'ova-framework' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .ova_box_feature_1 .item .icon i' 			 => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ova_box_feature_3.version_3 .item .icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ova_box_feature_1.version_4 .item .icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ova_box_feature.version_5 .item .icon' 	 => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .icon' 	 	 => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();

		/**
		 * Section content style version 6
		 */
		$this->start_controls_section(
			'section_convent',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'version' => ['version_6'],
				],
			]
		);

			$this->add_responsive_control(
				'padding_content',
				[
					'label' 	 => __( 'Padding', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'condition' => [
						'version' => ['version_6'],
					],
				]
			);

			$this->add_responsive_control(
				'margin_content',
				[
					'label' 	 => __( 'Margin', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'condition' => [
						'version' => ['version_6'],
					],
				]
			);

			$this->add_group_control(
	            Group_Control_Border::get_type(), [
	                'name' 		 => 'content_border',
	                'selector' 	 => '{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content',
	                'condition'  => [
						'version' => ['version_6'],
					],
	            ]
	        );

	        $this->add_control(
	            'content_border_radius',
	            [
	                'label' 		=> __( 'Border Radius', 'ova_framework' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	                'condition'  	=> [
						'version' 	=> ['version_6'],
					],
	            ]
	        );

		$this->end_controls_section();
		// End

		/**
		 * Section title style
		 */
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title_typography',
					'selector' 	=> '{{WRAPPER}} .ova_box_feature_1 .item .title p',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
					'condition' => [
						'version' => ['version_1', 'version_2'],
					],
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title_typography_v3',
					'selector' 	=> '{{WRAPPER}} .ova_box_feature_3.version_3 .item .title p',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
					'condition' => [
						'version' => ['version_3'],
					],
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title_typography_v5',
					'selector' 	=> '{{WRAPPER}} .ova_box_feature.version_5 .item .title p',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
					'condition' => [
						'version' => ['version_5'],
					],
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title_typography_v6',
					'selector' 	=> '{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content .title h2',
					'scheme' 	=> Typography::TYPOGRAPHY_1,
					'condition' => [
						'version' => ['version_6'],
					],
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => __( 'Color ', 'ova-framework' ),
					'type' 	=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_1 .item .title p' 			=> 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_box_feature_3.version_3 .item .title p' 	=> 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_box_feature.version_5 .item .title p' 	=> 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content .title h2' 		=> 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_title',
				[
					'label' 	 => __( 'Margin', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_box_feature_1 .item .title' 					=> 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} .ova_box_feature_3.version_3 .item .title' 		=> 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} .ova_box_feature.version_5 .item .title p' 		=> 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content .title h2' 	=> 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		// End

		/**
		 * Section description style
		 */
		$this->start_controls_section(
			'section_descripion_style',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'version' => ['version_6'],
				],
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'description_typography',
					'selector' 	=> '{{WRAPPER}} .ova_boxes.version_6 .content .description p',
					'condition' => [
						'version' => ['version_6'],
					],
				]
			);

			$this->add_control(
				'color_description',
				[
					'label' => __( 'Color ', 'ova-framework' ),
					'type' 	=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content .description p' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_description',
				[
					'label' 	 => __( 'Padding', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content .description p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_description',
				[
					'label' 	 => __( 'Margin', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content .description p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'opacity_description',
				[
					'label' 	 => __( 'Opacity', 'ova-framework' ),
					'type' 		 => Controls_Manager::SLIDER,
					'size_units' => [ 'px'],
					'range' 	 => [
						'px' => [
							'max' => 1,
							'step' => 0.1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_boxes.version_6 .item_v6 .content .description p' => 'opacity: {{SIZE}};',
					],
				]
			);

		$this->end_controls_section();
		// End

		$this->start_controls_section(
			'section_item',
			[
				'label' => __( 'Item', 'ova-framework' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'version!' => ['version_6'],
				],
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' 		=> 'border',
					'label' 	=> __( 'Border', 'plugin-domain' ),
					'selector' 	=> '{{WRAPPER}} .ova_box_feature_1 .item',
					'condition' => [
						'version' => ['version_1', 'version_2'],
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' 		=> 'border_v3',
					'label' 	=> __( 'Border', 'plugin-domain' ),
					'selector' 	=> '{{WRAPPER}} .ova_box_feature_3.version_3 .item',
					'condition' => [
						'version' => ['version_3'],
					],
				]
			);

			$this->add_responsive_control(
				'border-radius',
				[
					'label' 	 => __( 'Margin', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_box_feature_1.version_4 .item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'condition'  => [
						'version' => ['version_4'],
					],
				]
			);

			$this->add_responsive_control(
				'padding_item_v5',
				[
					'label' 	 => __( 'Padding', 'ova-framework' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova_box_feature.version_5 .item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'condition'  => [
						'version' => ['version_5'],
					],
				]
			);

		$this->end_controls_section();
		
	}

	protected function render() {

		$settings 	= $this->get_settings();

		$version 	= $settings['version'];
		$class_icon = $settings['class_icon'];
		$number 	= $settings['number'];
		$title 		= $settings['title'];
		$target 	= $settings['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow 	= $settings['link']['nofollow'] ? ' rel="nofollow"' : '';

		$description = "";
		if ( $version == 'version_6' ) {
			$description = $settings['description'];
		}

		?>

		<?php if( $version == 'version_1' ): ?>
			<a href="<?php echo $settings['link']['url'] ?>" <?php echo $target . ' ' . $nofollow; ?> >
				<div class="ova_box_feature_1">
					<div class="item">
					<?php if( $class_icon ){ ?>
						<div class="icon">
							<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
						</div>
					<?php } ?>

					<?php if( $title ){ ?>
						<div class="title">
							<p class="second_font"><?php echo $title; ?></p>
						</div>
					<?php } ?>
					</div>
				</div>
			</a>
		<?php elseif ( $version == 'version_2' ): ?>
			<a href="<?php echo $settings['link']['url'] ?>" <?php echo $target . ' ' . $nofollow ?>>
				<div class="ova_box_feature_1 version_2 ">
					<div class="item">
						<div class="icon">
							<?php if ( !empty( $class_icon ) ): ?>
								<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
							<?php endif; ?>

							<?php if ( !empty( $number ) ): ?>
								<h1 class="number"><?php echo esc_attr( $number ); ?></h1>
							<?php endif; ?>
						</div>
						
						<?php if ( !empty( $title ) ): ?>
							<div class="title">
								<p class="second_font"><?php echo $title; ?></p>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</a>
		<?php elseif ( $version == 'version_3' ): ?>
			<a href="<?php echo $settings['link']['url'] ?>" <?php echo $target . ' ' . $nofollow; ?> >
				<div class="ova_box_feature_3 version_3">
					<div class="item">
					<?php if( $class_icon ){ ?>
						<div class="icon">
							<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
						</div>
					<?php } ?>

					<?php if( $title ){ ?>
						<div class="title">
							<p class="second_font"><?php echo $title; ?></p>
						</div>
					<?php } ?>
					</div>
				</div>
			</a>
		<?php elseif ( $version == 'version_4' ): ?>
			<a href="<?php echo $settings['link']['url'] ?>" <?php echo $target . ' ' . $nofollow; ?> >
				<div class="ova_box_feature_1 version_4">
					<div class="item">
					<?php if( $class_icon ){ ?>
						<div class="icon">
							<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
						</div>
					<?php } ?>

					<?php if( $title ){ ?>
						<div class="title">
							<p class="second_font"><?php echo $title; ?></p>
						</div>
					<?php } ?>
					</div>
				</div>
			</a>
		<?php elseif ( $version == 'version_5' ): ?>

			<?php if ( $settings['link']['url'] ): ?>
				<a href="<?php echo $settings['link']['url']; ?>" <?php echo $target . ' ' . $nofollow; ?> >
			<?php endif; ?>
				<div class="ova_box_feature version_5">
					<div class="item">
					<?php if( $class_icon ){ ?>
						<div class="icon">
							<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
						</div>
					<?php } ?>

					<?php if( $title ){ ?>
						<div class="title">
							<p class="second_font"><?php echo $title; ?></p>
						</div>
					<?php } ?>
					</div>
				</div>
			<?php if ( $settings['link']['url'] ): ?>
				</a>
			<?php endif; ?>

		<?php else: ?>
			<?php if ( $settings['link']['url'] ): ?>
				<a href="<?php echo $settings['link']['url']; ?>" <?php echo $target . ' ' . $nofollow; ?> >
			<?php endif; ?>
			<div class="ova_boxes version_6">
				<div class="item_v6">
				<?php if ( $class_icon ): ?>
					<div class="icon">
						<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
					</div>
				<?php endif; ?>
					<div class="content">
						<?php if( $title ): ?>
							<div class="title">
								<h2 class="second_font"><?php echo $title; ?></h2>
							</div>
						<?php endif; ?>
						<?php if ( $description ): ?>
							<div class="description">
								<p><?php echo $description; ?></p>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<?php if ( $settings['link']['url'] ): ?>
				</a>
			<?php endif; ?>
		<?php
		endif;
		// end if version
	}

}


