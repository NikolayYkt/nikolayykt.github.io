<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_banner extends Widget_Base {

	public function get_name() {
		return 'ova_banner';
	}

	public function get_title() {
		return __( 'Package Service 1', 'ova-framework' );
	}

	public function get_icon() {
		return 'fas fa-check';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		//SECTION CONTENT
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
		$this->add_control(
			'heading',
			[
				'label' => __( 'Heading Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('The Works Wash ','ova-framework'),
			]
		);
		$this->add_control(
			'heading2',
			[
				'label' => __( 'Heading Title2', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('$13','ova-framework'),
			]
		);

		$this->add_control(
			'title_sev',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('This wash package includes:','ova-framework'),
			]
		);

			$repeater = new \Elementor\Repeater();


		$repeater->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);


		$this->add_control(
			'tabs',
			[
				'label' => __( 'Tabs', 'ova-framework' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => __( 'Pre-soak penetrating spray', 'ova-framework' ),
					],
					[
						'title' => __( 'Spa Foam Cleaner', 'ova-framework' ),
					],
					[
						'title' => __( 'Heated Super Dry', 'ova-framework' ),
					],
					[
						'title' => __( 'Heavy-duty Cleaning with Jet Blast Spray', 'ova-framework' ),
					],
					[
						'title' => __( ' Rain-X Treatment', 'ova-framework' ),
					],
					[
						'title' => __( 'Tire Shine and Wheel Bright', 'ova-framework' ),
					],
					[
						'title' => __( 'Undercarriage Blast', 'ova-framework' ),
					],
				],
			]
		);

		$this->add_control(
			'title_sev2',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('*(SUV &amp; Minivan upcharges apply to each included service)','ova-framework'),
			]
		);



		$this->end_controls_section();

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'color_banner',
			[
				'label' => __( 'Color Heading ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-banner' => 'color : {{VALUE}};',
				],
			]
		);
			$this->add_control(
			'background_color_banner',
			[
				'label' => __( 'Background Color Heading', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-banner' => 'background-color : {{VALUE}};',
				],
			]
		);
			$this->add_control(
				'color_title_pk',
				[
					'label' => __( 'Color Title ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .sev-pk1 .pk1-title' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title2_pk',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .sev-pk1 .pk1-title2' => 'color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'section_icon',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);



		$this->add_control(
			'width_icon',
			[
				'label' => __( 'Width', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'max' => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova_list_checked ul li svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_checked ul li svg' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_icon',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_list_checked ul li svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_title_icon',
			[
				'label' => __( 'Title Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_list_checked ul li span',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_checked ul li span' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_title',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_list_checked ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$title = $settings['heading'];
		$title2 = $settings['heading2'];
		$tabs = $settings['tabs'];
		$title3 = $settings['title_sev'];
		$title4 = $settings['title_sev2'];
		?>
		
		<div class="ova-banner second_font">

			<h2><?php echo esc_html( $title ) ?></h2>
			<h2><?php echo esc_html( $title2 ) ?></h2>

		</div>

		<div class="sev-pk1">

		<div class="pk1-title second_font">

			<div><?php echo esc_html( $title3 ) ?></div>

		</div>

		<div class="ova_list_checked" >
			<?php if( !empty( $tabs ) ) : ?>
				<ul>
				<?php 
				foreach( $tabs as $item ) { 
					?>
					<li class="item">
						<i data-feather="check-circle"></i>
						<span><?php echo esc_html__( $item['title'] ) ?></span>
					</li>
				<?php } ?>
				</ul>
			<?php endif ?>

		</div>

		<div class="pk1-title2 second_font">

			<div><?php echo esc_html( $title4 ) ?></div>

		</div>
	</div>
	
		<?php
	}
}
