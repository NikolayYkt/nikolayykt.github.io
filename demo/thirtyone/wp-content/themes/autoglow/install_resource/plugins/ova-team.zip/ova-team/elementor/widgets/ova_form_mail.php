<?php

namespace ova_team_elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_form_mail extends Widget_Base {

	public function get_name() {
		return 'ova_form_mail';
	}

	public function get_title() {
		return __( 'Ova Contact Form', 'ova-team' );
	}

	public function get_icon() {
		return 'fa fa-envelope-o';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-team' ),
			]
		);

		$args = array(
			'posts_per_page'   => -1,
			'post_type'        => 'page'
		);

		$pages = get_posts($args);

		$list_page = [];
		if( ! empty( $pages ) ) {
			foreach( $pages as $page ){
				$list_page[$page->ID] = $page->post_title;
			}
		}


		$this->add_control(
			'mail',
			[
				'label' => __( 'Send to Email Address', 'ova-team' ),
				'type' => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-team' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Contact Me', 'ova-team' ),
			]
		);

		$this->add_control(
			'thank_page',
			[
				'label' => __( 'Thank Page', 'ova-team' ),
				'type' => Controls_Manager::SELECT,
				'description' => __( 'If Sending an Email is success, it will redirect to this page', 'ova-team' ),
				'options' => $list_page
			]
		);

		$this->add_control(
			'error_page',
			[
				'label' => __( 'Error Page', 'ova-team' ),
				'type' => Controls_Manager::SELECT,
				'description' => __( 'If Sending an Email is failed, it will redirect to this page', 'ova-team' ),
				'options' => $list_page
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$template = apply_filters( 'el_elementor_ova_form_mail', 'elementor/ova_form_mail.php' );

		ob_start();
		ovateam_get_template( $template, $settings );
		echo ob_get_clean();

		
		
	}
}


