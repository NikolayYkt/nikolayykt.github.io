<?php
$email = $args['mail'];
$thank_page = $args['thank_page'];
$error_page = $args['error_page'];
$title = $args['title'];

if( ! empty( $email ) ){
?>
<form action="">
	<div class="ova-form-mail">
		<?php if( ! empty( $title ) ){ ?>
			<h2 class="title">
				<?php echo esc_html( $title ) ?>
			</h2>
		<?php } ?>
		<div class="con">
			<div class="input name">

				<span class="error"><?php esc_html_e( 'field is required', 'ova-team' ) ?></span>
				<input type="text" class="required field second_font" name="your_name" value="" placeholder="<?php esc_attr_e( 'Name', 'ova-team' ) ?>" id="your-name" />
			</div>
			<div class="input email">

				<span class="error"><?php esc_html_e( 'field is required', 'ova-team' ) ?></span>
				<input type="email" class="required field second_font" name="your_email" value="" placeholder="<?php esc_attr_e( 'Email', 'ova-team' ) ?>"  id="your-name" />
			</div>

			<div class="input subject">

				<span class="error"><?php esc_html_e( 'field is required', 'ova-team' ) ?></span>
				<input type="text" class="required field second_font" name="your_subject" value="" placeholder="<?php esc_attr_e( 'Subject', 'ova-team' ) ?>" id="your-subject" />
			</div>

		</div>

		<div class="con">
			<div class="input comment">

				<span class="error"><?php esc_html_e( 'field is required', 'ova-team' ) ?></span>
				<textarea name="your_comment" class="required field second_font" cols="40" rows="10" placeholder="<?php esc_attr_e( 'Write your Message...', 'ova-team' ) ?>"  id="your-comment"></textarea>
			</div>
		</div>
		<div class="submit">
			<input type="submit" value="<?php esc_html_e( 'Send Message', 'ova-team' ) ?>" class="ova_button second_font type1 medium" id="form-submit">
			<input type="hidden" name="email_to" value="<?php echo $email ?>">
			<input type="hidden" name="email_from_element" value="send_mail">
			<input type="hidden" name="thank_page" value="<?php echo $thank_page ?>">
			<input type="hidden" name="error_page" value="<?php echo $error_page ?>">
		</div>

	</div>
</form>
<?php
}
// end if empty email
