<?php
$category = $args['category'];
$number_column = $args['number_column'];

$show_social = $args['show_social'];
$show_name = $args['show_name'];
$show_job = $args['show_job'];


if( $category == 'all' ){
	$args= array(
		'post_type' => 'team',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count']
	);
} else {
	$args= array(
		'post_type' => 'team',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_team',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$teams  = new \WP_Query($args);

?>
	<div class="ova-wrap-team">
	<div class="container">
		<div class="row">
			<div class="archive_team <?php echo esc_attr( $number_column ) ?>">
				<div class="content">
					<?php if( $teams->have_posts() ) : while ( $teams->have_posts() ) : $teams->the_post(); ?>

						<div class="items elementor-items">
							<?php 

							$id = get_the_id();

							$avatar = get_post_meta( $id, 'ova_team_met_avatar', true );
							$job = get_post_meta( $id, 'ova_team_met_job', true );
							$email = get_post_meta( $id, 'ova_team_met_email', true );
							$phone = get_post_meta( $id, 'ova_team_met_phone', true );
							$list_social = get_post_meta( $id, 'ova_team_met_group_icon', true );
							?>

							<div class="content_info">
								<div class="ova-media">
									<?php if( ! empty( $avatar ) ){ ?>
										<a href="<?php echo get_the_permalink() ?>">
											<img src="<?php echo esc_url( $avatar ) ?>" class="img-responsive" alt="<?php echo get_the_title() ?>">
										</a>
										
									<?php } ?>
									

									<?php if( ! empty( $list_social ) && $show_social == 'yes' ) { ?>
									<div class="ova-social">
										<ul>
											<?php 
											foreach( $list_social as $social ){

												$class_icon = isset( $social['ova_team_met_class_icon_social'] ) ? $social['ova_team_met_class_icon_social'] : '';
												$link_social = isset( $social['ova_team_met_link_social'] ) ? $social['ova_team_met_link_social'] : '';
												?>
												<li>
													<a href="<?php echo esc_url( $link_social ) ?>">
														<i class="<?php echo esc_attr( $class_icon ) ?>"></i>
													</a>
												</li>
												<?php
											}
											?>
										</ul>
									</div>
									<?php } ?>
								</div>
								<div class="ova-info-content">

									<?php if( $show_name == 'yes' ) { ?>
									<a href="<?php echo get_the_permalink() ?>" class="name second_font" >
										<?php echo get_the_title() ?>
									</a>
									<?php } ?>

									<?php if( ! empty( $job ) && $show_job == 'yes' ) { ?>
										<p class="job">
											<?php echo esc_html( $job ) ?>
										</p>
									<?php } ?>								

								</div>
							</div>

						</div>

					<?php endwhile; endif; wp_reset_postdata(); ?>
				</div>
				
				<?php 
					autoglow_pagination_theme();
				?>

			</div>
		</div>
	</div>
</div>



