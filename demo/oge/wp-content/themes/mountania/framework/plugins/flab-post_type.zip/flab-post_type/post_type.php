<?php 
/**
 * Plugin Name: Flab Register widget
 * Description: This plugin register popular posts widget in sidebar & footer
 * Version: 1.0
 * Author: Besim Dauti
 * Author URI: https://fabric-lab.co/
 */
?>
<?php

require_once plugin_dir_path( __FILE__ ) . 'popular-widget.php';

?>