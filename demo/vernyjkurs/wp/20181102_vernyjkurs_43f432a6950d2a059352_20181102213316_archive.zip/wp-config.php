<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'b183775_jmwr' );

/** MySQL database username */
define( 'DB_USER', 'u183775_mhof' );

/** MySQL database password */
define( 'DB_PASSWORD', '9H:jkAq?' );

/** MySQL hostname */
define( 'DB_HOST', '185.84.108.16' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '>j)OM|xRZ_dy khq`Qit8Do>PvM+@<KqDo[j2s.ZGu8sg&X7 nPpMa3:+%DR!3:&' );
define( 'SECURE_AUTH_KEY',  ']17^(GL KB^;Qe^}}FWpjr{(=+IbQNx0,*.E^}>+:<rAPy| /}6HO[03Qgn?.)V=' );
define( 'LOGGED_IN_KEY',    'i~Z9u`D(%r.K^ntf5Fa}TNzwzqWg?IX[Wz5a|]8u9U80p<R3Pa!d_ bo>eA(RVjM' );
define( 'NONCE_KEY',        '.7eh`06w%`w;N?Hjt`J1@F`b2!RNxZS3M}x$N rfUy&e]gk66q@E61In{ c}R,I{' );
define( 'AUTH_SALT',        '$ZY^t6g4XpcM;lNZ5Ok7GMfK.]yFi21R$B.w?heN$bZc1n;w4%r@j,Xh(Sgj)esw' );
define( 'SECURE_AUTH_SALT', '~%8RJG=&;[ &b7GQq]{^:*#Ksq^/aP?{QFF_a!{[bK>/x$[QZ@_%JfH]CjJ;D,O8' );
define( 'LOGGED_IN_SALT',   'q#PkTdww%`md!1Lw~m1|^J:wE-%T4,xYx&.uZ|)UU!pD?C<^.l`R:Wm6APVL+?l#' );
define( 'NONCE_SALT',       'Sf#rO*V/B~4GmKN_!]a3C&jT01u@tvbKZe<cT-R~YEJf!L2$A3^$@?dZvJ#hkwl&' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
