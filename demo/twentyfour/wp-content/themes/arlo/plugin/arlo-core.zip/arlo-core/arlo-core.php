<?php
/*
Plugin Name: Arlo Core
Plugin URI: https://themeforest.net/item/arlo-portfolio-word`ress-theme/22729865
Description: Arlo Core Plugin for Arlo Theme
Version: 4.2
Author: Frenify
Author URI: https://frenify.com/
*/

		


// since v4.1
define ('ARLO_PLUGIN_URL', plugin_dir_url(__FILE__));
define ('ARLO_PLUGIN_VERSION', '4.2');
define ('ARLO_TEXT_DOMAIN', 'arlo-core' );

register_setting('arlo__options', 'arlo__welcome_page', array('default' => 'no'));

function arlo_fn_redirect() {
	if(get_option('arlo__welcome_page', 'no') != 'yes'){
		update_option('arlo__welcome_page','yes');
		wp_safe_redirect( admin_url( 'admin.php?page=arlo' ) );
		exit;
	}
}
add_action( 'plugins_loaded', 'arlo_fn_redirect' );
// since v4.2
// redirect to settings page after installation
function arlo_fn_reset( $plugin ) {
    if( $plugin == plugin_basename( __FILE__ ) ) {
		update_option('arlo__welcome_page','no');
    }
}
add_action( 'activated_plugin', 'arlo_fn_reset' );


// was changed since v4.2
define ( 'ARLO_CORE_SHORTCODE_URL', ARLO_PLUGIN_URL . 'shortcode/'); // since v2.5
define ( 'FREL_PLUGIN_URL', ARLO_PLUGIN_URL . 'shortcode/'); // deprecated since v2.5
define ( 'ARLO_PLACEHOLDERS_URL', ARLO_PLUGIN_URL . 'shortcode/assets/img/placeholders/');
define ( 'ARLO_CORE_CSS', ARLO_PLUGIN_URL . 'shortcode/assets/css/' ); // since v2.5
define ( 'ARLO_CORE_JS', ARLO_PLUGIN_URL . 'shortcode/assets/js/' ); // since v2.5


// Custom Meta tags for Sharing
add_action('wp_head', 'arlo_fn_open_graph_meta');

function arlo_fn_open_graph_meta(){
	global $post, $arlo_fn_option;
	
	// enable or disable via theme options
	if(isset($arlo_fn_option['open_graph_meta']) && $arlo_fn_option['open_graph_meta'] == 'enable'){
	
		$image = '';
		if(isset($post)){
			if (has_post_thumbnail( $post->ID ) ) {
				$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
				$image = esc_attr( $thumbnail_src[0] );
		}}?>

		<meta property="og:title" content="<?php the_title(); ?>" />
		<meta property="og:type" content="article"/>
		<meta property="og:url" content="<?php the_permalink(); ?>" />
		<meta property="og:site_name" content="<?php echo esc_html(get_bloginfo( 'name' )); ?>" />
		<meta property="og:description" content="<?php echo arlo_fn_excerpt(12); ?>" />

		<?php if ( $image != '' ) { ?>
			<meta property="og:image" content="<?php echo esc_url($image); ?>" />
		<?php }
	}
}
		add_action( 'init', 'translation' );
		// Load text domain
		function translation() 
		{
			load_plugin_textdomain( 'frenify-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}
/*----------------------------------------------------------------------------*
 * Plugins
 *----------------------------------------------------------------------------*/
	
	if (!class_exists('ReduxFramework') && file_exists(plugin_dir_path(__FILE__) . '/optionpanel/framework.php'))
    {
    	require_once ('optionpanel/framework.php');
 
    }
 
	if (!isset($redux_demo) && file_exists(plugin_dir_path(__FILE__) . '/opt/config.php'))
    {
    	require_once ('opt/config.php');
 
    }

    // Load Theme Options Panel

	include_once(plugin_dir_path( __FILE__ ) . 'shortcode/frel-core.php');


	include_once( plugin_dir_path( __FILE__ ) . 'inc/widgets/widget-business-hours.php');	// Load Widgets
	include_once( plugin_dir_path( __FILE__ ) . 'inc/widgets/widget-estimate.php');			// Load Widgets
	include_once( plugin_dir_path( __FILE__ ) . 'inc/widgets/widget-brochure.php');			// Load Widgets
	include_once( plugin_dir_path( __FILE__ ) . 'inc/widgets/widget-subscribers.php');		// Load Widgets


	add_filter( 'plugin_row_meta', 'arlo_core_fn_plugin_row_meta', 10, 2 );

 	function arlo_core_fn_plugin_row_meta( $plugin_meta, $plugin_file ) {
		if ( 'arlo-core/arlo-core.php' === $plugin_file ) {
			$row_meta = [
				'docs' 		=> '<a href="https://arlo.frenify.net/doc/" target="_blank">Docs</a>',
				'faq' 		=> '<a href="https://arlo.frenify.net/doc/#faq" target="_blank">FAQs</a>',
				'changelog' => '<a href="https://arlo.frenify.net/doc/#changelog" target="_blank">Changelog</a>',
			];

			$plugin_meta = array_merge( $plugin_meta, $row_meta );
		}

		return $plugin_meta;
	}
	add_action( 'plugins_loaded', 'arlo_fn_plugin_setup' );
	function arlo_fn_plugin_setup(){

		// Load Meta Boxes
		include_once(plugin_dir_path( __FILE__ ) . 'inc/meta-box/metabox-config.php');

		// Call to Custom Post types and Functions
		include_once(plugin_dir_path( __FILE__ ) . 'inc/frenify-custompost.php');
		
		// Call to Custom Functions
		include_once(plugin_dir_path( __FILE__ ) . 'inc/frenify_custom_functions.php');

		// Call to Demo Import
		include_once(plugin_dir_path( __FILE__ ) . 'inc/demoimport/one-click-demo-import.php');
		include_once(plugin_dir_path( __FILE__ ) . 'inc/demoimport/demo-list.php');
		
		
		// Call Settings
		// since v4.1
		include_once(plugin_dir_path( __FILE__ ) . 'inc/settings/settings.php');
		

	}
	function arlo_fn_subsribe__add_table(){
	  	global $wpdb;
		$charset_collate 	= $wpdb->get_charset_collate();
		$table_name 		= $wpdb->prefix.'frenify_subscribers';
		$sql = '';
		if( $wpdb->get_var("SHOW TABLES LIKE '" . $table_name . "'") !=  $table_name){
			$sql = "CREATE TABLE `$table_name`(
				`id`						INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
				`email`          			VARCHAR(255) DEFAULT NULL
			) {$charset_collate};";
		}
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
	 }
	add_action( 'init', 'arlo_fn_subsribe__add_table');
	
	function arlo_fn_subsribe__add_email() {
		global $wpdb;
		$email 				= $_POST['email'];
		$email 				= filter_var($email, FILTER_SANITIZE_EMAIL);
		if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$query 				= "SELECT id FROM {$wpdb->prefix}frenify_subscribers WHERE email='".$email."'";
			$results 			= $wpdb->get_results( $query );
			$status				= 'old';
			if(count($results) == 0){
				$wpdb->query($wpdb->prepare( "INSERT INTO {$wpdb->prefix}frenify_subscribers (email) VALUES ( %s )", $email ));
				$status 		= 'new';
			}
		}else{
			$status			= 'invalid_email';
		}
		$buffyArray = array(
			'status' 		=> $status,
		);
		die(json_encode($buffyArray));
	}
	add_action('wp_ajax_arlo_fn_subsribe__add_email', 'arlo_fn_subsribe__add_email' );
	add_action('wp_ajax_nopriv_arlo_fn_subsribe__add_email','arlo_fn_subsribe__add_email' );
