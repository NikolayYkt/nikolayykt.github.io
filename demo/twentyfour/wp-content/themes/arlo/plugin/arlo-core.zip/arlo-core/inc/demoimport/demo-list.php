<?php

function frenify_register_plugins( $plugins ) {
  $theme_plugins = [
    [ // A WordPress.org plugin repository example.
      'name'     	=> 'Elementor', // Name of the plugin.
      'slug'     	=> 'elementor', // Plugin slug - the same as on WordPress.org plugin repository.
      'required' 	=> true,
    ],
	[ // A WordPress.org plugin repository example.
      'name'     	=> 'Contact Form 7', // Name of the plugin.
      'slug'     	=> 'contact-form-7', // Plugin slug - the same as on WordPress.org plugin repository.
      'required' 	=> false,
	  'preselected' => true,
    ],
    [ // A locally theme bundled plugin example.
      'name'     	=> 'Arlo Core',
      'slug'     	=> 'arlo-core',         // The slug has to match the extracted folder from the zip.
      'source'   	=> get_template_directory() . '/plugin/arlo-core.zip',
      'required' 	=> true,
    ], 
    [
      'name'        => 'Redux Vendor Support',
      'slug'        => 'redux-vendor-support-master',  // The slug has to match the extracted folder from the zip.
      'source'      => 'https://github.com/reduxframework/redux-vendor-support/archive/master.zip',
	  'required' 	=> true,
    ],
  ];
 
  return array_merge( $plugins, $theme_plugins );
}
add_filter( 'ocdi/register_plugins', 'frenify_register_plugins' );


function frenify_after_import_setup( $selected_import ) {
    // Assign menus to their locations.
	update_option( 'permalink_structure', '/%postname%/' );
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
 
    set_theme_mod( 'nav_menu_locations', [
            'main_menu' 	=> $main_menu->term_id, // replace 'main-menu' here with the menu location identifier from register_nav_menu() function in your theme.
            'mobile_menu' 	=> $main_menu->term_id,
            'trigger_menu' 	=> $main_menu->term_id,
        ]
    );
	update_option( 'show_on_front', 'page' );
	
	switch($selected_import['import_file_name']){
		case 'Digital Agency #1':
		case 'Personal - Jacob Barnes':
		case 'Corporate Business':
		case 'Personal - Albert Walkers': 	$front_page_id = get_page_by_title( 'Homepage' ); 	break;
		case 'Personal - Noir Ragoli': 		$front_page_id = get_page_by_title( 'Homepage5' ); 	break;
		default: 							$front_page_id = get_page_by_title( 'Home' ); 		break;
	}
	update_option( 'page_on_front', $front_page_id->ID );
    // Assign front page
   
 
}
add_action( 'ocdi/after_import', 'frenify_after_import_setup' );


// ===============================================================================================================================
// ===============================================================================================================================
// ===============================================================================================================================


function frenify_import_files() {
	$url 	= 'https://arlo.frenify.net/files/';
	$opt 	= 'arlo_fn_option';
	$upload = 'https://arlo.frenify.net/demos/intro/wp-content/uploads/';
	
	$ifn	= 'import_file_name';
	$cat	= 'categories';
	$ifu	= 'import_file_url';
	$iwfu	= 'import_widget_file_url';
	$iRedux	= 'import_redux';
	$fURL	= 'file_url';
	$opn	= 'option_name';
	$ipiu	= 'import_preview_image_url';
	$pURL	= 'preview_url';
  	return [
				[
					$ifn	=> 'Travel Blog',
					$cat	=> [ 'Travel' ],
					$ifu	=> $url.'travel/content.xml',
					$iwfu	=> $url.'travel/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'travel/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/11/travel.jpg',
					$pURL	=> 'https://frenify.net/envato/frenify/wp/arlo/demos/travel/',
				],
				[
					$ifn	=> 'Personal - Noir Ragoli',
					$cat	=> [ 'Personal' ],
					$ifu	=> $url.'personal5/content.xml',
					$iwfu	=> $url.'personal5/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'personal5/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/07/4.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/personal5/',
				],
				[
					$ifn	=> 'Personal - Jackson Brown',
					$cat	=> [ 'Personal' ],
					$ifu	=> $url.'personal4/content.xml',
					$iwfu	=> $url.'personal4/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'personal4/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/06/personal4.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/personal4/',
				],
				[
					$ifn	=> 'Personal - Alan Klein',
					$cat	=> [ 'Personal' ],
					$ifu	=> $url.'personal2/content.xml',
					$iwfu	=> $url.'personal2/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'personal2/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/07/personal2-scaled.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/personal2/',
				],
				[
					$ifn	=> 'Personal - Bona Green',
					$cat	=> [ 'Personal' ],
					$ifu	=> $url.'personal3/content.xml',
					$iwfu	=> $url.'personal3/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'personal3/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/06/2.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/personal3/',
				],
				[
					$ifn	=> 'Personal - Jacob Barnes',
					$cat	=> [ 'Personal' ],
					$ifu	=> $url.'personal6/content.xml',
					$iwfu	=> $url.'personal6/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'personal6/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/07/6.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/personal6/',
				],
				[
					$ifn	=> 'Personal - Albert Walkers',
					$cat	=> [ 'Personal' ],
					$ifu	=> $url.'personal1/content.xml',
					$iwfu	=> $url.'personal1/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'personal1/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/06/Layer-7-scaled.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/personal1/',
				],
				[
					$ifn	=> 'Split Screen',
					$cat	=> [ 'Portfolio' ],
					$ifu	=> $url.'split/content.xml',
					$iwfu	=> $url.'split/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'split/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/05/3.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/split/',
				],
				[
					$ifn	=> 'Interactive List #1',
					$cat	=> [ 'Interactive' ],
					$ifu	=> $url.'interactive1/content.xml',
					$iwfu	=> $url.'interactive1/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'interactive1/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/05/4.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/interactive1/',
				],
				[
					$ifn	=> 'Interactive List #2',
					$cat	=> [ 'Interactive' ],
					$ifu	=> $url.'interactive2/content.xml',
					$iwfu	=> $url.'interactive2/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'interactive2/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/05/5.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/interactive2/',
				],
				[
					$ifn	=> 'Interactive List #3',
					$cat	=> [ 'Interactive' ],
					$ifu	=> $url.'interactive3/content.xml',
					$iwfu	=> $url.'interactive3/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'interactive3/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/05/6.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/interactive3/',
				],
				[
					$ifn	=> 'Interactive List #4',
					$cat	=> [ 'Interactive' ],
					$ifu	=> $url.'interactive4/content.xml',
					$iwfu	=> $url.'interactive4/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'interactive4/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/05/7.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/interactive4/',
				],
				[
					$ifn	=> 'Interactive List #5',
					$cat	=> [ 'Interactive' ],
					$ifu	=> $url.'interactive5/content.xml',
					$iwfu	=> $url.'interactive5/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'interactive5/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/05/9.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/interactive5/',
				],
				[
					$ifn	=> 'Minimal Portfolio',
					$cat	=> [ 'Portfolio', 'Minimal' ],
					$ifu	=> $url.'minimal/content.xml',
					$iwfu	=> $url.'minimal/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'minimal/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/05/8.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/minimal/',
				],
				[
					$ifn	=> 'Creative Portfolio #1',
					$cat	=> [ 'Portfolio', 'Creative' ],
					$ifu	=> $url.'creative1/content.xml',
					$iwfu	=> $url.'creative1/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'creative1/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/12/half.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/creative1/',
				],
				[
					$ifn	=> 'Creative Portfolio #2',
					$cat	=> [ 'Portfolio', 'Creative' ],
					$ifu	=> $url.'creative2/content.xml',
					$iwfu	=> $url.'creative2/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'creative2/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/05/13.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/creative2/',
				],
				[
					$ifn	=> 'Corporate Business',
					$cat	=> [ 'Business' ],
					$ifu	=> $url.'business1/content.xml',
					$iwfu	=> $url.'business1/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'business1/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/11/business.jpg',
					$pURL	=> 'https://frenify.net/envato/frenify/wp/arlo/demos/business1/',
				],
				[
					$ifn	=> 'Digital Agency #1',
					$cat	=> [ 'Agency' ],
					$ifu	=> $url.'agency1/content.xml',
					$iwfu	=> $url.'agency1/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'agency1/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/09/agency-scaled.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/agency1/',
				],
				[
					$ifn	=> 'Digital Agency #2',
					$cat	=> [ 'Agency' ],
					$ifu	=> $url.'agency2/content.xml',
					$iwfu	=> $url.'agency2/widgets.json',
					$iRedux	=> [
						[
						  $fURL	=> $url.'agency2/redux.json',
						  $opn	=> $opt,
						]
					],
					$ipiu  	=> $upload.'2020/10/agensy-2.jpg',
					$pURL	=> 'https://arlo.frenify.net/demos/agency2/',
				],
    		];
}
add_filter( 'ocdi/import_files', 'frenify_import_files' );

function ocdi_plugin_page_setup( $default_settings ) {
    $default_settings['parent_slug'] = 'arlo';
    $default_settings['page_title']  = esc_html__( 'Demo Import Page' , 'one-click-demo-import' );
    $default_settings['menu_title']  = esc_html__( 'Import Demo Data' , 'one-click-demo-import' );
    $default_settings['capability']  = 'manage_options';
    $default_settings['menu_slug']   = 'theme-demo-import';
 
    return $default_settings;
}
add_filter( 'ocdi/plugin_page_setup', 'ocdi_plugin_page_setup' );