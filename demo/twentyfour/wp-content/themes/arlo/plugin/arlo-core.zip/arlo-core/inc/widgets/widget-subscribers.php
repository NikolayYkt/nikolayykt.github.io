<?php

/**
 * Plugin Name: Subsribers
 * Description: A widget that show business hours of your company.
 * Version: 1.0
 * Author: Frenify
 * Author URI: http://themeforest.net/user/frenify
 *
 */


/**
 * Example Widget class.
 * This class handles everything that needs to be handled with the widget:
 * the settings, form, display, and update.  Nice!
 *
 * @since 0.1
 */
class Frenify_Subsribers extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function __construct() {
		parent::__construct(
			'frenifysubscribers', // Base ID
			esc_html__( 'Frenify Subscribers', 'arlo' ), // Name
			array( 'description' => esc_html__( 'A widget that displays subscribe form. Subscribers list you can find in Theme Options > Subscribers', 'arlo' ), ) // Args
		);
		add_action( 'widgets_init', function() {
            register_widget( 'Frenify_Subsribers' );
        });
	}
	

	/**
	 * How to display the widget on the screen.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		global $post;
		/* Our variables from the widget settings. */
		
		$title					= '';
		if ( !empty( $instance[ 'title' ] ) ) { $title = $instance[ 'title' ]; }
		$title 					= apply_filters(esc_html__('Subscribe', 'arlo'), $title );
		
		$placeholder 			= '';
		$submit_text 			= '';
		
		
		if ( !empty( $instance[ 'placeholder' ] ) ) { $placeholder = $instance[ 'placeholder' ]; }
		if ( !empty( $instance[ 'submit_text' ] ) ) { $submit_text = $instance[ 'submit_text' ]; }
		
		
		$invalid_email 	= esc_html__('You have entered invalid email', 'arlo');
		$no_email 		= esc_html__('Please fill out required field', 'arlo');
		$old_email		= esc_html__('You are already here. Thank you', 'arlo');
		$success		= esc_html__('Your subscription was successful!', 'arlo');
		$loading		= esc_html__('Please wait. Your previous request is being processed', 'arlo');
		/* Before widget (defined by themes). */
		echo wp_kses_post($before_widget);
		if ( $title ) { echo wp_kses_post($before_title . $title . $after_title);  }?>
		
		<div class="arlo_fn_widget_subscribers">
			<div class="message" data-invalid-email="<?php echo esc_attr($invalid_email);?>" data-no-email="<?php echo esc_attr($no_email);?>" data-old-email="<?php echo esc_attr($old_email);?>" data-success="<?php echo esc_attr($success);?>" data-loading="<?php echo esc_attr($loading);?>"></div>
			<div class="input">
				<input type="text" placeholder="<?php echo esc_attr($placeholder); ?>" />
			</div>
			<div class="submit">
				<a href="#"><?php echo esc_html($submit_text);?></a>
			</div>
		</div>
            
		<?php echo wp_kses_post($after_widget);
	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		/* Strip tags for title and name to remove HTML (important for text inputs). */		
		$instance = array();
 
        $instance['title'] 			= ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		
        $instance['placeholder'] 	= ( !empty( $new_instance['placeholder'] ) ) ? strip_tags( $new_instance['placeholder'] ) : '';
        $instance['submit_text'] 	= ( !empty( $new_instance['submit_text'] ) ) ? strip_tags( $new_instance['submit_text'] ) : '';
		
 
        return $instance;
	}

	/**
	 * Displays the widget settings controls on the widget panel.
	 * Make use of the get_field_id() and get_field_name() function
	 * when creating your form elements. This handles the confusing stuff.
	 */
	function form( $instance ) {
		
		
		/* Set up some default widget settings. */		
		
		$title 			= ! empty( $instance['title'] ) ? $instance['title'] : esc_html__('Subscribe', 'arlo');
		
		$placeholder 	= ! empty( $instance['placeholder'] ) ? $instance['placeholder'] : esc_html__('Email Address', 'arlo');
		$submit_text 	= ! empty( $instance['submit_text'] ) ? $instance['submit_text'] : esc_html__('Submit', 'arlo');
		

		?>

		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Title:', 'arlo'); ?></label><br />
			<input id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_attr($title); ?>" class="arlo_fn_width100" />
		</p>
        
		
		<div class="arlo_fn_widget_bh_days">
			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'placeholder' )); ?>"><?php esc_html_e('Placeholder Text', 'arlo'); ?></label><br />
				<input id="<?php echo esc_attr($this->get_field_id( 'placeholder' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'placeholder' )); ?>" value="<?php echo esc_attr($placeholder); ?>" class="arlo_fn_width100" />
			</p>

			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'submit_text' )); ?>"><?php esc_html_e('Submit Text', 'arlo'); ?></label><br />
				<input id="<?php echo esc_attr($this->get_field_id( 'submit_text' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'submit_text' )); ?>" value="<?php echo esc_attr($submit_text); ?>" class="arlo_fn_width100" />
			</p>
		</div>
		
	<?php
	}
}
$my_widget = new Frenify_Subsribers();